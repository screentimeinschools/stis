window.NEWS_CACHE_DATA = {
  "generatedAt": "2026-06-14T16:08:30.482Z",
  "count": 400,
  "items": [
    {
      "state": "Colorado",
      "district": null,
      "headline": "No more scrolling at lunch: Officials from 3 Colorado school districts discuss their cellphone bans",
      "date": "Sun, 14 Jun 2026 12:00:00 GMT",
      "source": "KUNC",
      "url": "https://news.google.com/rss/articles/CBMi0AFBVV95cUxQREU4M19vQnVpRDlZSlZRaksxMkc0Nmczd2tBMHBmeXZRMWhsWmhIbFRnd1czS0Z4NS1qQy1CRW9GWXpwU1kyLUVwc3BjckR3NmRBT1BIN3JURG5xVU83MzdwOTd0TGJabTlDMG9RakRlb2JLT3dZdXZzM2U4czZGam1QSkFFbGhVSUJtZzdIVjFqbkVRYW9yRVJ2eUtOdHM0bzM0bE9zQlVRWXM3X2k4TFluSk1pbVFBVnI1SnNiUzNON1hmZzA4Xy1LeUdQbVF2?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Georgia",
      "district": null,
      "headline": "What we know: Georgia’s ban on cellphones in all public schools",
      "date": "Sat, 13 Jun 2026 19:58:38 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMihAFBVV95cUxQUXhQdVc5ME52ZDZISTBqcXdtSWpGR21TTHdFdmIwblJRXzdHMXREUU5ESFppU2xCV0NrM2JxN2RWNTlyak1PQmFGUWhGRjJEQnF6XzNDTTQ5OU5KMFhYaXBYQ1JwTXI1aVUtbzd6NXVFZ0xOWHJlSDFoN0Nta3Rlek9OeFc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Utah",
      "district": null,
      "headline": "Strict Utah school bans phones and mirrors to stop students from being late for class. Do you agree?",
      "date": "Sat, 13 Jun 2026 19:29:42 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMihwNBVV95cUxQWllwZThETEJFbGE5OUl1LXVIRjVxcGNzM0VTanFRb3hSX3lxNU44aHpYMXV4TEVmYlZfbGx1TjFPSUpxMWRWRnNkcGlISVA1dzlhanlCc0NOd3FzdGhSM0hQWDZJVV9aWUFJZlcxVFVOZl8xa0dXbWtUOXZ4ZEh0WF9KM0ZaTzk0Ym45amJtVjd5ZkcweXBaeWxvdVRCUEROeHdwQ0dscUJmSnRmcW1Wa1JwZWFmOHBiemZxUU90TzBPVGw5ei15cW5LSXdQSEVVekZiTEllWFdlbXJIU2FwU3JqYkFPTDh4VE5Bb3haUHcyeDg3MENXRTBDRGpUQmtPN0ozSEswNlVUcXlEUHlwRG1WM0o4bTlIdHdWNFBGZTJsZkNkRjI3R1g2WG8ybkdCMnZkYl9aM1RPSWxlQkVfS2xTaERHTklvMlB3QzhBbVhTMnRoaklFUlAwSHgxTmFtc2JNNEtGQjhSTkpRZ1VFNjdwUjgtcHh5MVJEcG9ZQkJYeUxJd0dR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Connecticut",
      "district": null,
      "headline": "Torrington school board weighs Chromebook rollback, classroom screen-time limits",
      "date": "Sat, 13 Jun 2026 09:03:42 GMT",
      "source": "CT Insider",
      "url": "https://news.google.com/rss/articles/CBMiqgFBVV95cUxPendOM2laRHBhV2pvX1JQLTI1NVFVRkRFUXVkZWQ1X0lnVF9rcHNYTm52a09MZldiVmZCMThlakpMNEx2MXVlMksxRFZVaFM3c3lWNlFZUWREaGd1a1pxbF9vUlBOUW4teHVHX1FmdUVVVkctVTlkNlFVSWt0cEN0ZXJ6QzExenA1ODVMZWRnUy1vWXhyRmNPZmpGeDd1TGFSampVTlNoR2c4UQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Colorado",
      "district": null,
      "headline": "Southern Colorado school board considering loosening cell phone policy",
      "date": "Sat, 13 Jun 2026 02:37:00 GMT",
      "source": "KKTV",
      "url": "https://news.google.com/rss/articles/CBMipgFBVV95cUxNeTNLSGx0VE9kQmlDQmo1M0tPQ1V4eFYtNDMyZmJwN3ZpbTUyZUVCUnhtRUtMbWxDa0xRVmVLVzQtMHlEcksycDc3cXlBN1RVR04weGEyYkpEWUZlYzNsTDZncEVlV0xQTTVhWTN6NGEzNHY0bV9vTy1zVjJjV1FoQ0pHWXZ5dWRNZDBQaTNqTGw0SlBJdm9SRTFXSUZIRHFDdjB0aTN30gG6AUFVX3lxTFBTY0JSTElpZWpnYXk4TU9MRUFKcVJRYW1CU2NUSERLdktDUlJUQXBlWm1aallhQ0ZXU08wWGJYYURRQzlzdlV3Xy1kLVRqcFNQM09Vb2ZyNHVLY3JlOVVGd1Z0N1g0RGs0Tm9WYTF6WEZVdWQ1YmJtMDQyZmdudDJTQW1JMTdIVWxzRVJ4TkczSlFUNFpaZ1ByMTk4b3pmX2F3aWt1aGJoaWpaYmtfWVlDdjRadUdtclRmdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Illinois",
      "district": null,
      "headline": "Illinois bill would ban cellphone use in schools",
      "date": "Sat, 13 Jun 2026 00:42:49 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMihgFBVV95cUxQWkpQWFpEMi16NDJfWTd0b3lyRThiZ3NsQlowS01fTnY1ZnRtdzk1amJhb3o0dGZodTRyRFN2dWNDR2tiMTg5WWVOVXJuSW1acGFONEZ4V2gxUUJPNTF0RWctekRETW51NmIwODNTdGRYZGx1R3diU0ZQZ0RUaGRhcnlkX0ZRZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Louisiana",
      "district": null,
      "headline": "Louisiana school cell phone ban earns positive reviews after first year",
      "date": "Fri, 12 Jun 2026 22:51:00 GMT",
      "source": "KTBS 3",
      "url": "https://news.google.com/rss/articles/CBMi4AFBVV95cUxOYkhyS0gyQXB2WTlnSXgzVmF0c0JWLUh3VWNNUVJUTXdaYkZ5UlhWb2dwR1dIY3d2RVJMTW53YUoxR2pqR0ROY0gxUEgzaUZNcXYwVTc2aWs0UjE4QWdQRGd0dEhLQkc1S2UweDVfV216dDZjODZXQVZyMTBoVGNxcGViaWMxZ1J4ZHBPY0NEUGJEYXNFaUgyMnRUX1hoam9NWC1NVDBmU2JETy1oTVZfS1hSYkJXV1gycVF5OUZNbEpiOVFqT3ItM05MVUZJOXY3MjRqQlFrRjRNUF9xUGFjdA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arizona",
      "district": null,
      "headline": "NY cellphone ban takeaways: Students paid more attention, bullying declined, survey finds",
      "date": "Fri, 12 Jun 2026 21:00:00 GMT",
      "source": "Arizona Daily Sun",
      "url": "https://news.google.com/rss/articles/CBMiiAJBVV95cUxNNF94c2lhdHBDLTlYYk94VHZXZjB4eXNZUEJFYVVXNHFBWHlhMm9FcnZaNmJHUW5ES0RXVzVCbWxCcm4yNUZldEIxemRDMElvMjRJS2FvTzAxUmdDREhoZFV1bWd0Q3hGQkhHanV1MVFkLTlDM0lsYlNkOUs1UVZvZXNPMFZ1T3l3ZWRnRkQzbkRBMkxDbWs5eVkwWXVqVjlZLWdfVjlnZWlpbGYtc3ZIQjBRZ21NcVdBU1R4QS1VYlBjVjd2ZjFTTTMzNV8tOTZ6NE1WbTFBbjJOTUtUb1pkMmFCNHdiSGxuLW12Zk14Q0x0YnBYOUFTSkVNdnRhTUNRVkxsUXNZYlI?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arizona",
      "district": null,
      "headline": "NY cellphone ban takeaways: Students paid more attention, bullying declined, survey finds",
      "date": "Fri, 12 Jun 2026 21:00:00 GMT",
      "source": "Arizona Daily Sun",
      "url": "https://news.google.com/rss/articles/CBMigwJBVV95cUxNTXFKdlY0NjRXLXlONnhBT2xBRWxTbUlfZDhhN0ozeDdLdWVmVUE4TjJRekhibGpMOVlyZFhmWUFaZzY5ZTc4TWZFSnItTzNTcDdZVWlmV3RQQkRsVk1EQ0JrNGZxby1qdldFLXl1TVUyMEdYWjl4M2Nock9yVE9PQ0F3WnN5VlBHVHpxTVFnaUVDVVV5czBJejdUcllRUVViLVJGTWotdFlNX0RYWEUzLUd1a2Z6eHYtWWFYWUtNeUd0WGh4anp6cXM1bG9MaDRUUmI3bmVKRl8zTkhZbmxCLWxVeWYyVjRRNXFJTUFoaWRiOWk0VWt2VzV4anU4WmZVWWhz?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New York",
      "district": null,
      "headline": "NY cellphone ban takeaways: Students paid more attention, bullying declined, survey finds",
      "date": "Fri, 12 Jun 2026 21:00:00 GMT",
      "source": "Arizona Daily Sun",
      "url": "https://news.google.com/rss/articles/CBMigwJBVV95cUxNTXFKdlY0NjRXLXlONnhBT2xBRWxTbUlfZDhhN0ozeDdLdWVmVUE4TjJRekhibGpMOVlyZFhmWUFaZzY5ZTc4TWZFSnItTzNTcDdZVWlmV3RQQkRsVk1EQ0JrNGZxby1qdldFLXl1TVUyMEdYWjl4M2Nock9yVE9PQ0F3WnN5VlBHVHpxTVFnaUVDVVV5czBJejdUcllRUVViLVJGTWotdFlNX0RYWEUzLUd1a2Z6eHYtWWFYWUtNeUd0WGh4anp6cXM1bG9MaDRUUmI3bmVKRl8zTkhZbmxCLWxVeWYyVjRRNXFJTUFoaWRiOWk0VWt2VzV4anU4WmZVWWhz?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maine",
      "district": null,
      "headline": "RSU 9 reviews cellphone ban, staffing shortages and student behavioral needs",
      "date": "Fri, 12 Jun 2026 20:51:39 GMT",
      "source": "The Maine Monitor",
      "url": "https://news.google.com/rss/articles/CBMiekFVX3lxTE1oTVJGTzhIeHFvZy1ENjdqYnhGMERXemRZT016N0lDZkVfR2tBRHZQOGQ0LUMyM2w3WGpQRDQ4Mk9PRFN3cU9tTjJPRjVkd3dILXlUWks2OGRVSmNKMVZMVDBKd3dfOFNtZ3M3YUd1NDlCQW5iLUY0ZGFR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Delaware",
      "district": null,
      "headline": "Motorcyclist aims gun at students on school bus in Delaware, police say",
      "date": "Fri, 12 Jun 2026 20:23:20 GMT",
      "source": "NBC10 Philadelphia",
      "url": "https://news.google.com/rss/articles/CBMivwFBVV95cUxNSHFVUDVpNzJiZEl5Q1FmVkd1TVFCSVNSZnhSbjZma0FFR3JsXzhuczFjNkY4Rjk1VUhSQjR4b0hpaHZwSW5SaGhkRXpDUHktVDlzeXh5UmFmZndTMEw5cWw0dnZuM0N3Y2lvTHBJRlBySWdEWTJrb1ZMcDlGenh1QnQ0YnJVMFp5SzZ1UEE1ZUZubkc2bkYzY0c1SVlLeGcxTUlSUllqUEVBa2drcVM3OXF3MXh3dU0xTnFfZTZJY9IBxwFBVV95cUxNX2pQZ19lZDhWSmdYRGJsSUV1eHNGdzUxRUFnS2RoN2RLN0VCRERmRGxYejJuYlBRdmhDQkJGdGFEUTdDVWkxZndscnl6WEV1RGhsMkdUWHdkTjg2REQtUno3dzc3a2luc2o1ZXFNeUZZQkROZExBRFNXeEZrWVZQTUdNQ0duZHBibE5rZ19Tb0x5cGZsS193enFZWkNrMmxIWDF4TmQzLWpsRndOekwxVXRFY0p4dzZLMC1kLTdhMVhUZDFIWklB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Delaware",
      "district": null,
      "headline": "State Police Arrest Magnolia Man for Pointing Gun at School Bus",
      "date": "Fri, 12 Jun 2026 20:00:28 GMT",
      "source": "Delaware State Police (.gov)",
      "url": "https://news.google.com/rss/articles/CBMiogFBVV95cUxNUkNCY2RyX3A4VEU3bXFEQ2dVQUQ2MHFXR1hPLXdpdWJWdkUwb3hSTFFucGJWQnZRREFWaXdzRFBnNjZ5RTdYaldNUDYzRUVDNnFjZWhoNG5GdDBiNFVkQjhjVUhyd2J5RFRwSmFvVzR6aGxrSmxYa0N1bmZNdVY3cWRFVGNkbllVdDdaX2VZOHY5LU9VWjFCeTBCT0lBRks0TUE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arizona",
      "district": null,
      "headline": "The Protect Education Act harms Arizona’s disabled students and school choice",
      "date": "Fri, 12 Jun 2026 17:59:30 GMT",
      "source": "Arizona Capitol Times",
      "url": "https://news.google.com/rss/articles/CBMivAFBVV95cUxNRGR3X2Qzby1QRWdPUjh3SkRoSTJZSW1IaEpNSWg5RFpqa3J5LXh3OG0xOWFhQ2wyb09oUGgxZlJkV2JBdUNJOUk3NGdkM2VmdFcybC03SlhvYmltaEJDSDNDdFBidHpRZ2xtNEZEb0taaVRkWHR5UDEwRXBhaVJIYkItSVZ0d1JLVzFWX09ZZEx0QUdtSlM4WTg4NmxUeG9LQUlBd3pQSXpTY29IRm9yVERsUVlnc2NkTUQyTQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Jersey",
      "district": null,
      "headline": "See what you should know about the new NJ school cellphone ban law - Courier-Post",
      "date": "Fri, 12 Jun 2026 16:35:03 GMT",
      "source": "Courier-Post",
      "url": "https://news.google.com/rss/articles/CBMi2gFBVV95cUxPaWZqdnJLXy1JN3g2TkdtQ0U1UVgzSUxyZWppRk5LRWRKS1d5aUZDNlFIR3V3VXNYY0d3T09SVDByYTN2NGVWMnJ3THdmdVRLai03ZGFJSGZvU1FVRFZObWlkOUFpQ20zUko4Nk5XcVBVVzk0MWZjdU04eHdhT2NZQVFRd1ZvZ3UwSFZyeDAySGVEQkZkRXA5V0RQSzBLQ1QtYmRzQkxqaG9qM0k5ZnhFaDRhanhNYTE4YkRHbU1CMmR4RmotRndqMGgxcy10NmhTYTI2V19WLUI5QQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Jersey",
      "district": null,
      "headline": "See what you should know about the new NJ school cellphone ban law",
      "date": "Fri, 12 Jun 2026 16:25:38 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMid0FVX3lxTE1vWkJJMHdjV19xLURYZm5GRGRvdzNzTDVPZG03U0hRdGtzQnNsbE14bDBYaldVbDVxQ0tkOFltNlpla2pUMDdZWFBpVmJRMUJucmhRMV94Y1ZwRUVHeHQzTXl0VG8wZU5EbWZPbXhRQkFhem9ueDVj?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Idaho",
      "district": null,
      "headline": "Former Ridgevue High School teacher charged with sexual battery of a minor",
      "date": "Fri, 12 Jun 2026 16:17:13 GMT",
      "source": "Idaho News 6",
      "url": "https://news.google.com/rss/articles/CBMinAFBVV95cUxPbVZpN1BUSlY5dnpmRUZPd0NZNC1SV0gxMUpuUEhkdXNNNGtXWHdhVzhoRGFlUHUyN3IyUzEwZklKSmNlX05FUWJpWjMzT2FlUUxwNXNiNmh1akt4R3VHVkZwdHVlSnRvdVNqZTZ5QXVOQ29vMEV1UlVXakNwZnRvY2JmQUdXRElVWlBjQlp1X0tIN0xQellwN0xvNC0?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Colorado",
      "district": null,
      "headline": "These 3 Colorado school districts banned cellphones: Here’s what changed",
      "date": "Fri, 12 Jun 2026 12:34:22 GMT",
      "source": "District Administration",
      "url": "https://news.google.com/rss/articles/CBMiqgFBVV95cUxPQjJ0N0YyZzIxSFNiR2dMM0hnaEpBUVdZbWNrNm9UaUpRUXF1MklSOVQxMVpoeVpsUEtBWHYycWxhbHdVOXJJYVJhTHZtM1lralNvTlY1bXdId0E1bEp6cDBZLTk4cDFSNGNkc1phbkdiNHRZenE4Qm0tS1ctQVNEMWlYTlJPRC16WVBHMVk5TFUzZzZvcTVZOWVmSGNFb1hrbU0zV0VwZlViZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Jersey",
      "district": null,
      "headline": "What to know about the new NJ school cellphone ban law",
      "date": "Fri, 12 Jun 2026 10:52:15 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMifEFVX3lxTE1BaVB3cDRBd0pIanBIVHlFMnFVcWt1V0tlb3dLV0ZLajBJcFdVdzdqeEV0V2tvUW0yVW9OT2hGVDd6ZFB6V1VtVTQwSWRQZWJtSEpRdkdZSFdJTlNlTkhSckFvMXA5cUREU3ppR3AtSE5nU296eVUyY3Rvc20?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Colorado",
      "district": null,
      "headline": "Three Colorado school districts already banned cellphones: Here’s what changed",
      "date": "Fri, 12 Jun 2026 10:02:32 GMT",
      "source": "Colorado Public Radio",
      "url": "https://news.google.com/rss/articles/CBMihAFBVV95cUxNTVViazFpTUxfTHpXVTJ3Q0NCQVJNMEZ0TWdMMGlWbm8xMnVpZHpTNFhlaHVVSEJBZlJ1VVV3LTZQdmU3REl6T2tnRHlaQVZxNV8yc2k2aUMxd0V6NHJ1MkJQYTZFMmN0M2FvcV9yb1ZZUDhXWXhtbmY5MUpMSjhlcm1YeTg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Jersey",
      "district": null,
      "headline": "What to know about the new NJ school cellphone ban law",
      "date": "Fri, 12 Jun 2026 09:13:50 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMifEFVX3lxTE1oV2RaR1BJTGtHdlF4UDZCZjktSy1SV0tTSk5wZXpZVEJQX1RPWXpBeFZ6Ul9IQVNnOGxrWWx5Y3J5X2QzaUkydXI4RzJNd0pZd3E5bjlmQTh6N2t6ZVdxTW1ZV3QyMHhuUXBaM0pOVUFyTmNUMVlyV19sTGE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Jersey",
      "district": null,
      "headline": "What to know about the new NJ school cellphone ban law - Courier-Post",
      "date": "Fri, 12 Jun 2026 09:13:00 GMT",
      "source": "Courier-Post",
      "url": "https://news.google.com/rss/articles/CBMixgFBVV95cUxQSENWRWVRY0hRR1J3U19kZ0JlX3Fpa2puWVl0ZHh3OEJpWkpnYS1UM3ByYVZLaHFuOHlUc2dPNjBLVWhlc3pOZW44eERwWlBpeFp3SEpxbmg2UjktUXpXNDYzcWhnbHlpRXFtQjBmREhIakJWLUZYM2Z5VDREN3RTX0Y4eGRwcFBiVl8zeVpvMTNXQ3pzSUkyWlZSaC1tRVlnVGJEYkJtb3NDNVR5N3pQR1k4a0tsTWpWYVpEcC1PRUN0cWhNWWc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Washington",
      "district": null,
      "headline": "Washington Pushes Statewide School Cellphone Ban For Students In Class Brampton Weather (eqEuP8B7Ae)",
      "date": "Fri, 12 Jun 2026 05:51:58 GMT",
      "source": "Mshale",
      "url": "https://news.google.com/rss/articles/CBMiW0FVX3lxTFBlN19nazFKSlJ4VHd1cFdwRjFSd19xbHVmVlVOMXhPOXJDenY4OG5lblM4UVNKM2xmSGJtaExIMmpEUGxXLTU1ZW81WTdPaFlKRUp2ZHFodW1tNzQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Washington",
      "district": null,
      "headline": "‘Away for the day’: Washington governor proposes student cell phone ban",
      "date": "Fri, 12 Jun 2026 02:35:26 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMiywJBVV95cUxQVUhpTEhTbWQwUEROd1NRWHh2MkxYdzFYbVk4SHVkblFTbjMySUdHNHJQaUpkMGFtakhRZzNiWTR1bGJEcmpHMzZoeGJIWkllRWl1dVdNUDlHMzluNzItdWkyYm4ta18zWE11MFUtYXZCY2hPNERmdTFoZV9BemxFZVF2VnJkbkdTYmxsOGdvbWQySlNsZ0VRc3FOZnUtenZqWjJfZWRMV2p3X1pBeTdTSGxYUmlpN1dydEFxR29yYnpPb2hZOXp5YmQ3bFJFUG5hUlNSek1FellDdjNydFl2Yzd1WHBxSVJlOXQ0UDdEX3ZiYTBkTGptd1ZvbEo4SDdFbEdpT2NBeVAwOXdxbDhkZWdYRU8yN2Fxa3R0MXFKQUxXNE45ZUdHRWdrUUVvaEdqMWZuYVBiSU9KZVExODctcEpxY1dYY0NxZ05r?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Illinois",
      "district": null,
      "headline": "Illinois lawmakers approve statewide classroom cell phone ban",
      "date": "Fri, 12 Jun 2026 01:15:18 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMilAFBVV95cUxNZmJXZGpUWEg3ZVM1a0YwTms5VGpFaDR6QTlNTEJTRy0xSlMtRFgycGxyVEFQaG5NWFdraE9xdGtjdTY4SmlVX3QyMjZnSGFZdTJkTXJ4d0xNQzFmQUlEczFOQzA4Ni1vZVVpLU4xeTBEeWFKdFJuYkFTSDZYOWZNcDN3OFRITlJ4cVQ4UVlxMkdna2Zl?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Texas",
      "district": null,
      "headline": "STAAR EOC 2026 Central Texas District-by-district results",
      "date": "Thu, 11 Jun 2026 23:48:00 GMT",
      "source": "KWTX",
      "url": "https://news.google.com/rss/articles/CBMimAFBVV95cUxOajQta0x1N1JkS0ROOHBUME14dW5zdkgzZzM3cFRBTWFFVVVZeFNfSHZKeFN0NUJHNzBlYnh1ZmRRZjFZNkRISEFjTi1XZXdRTjBWODMxaU1XdDNtV0F6U3NndUZlcHZNMHI0YnJYdDlOZV9fRGhsbjJPRnpxQjVhYlhGbkxKbEJ0Yk9jTDdRLVdtakZDc1JfLQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Texas",
      "district": null,
      "headline": "Central Texas high schoolers score higher on STAAR Test in 2026; officials credit cell phone ban",
      "date": "Thu, 11 Jun 2026 22:27:00 GMT",
      "source": "KWTX",
      "url": "https://news.google.com/rss/articles/CBMi0gFBVV95cUxQck1WdExROG51YVpPYk84R0FLUGJvc253Z2tLV1VncW0yQmNrTHdsMzJyUGVTdlRTYjh5cXpBY0hLU043NF9VOTl1UlhWZlNmNzIxdFRBelJhTG54VklTZlVfcnRTSVN0TUEwSURvX3l0MkVpdzdIdHN2VW5wMGxxdjdBYWlkTW5sVmwxMnN6VVp3bEdEZ1hrTWtDOFp0SDZXcno4aXJKaDhHclhBSFI5QW1tWUZubHpXa05rQzJrbVQ2NExfMTR5d3JuZV94V1VqZmfSAeYBQVVfeXFMTkpfbUY3dmMzNzN6RFNaQ3dGVWlGWFRhUkZoWUI3LUNKS2FtMERjenNObm9yNUJHbERQRmIySnNQU01aWl8xUkJNMFhBSjVDQ3RDNEU4RDVXTThCSHZ0ZlgtZE9iNWxiQUktTjBXMHZSSDN4bFczUm4wMDlKNUF2WVk2Z2t6TENRSThwcGRYZGxQVjFkSTd5anFTTFVHODU3ejhQU0NzYUR0dVl0Nk00Y3VFMjBsaVpRdUNQY3Awd1lHSkJ4WVZVeXM2UXBUVFpmanBJbi0wangtTFgycHJreVo1ZVZIZWc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Washington",
      "district": null,
      "headline": "Math, not memes: Washington moves to ban phones in schools statewide",
      "date": "Thu, 11 Jun 2026 21:16:53 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMixwJBVV95cUxPVnZ2MmVFWnlsZHduNG1nb0l6NWh2Yjk5WXItRFR0UXpwQlNZNHFIaEk1RkFJMkRjdzd3WmtPUTl3Z2xveHpGNUZqVDBoVTBCZktpcXlEbUgtS09CSUVIVkxiN2RhWkZQU1NMX096Ry1IcklYb0lLdWJVQ2tiY3dDaTFYbmFCY2VxZzNKTVo5OXh1Y04wcU96Q21JczV3M3JRUHQxYkZITE1EdFhidEx4R09GVWpnQmUyODBQSGRrZnR3UEtIai1zWVBkbFFiZ0dUSG1pajdqWm9kZGpRWjJvS0JmcHEwUWswTDBPQ2s0WFJSQUM1aVhMWFE4ODQtdWIyaHd1Y3FTcDFCVFNKLWF5OU9PYnlxdEJNSF9OaTlMQ3NmSnFCRzdXbi1rR0l5b0FpRV9NcURxTWh3M29IV2l5QzJrM3NYc2c?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Washington",
      "district": null,
      "headline": "WA Gov. Bob Ferguson announces proposal to ban cellphones in public schools",
      "date": "Thu, 11 Jun 2026 19:37:43 GMT",
      "source": "KUOW",
      "url": "https://news.google.com/rss/articles/CBMiowFBVV95cUxQc055bkFVRS1XRmF3bmdHZ1ZlS05JaE45SDdPYXMyVnhWWEJVMFc2NzFJbllyWWxkQ1NGQ1ZNenRyY1dldlcwcGY3bkNOdFBnYmFfSlo2d2RiajdiRHZIODVzMDhybDVHLVJwd2pMUERoVUtRU2hPeFR3emxCYU4tVElHTzFackNCR3dhNDBCNzdQMkVqRjQ0c1hKVkJlTHEtNzRn?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Washington",
      "district": null,
      "headline": "WA Gov. Bob Ferguson announces proposal to ban cellphones in public schools",
      "date": "Thu, 11 Jun 2026 19:37:43 GMT",
      "source": "KUOW",
      "url": "https://news.google.com/rss/articles/CBMipgFBVV95cUxPdzl5X2lsQjA5UjlyeV8yeXl4NVNwbkRqLXp3TUZ5Wmg4SWNLdHE2Sk9uY1RVY3RUT0ZHRk5jWG5VNTR5S3ZvbGNLZl9DcVhGbWpvdTJYeXRveldvTkd4TDdiRnhFQU52akt6LTd3OThUOGRHNUFIMndaWGtWZjFtTEcxTUFxWktnd25GNkFLLWFKT09lTWNMRmp4OHBQVHdhUWNrbjd3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kansas",
      "district": null,
      "headline": "Kansas Board of Education discusses appropriate technology usage in classrooms",
      "date": "Thu, 11 Jun 2026 19:10:40 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMiiwNBVV95cUxNVUQwbE9oN19RWEgyYjlkcnpmSHJIQURPN2U5VWc4Nmp0cURuTlVVQ09hR20yMUFuenoxelN2U0FhR0xOaVJKbExOTlQ3ZHZRd293SDNCX0R2WnRHYkNnRzVEcVFGVDZkTjFYcjFzdzFkNnhXZC02eUxkaEVtc3c4RUxGcG1YdXV6eFFJc0EzVlByUTN5UktLdXVYeFV5Vl8ycnF4cURSWWNDR0RoSEkyaVRaQzVuamVBTW9QZXV1UGZyZHVyQVA4YkRKSDZDRjR0ZFJXMldFaW1hN2w5ZTJIQTJISVlmbWRnQmlPUHNHNXRKQk1qYWFfRkRLSHlBd245Z205TTVldk9jcGdfSmladlNLcXdXQkViUnQzaGZUOEZMcE1qZmpYTTJTeGZsWk9vX3dQYV9zTWlJSXdvS1RqRkRDcFRlNHpfTmV3dGExbGxQcHdiaG4xQlJNdG5PZ3luU253ekN0cUtMYVlBMFloQm1GUFdsVUtKdXpqQ3JhZ0h2WEttYWxVcC1PYw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maine",
      "district": null,
      "headline": "One school’s cell phone ban offers preview into how students, administrators may adapt to new law",
      "date": "Thu, 11 Jun 2026 09:02:52 GMT",
      "source": "Maine Morning Star",
      "url": "https://news.google.com/rss/articles/CBMi1AFBVV95cUxNQ05sMXNnemd2SXlES2gtaVZYQU5IMG9LQTFmeUYzMDgxbmQtR01fZmZoc253TlNualJrUEVyWTNaNWZsMU9XUzUtdVNIUVhlSWUwa085ZXMwWGgtWFFmLVdDeUVyVVBtTGxMc3FTNVdfTXoxd1VQcTRtQUZHTy1TUjJCOUQ0c19DNWg1OVlMU2NWNGlleDNNSVpwU1FsdEFnNng2YmRHODNjY2ZQRVVudGZ3WXZrd2RpcE9ZbzN5dEJPTEg1UW13WlpVemloLUttRDRzMA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oklahoma",
      "district": null,
      "headline": "Oklahoma students lose phone access in school. Do parents have safety concerns? | Opinion",
      "date": "Thu, 11 Jun 2026 03:23:56 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMi4AJBVV95cUxQR2U1Q3JKaEhkNDlrdEFmenFvUFcwVnR0bFJtdEtKZWtYalJLZzQ4QkJwdUFlcUN0eGFBUGhDdHN4Z0lVaGo4TjItZmFMZXh3QXFMQ0szWmljOTkxeksxekFiZG8tX0pMNUFGRVlyYVl4SGktMWw1aXVPTDJCMGpJUDBiTUdhc3dUc0llQ2tNYzNMcjRnc2tsc0xMY0ZpQjlvakdmU0gyU0tFUUxQYlg0OUdqbWR4RjJrS3JMMkZQcDl5eFdLZU1sMk5CQl94b3ZmbGVQOWt5ZS1nUHpDR0doajBJajVsTE9QV3pPZnA0ZWQtNXo0enNzeXdmS3lra0tqOHE5eGxacm5CQkJzZlMwZUNEbzRhWjlncml4azVQZ0hMQUxBb0Y5ZFh3VmJlaTZORFZpNHRqcEl0bk05eHh0US1FY3FpLVdrZnVWQnQ5a0thaWs0VVFEX0k2T3hrdHQ1?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Washington",
      "district": null,
      "headline": "Governor proposes bell-to-bell cellphone ban in Washington schools",
      "date": "Thu, 11 Jun 2026 00:41:09 GMT",
      "source": "Cascadia Daily News",
      "url": "https://news.google.com/rss/articles/CBMirgFBVV95cUxOSC1lenliMk9QQV9La3JEeXdJbHg0Qk5KaE1sUjBXUmFIRVE3TXQxWFhhcW5Jb2s0RjM4cVFFTlk4MjVxSkJfdVpzWDlseFVOMFFRVXEybGh5REF0Z0hwVDJWeUpJUHEtYXBfWWhQV1g3WC1JMUllSnl3MGhza2pQMzM1Y2d1R0stbnhFZE1fb3lHREZ5WWl1OVdUQVJVRVFrT0NmT2E4akFZQXFYSlE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oregon",
      "district": null,
      "headline": "Washington governor announces proposal to ban cellphones in public schools - Oregon Public Broadcasting",
      "date": "Wed, 10 Jun 2026 21:17:57 GMT",
      "source": "Oregon Public Broadcasting - OPB",
      "url": "https://news.google.com/rss/articles/CBMigwFBVV95cUxNV0gyVXZVejN0aGNwcEpOWGxzd0F3TUZIandpUEJ0c19GaV9SS0hJczM5VHg4YkxMOWg0R05DZnpNMHpjQ0dxYVlVY1NWTE9EUGQxSXlUeDYyN2J0UEp4Um9yM2xTcUVfblVFcUEtWXRRbktRTzBXc3RqaFI3MUlleVR0QQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Washington",
      "district": null,
      "headline": "Central Valley School District reflects on success of cellphone-free policy as Washington looks to implement sch...",
      "date": "Wed, 10 Jun 2026 20:23:51 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMingNBVV95cUxQUnRQdVZMSW1tdHBMeWVQWW50Q0NOZmhmRncyR1lYTlc5bGE2eXdLUjRIQ0prb2hKTjZmMEJxODVkdnRlQWpyT09MTUVFV2xCYTZyZE0zcnI3SzJ1T1lmbmQxZTJtZU4wUWxqRjJNbHNEeHRBRFNsSXh5bFRHV2Z1ZnV3QVRLY2VfeGE4S3U2Qm1uMDU5YTFXZGR0eUdCWDZ1OU1fM01aOGJyVHJlRUItQ0hlY2dWVW85TnBCcmNOUEUwcGViQ000S0R6VzBhcnEzeGRfVzR3TFpPT3hibGV6VUNuQWhOUGZ2QW1ZeGQ4R2oxTE1aOVFjNWtFWmNweUZ1VW5WTTRScHVIeGZ2N3M4bG9BbEd5TXI5aEVKZnU0cks2YVFCTmZDdjViTGZJNmVseTFhd3FNUEVobG5KWTBqTk85cnpoY2JJdGpfUGlRUHl6YXR2eXhfaGJzWkpReXR6YmVRRDB3Z0JHbkJ1aldjWVdmc3hhVTA4MXdWRTYxUVpLcGY0enNRTGkyRTh3T1RSa2w4VFVraEhvMk9DRkE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wyoming",
      "district": null,
      "headline": "Gillette school board passes full cellphone ban for K-8 students, bell-to-bell ban for high schoolers",
      "date": "Wed, 10 Jun 2026 19:39:00 GMT",
      "source": "WyomingNews.com",
      "url": "https://news.google.com/rss/articles/CBMihgJBVV95cUxQb1Z3WWdhcEhKcXlsZ1hwWWM4d3I3OEV1WE5oRjIzNDVYWEYwT3JaN1lHeFBxVUVhY243cHQ4MlNwVFB2UENrb19ZT2tUTFh5RzZkMksyVFFwN2JsaTcwZ3YwMXJnUDRNUVd4VENFNXA1YWZvQk5PQ3M1eWJIbnFLNGNNM2lCMkozN3BxZ3E3aVVvRHZZNDh1X1cyTFoyalBVeVljMERubTdnTlRoaU9CRlljV1hRX0xCMUlQc09HVkd6aW9IbzZFQUd1c29fcThwNU9QYnc1clVFTnZGOGVFSGt0RXRsVGl6eXZWbVNxb2l3NkRhejVNcXdrU2lfclhleXhhVWxR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Utah",
      "district": null,
      "headline": "Strict Utah school bans phones and mirrors to stop students from being late for class. Do you agree?",
      "date": "Wed, 10 Jun 2026 17:31:15 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMi4AFBVV95cUxONGVpN1FBdXhUb2NnSU1ybF9TUlB3b1NXbFFDU3ZZbUNFV3drRlpwRXA2dE1NMzY1UjIySndYQmFUc2IyU1Fvc2dnWWs0SEJjR3dPZ1hzMEdOLTVyWmxYVjduMERRNzZLN0FrZW1OVnRISHFsRUx2QTg0d0xRampmSzFnWGo1ckFEc1ZxdEpKek92S1Q3bTRIcFkwSXdtSG5TRm1xWDEwZExiajdBNjFEOVNhUzFXYV9BUHpWN01NNldORWE0NVhZZ2R3UzRYM0s5WHpBTmFTaWgtMmdmb2d2UQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Utah",
      "district": null,
      "headline": "Strict Utah school bans phones and mirrors to stop students from being late for class. Do you agree?",
      "date": "Wed, 10 Jun 2026 16:51:15 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMi4AFBVV95cUxPaGJsRE4telp2bkY1YmpMQTdESThPUkN5b3piWUVldERsTEc5UllWQ3Z1anB0SWlpcWVFX3lhRzk2M0xtS3VxelZrTmlsMTNKYjZFU25paWhpNkhlWjZLdnlTVjV3Snk3VVdGMy1DTWJzSHo1QkNNZnktR3p1VllYb3NiNFhwRzFCSUc2cVlaYmdib2lJYVJmcmNjM3QtUXAwMzdUWlJXTDJWM2lmbVQ0bUJnd3g1VjhBVzQ3UmtwTzJRck1aQmtlRzAwbUdDWlUyNjlfV1hQcHZVTUxCbjdRag?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Washington",
      "district": null,
      "headline": "Could Washington become the next state to ban cell phones in schools?",
      "date": "Wed, 10 Jun 2026 16:43:00 GMT",
      "source": "AppleValleyNewsNow.com",
      "url": "https://news.google.com/rss/articles/CBMi7gFBVV95cUxNcWZqbzAtcUhXSC15UGlNcVFNVkx0dEJic0djbDhHWm5rNk5NampxR05Ddy1fbEF3WEtWcUVyWERIVmRJSlc5LXdtLV83UlZuV1FhWVZCRXlQdDRBLUlNc010UkNaV1hLaF9QWFlTc1FUZDV6Q3RlR3pwRG1NS0lkLVdUSE83aFZyS1R3ZnpkRGUxTExZNlEwM3lFR3FMbW5STnBPZUlwZ1p6aU5meWk0bG5IQUJXYnh3c1ZqWDFiNFNFVUswOHpPUUV6MmdDYUxsREM2RVl5THZZYzV0djlVaDg3TDBud0FtMHJsNDBR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arizona",
      "district": null,
      "headline": "Virtual school, real connections: How Arizona's online students are finding community and thriving",
      "date": "Wed, 10 Jun 2026 15:47:00 GMT",
      "source": "12News",
      "url": "https://news.google.com/rss/articles/CBMi_wFBVV95cUxPcHNKQmlsdTVRY2Fsd0xTX1F5Y21TTlJlX0Q2eThVS1FOM1VvVGRpLUtSTlNZZmNUM1ZCbTE2MVRPSjlxcDc5NGpycmRJeEN2ZHMtT3VWMWllM21STm1oTnk2UExEdm1GVEkxcm16SG5FNEJGeG9BcC1oVW9PdUR1MDNoSEFVLXVQUTBaSUR2SWZrMTV3X1A1Wl9zRFphWXBnMEJhSnFqOXRSOFlza3dyZ1dvMzVBRHV5Tm1vTUpNSllpV2V0Q1N5a21DUk1GZEpOUFhQODVCbzNLUHhsMEUwN3BNWkZKVUVVd0hUSWxvMG9ucEIyeUQ2SE1GV3BMQW8?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Utah",
      "district": null,
      "headline": "Strict Utah school bans phones and mirrors to stop students from being late for class. Do you agree?",
      "date": "Wed, 10 Jun 2026 15:31:45 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMi4AFBVV95cUxPUkQwVEF4RThabm5lVUlSSjZldUJ2N0hMVUwzZG9kdktBMFJWd1Fmd213U0ZqVzYtSmM1M0ZBSk1mTFNvUW95MWhDNThYZHZGR1hmMnIxb1g3ODRBbi1ONGdYaWpkcm9DWVZIZVFoTjVQVFh5dU9neDEwcldQRnd4ZDJ3blhlOGlzLWtYOFVzWFlGbncwNUVIMDRRNU84Ujluc0wxaHBfM3I1SGhwMTR5aGlnNEx1OWJlVEx4eVFGNkl3ZEQ1by1RemtGMFJhQ1FZeEJzZkx4YlVKeHE4NXd1Mw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Utah",
      "district": null,
      "headline": "Strict Utah school bans phones and mirrors to stop students from being late for class. Do you agree?",
      "date": "Wed, 10 Jun 2026 14:15:26 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMi3AFBVV95cUxOS0JkLVdHTkdULTFSSUFoRjFIQk9qUTUzZTVhTGJBbDFiRk1uaWJZcmFiR0dYLXNGdU9ZZmlUQWVySEMyOHdXdGNIdnNRNEJnZFhDWmNidVFpZlR5aC1DVFRTTVc5dk5NVlhFUlBmMTBYbExnYU9QczhZVzlrNzZtSHRNMWJzZ09uZ0p0VzJzQ2dTNjJnUllhMlRzazNIWmhHVG5pa1htOXE1SkVrQUxiUGF1d19XR3RwS0FRQm91cldRZEltazYxWjhVekh6a1Q4WWk4NkxPOG5IZ3BB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New York",
      "district": null,
      "headline": "New York Schools Tighten Rules On Electronic Devices",
      "date": "Wed, 10 Jun 2026 09:46:10 GMT",
      "source": "hudsonvalleycountry.com",
      "url": "https://news.google.com/rss/articles/CBMie0FVX3lxTE1LcFRvTmdtQ3Rud1l6SThET0EtYzAzVEluSzNhRVY3aUpwd19tYWFMZVp2SnFCYUZGc0VJMHJzM0hCVWFmRDlFM051VjlDbEo2TC1RWVhidExaaGZTSzJqZjNoWnV4UDM4Vl93Y2EydUNVVFYtWjZWSW1PRQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New York",
      "district": null,
      "headline": "One year into New York’s school phone ban",
      "date": "Wed, 10 Jun 2026 07:21:15 GMT",
      "source": "Local 3 News",
      "url": "https://news.google.com/rss/articles/CBMizwFBVV95cUxPcjhWUlQtSkp1cVE0WkoxMGtMU3VWbld0WGpZWFNDOHBPVkJtaDM2NWtuUl9ROXBLa1FmS0NXa2Q5d0p4TjdIR3dveHFncUhOak5CbGtUT0phLWo3YmRwT3ozV2RJNEhGUGJkUGkweWRIR3ZQbDlzOUNqck1CR0ladDdyT0xkX1hfU2lnc0FtNnl5U1FramlGd3FIcFFrSFpIbHBVSWhOUUhieTl4S2FZZmJBVHRKMU9LWWpqR1A3STNOMlZXODJyYXNlRE5NeFk?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New York",
      "district": null,
      "headline": "One year into New York’s school phone ban",
      "date": "Wed, 10 Jun 2026 07:09:22 GMT",
      "source": "CNN",
      "url": "https://news.google.com/rss/articles/CBMirAFBVV95cUxQUUkwRTRyMllJR2NYQkZYMnFKQlI2U2M5cWdxTW9SWU9KWEZDNGQwcjhMZnFlZDMtdWdlLUs2VU5mVW9pbm1LNzkxSjl2SG1MNE1KR2dGUnZlOWExZ0U3Y0JKQ2dGaXZiSzhzeG5jaVU0U2RjbDBPWjdvaWFHQjBBcEdyM2o4OGlZYVFJWTkzcEtOXzBFcU5zRThldlozRDRMTXFRZkgzeE9TckFh?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New York",
      "district": null,
      "headline": "One year into New York’s school phone ban",
      "date": "Wed, 10 Jun 2026 07:09:22 GMT",
      "source": "CNN",
      "url": "https://news.google.com/rss/articles/CBMisgFBVV95cUxOdXVRUG11R0dTUnlZWnRnaFZ3endIQUxnU0w1djdGdFVuYUNOQzZJUm9ESVB5bUdOYWY4aXhsVzBkQ3Z5cTdGdkY0dUk4WHYweGlTRWc5bmhlOUg4MEotSTFJOUdmelp2dmw0cjRGNXpVODFnWVl6OWgzSElQdHFTRDFRbTllSlJBTDNvVFJkalYtTDRSaG83d3pwd2YyRDJSVEVsem9XQzR0cmJwcy0zZjFn?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oklahoma",
      "district": null,
      "headline": "'Bell to bell, no cell': Governor Stitt signs legislation for phone-free Oklahoma schools",
      "date": "Wed, 10 Jun 2026 01:57:49 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMiywFBVV95cUxQdnpQMk9tNWRtWndMRVl5VHZUd2wzRWtrQUxKTlVnWUplVDdHQkg4YVNEcEFRU0o4OHo5WWgtZ2ozeEFaU3czcnNOWDFaWjVLUHNsVnNsY2NhUldjbkxiM1pJNU03TzJYcjJrYWpPeU9ZaHRIZURVSkpHV0RaN1dlZUlDNWhOVkxnVGZZMnN4Y1JfRlNoQmE3NDk5NC1TeUtNRzI3dU5NTVFvcEkyV005WEliRVFCQWQzWDZjQlo3dzEzMHlkVmJlbS1Zbw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Jersey",
      "district": null,
      "headline": "Is it legal to use your cellphone at a red light in New Jersey?",
      "date": "Tue, 09 Jun 2026 11:40:57 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMifEFVX3lxTFBTLWFtSk5DaU85MHBfQ19MeUV6el9DRjJEWWV2VjJMaTZmTUtMcktBeTJSa3N3MWpsdnpUbzc3dUtzVjZsMEJNTVJXRHh1ZGNTQkdXcndkZWRnUE5mS3k4c0tndlhiYTlwYzZaZms0bGRwZDd2WGpZUWZod1M?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Louisiana",
      "district": null,
      "headline": "A digital reckoning against smartphones in schools has spread to Sweden",
      "date": "Tue, 09 Jun 2026 10:44:17 GMT",
      "source": "Louisiana First News",
      "url": "https://news.google.com/rss/articles/CBMi7wFBVV95cUxOb3Fvb1Vyd2VDaVc0LW5ObENlSDRuV05qNEZCZm5tc3lSWkxpUkswY3JodGxLYml5bUhYMm85dEJDQkZ0ek9RZzJBX3dkQ1NUcnZJUVlRbHhSbkdQbEVLR1Q1Wnd3YTloX3dOSXNvRWF3WjlfSHhtemNZNVhQNElzcjVqcmZiRTVFcWdPaDR3bkdzU1IwUVJSaDN5UzVDUlJJandpWlg0WURRR2hqd1hhcnh6R3hSUlJDSFQ3WWVFTEZSVk9TaVNwZXhHWGVpVTd3dDBQNE9iN09qTGxhaDdEMTEwOXV5cU9xRmk5RVItc9IB9AFBVV95cUxQSXl4VlB3OV95ZWxmeGFma0dHdnFhRUFseWNQeDl2dFN5eWptT1d5eWUzRWpfMGtEeVZCSFhEMHBYcEJ4aXY3WHJ5bXFTdnRZT2Z4OVdBVnpiYmtQdjdhRnV6dWhIT2hFY2dWXzR2Wkg0NDByMzJTeG8xcXJTYmVSc3FVTXNicmpoTjJMb0ljd0xmelNqVTEzY0NCMnF1SXA3MXFIakdSVWlOTHhXNVh4Z0RMQWc2bUtMY3pUS1puUjAtQ1lUX2dRdkNYQU5wV2lHRFYzQ1dMYVpobWVUTGk1TzZ5LWo4M1N2ZlpUcmt3TUZOMFNH?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Colorado",
      "district": null,
      "headline": "Denver students face ‘bell-to-bell’ ban on cellphones",
      "date": "Tue, 09 Jun 2026 07:00:00 GMT",
      "source": "Colorado Politics",
      "url": "https://news.google.com/rss/articles/CBMinAFBVV95cUxQMTdTNE9CZFpvRzdkWWhncjV4ckM3ZmNWWWJxSk5oSWhtaWhOc2lOR0gzSldHN1R4OF9RVzl5YmVHeFBBUThueGlieG8xS01qVzNlS3JBazlPamRselZMelkwTm1LX2czOFhyTjhYTVpwYVg3Tm92OC1FSVpEUTdGdlFWQ3FNMWZlbG5VWmk1aHlTSnIzcHRVV2txTmI?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Idaho",
      "district": null,
      "headline": "Sweden set to ban mobile phones in schools, joining trend of shelving screens for students",
      "date": "Tue, 09 Jun 2026 04:32:10 GMT",
      "source": "Idaho Press",
      "url": "https://news.google.com/rss/articles/CBMiiAJBVV95cUxNalFxSnYyUmdKYzdTd0dGd3EyYTdad3dXQmllTDVqNlZyQldXQjhqM0FUZzZqNkFIUnN4LVBNbG9wdXlKdDl3bU1MbGpWdVNCV0ZKRVYwZ3lxbnpkYkVsNWd5SmJ2OGI5U2JpUzRTdV9KS1BvTDBXNDBzaUgxWmE5Q1puVFIwSHkwLVdTeFFkZldxU3NvTGVKam01bXBaTnIyYmtydENjTjRJVFJJc2h6MmRGdFNyMGhXSU5nMExOZUF4WGZhZnp4THFjZEN3RHVXdXJYMTdrcmtoZFB6SWVaOXdPSVNuYlZDNFpFWGxjYThQbWFPTS1yMEwtMWF3T1VaTl9qbmdicDc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nebraska",
      "district": null,
      "headline": "Nebraska won't play Texas Tech in any sport this upcoming school year",
      "date": "Tue, 09 Jun 2026 03:21:13 GMT",
      "source": "KMTV 3 News Now",
      "url": "https://news.google.com/rss/articles/CBMiogFBVV95cUxQZFNJTzhGMkhVUU8tZG5wbFpMM2NmZ2sxVzRET3VkRkZURzVycWFXbGdsNDA3Wk81Mk9HYVVQNUJza01tanBERmU0STY5X0lJVm1fUjR1N21vZEYwSklLZXVlYjF0V0Q5VGViV2hNc2xhYm1qSHByQ2RhNzRNcU1Lb3ZiRTV4LXVHVmRORFhIbGVvS1dSWkFXckxvVy1yczVRWlE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kansas",
      "district": null,
      "headline": "‘Leading now is imperative’: Kansas BOE discusses school cell phone ban",
      "date": "Tue, 09 Jun 2026 01:25:55 GMT",
      "source": "KSN.com",
      "url": "https://news.google.com/rss/articles/CBMimgFBVV95cUxPWXJWN2ozUTh4SVlYODFzTjZCTGNXS3U3czBYckN2NmEwQ0NrbjlHeVBvZFE3dXdCMWlJSzZjdWlxSWZMM1hkallrY1huczdlZzFTbWxFUzZVYUVuMnlHQU82dFZtQzN2WkRWbVNhVHZ0a2Zsakc3ZVNLdGJ6UVBWdThGZWlHS3F5R2dGakNtZFVvY05NV01YdjhB0gGfAUFVX3lxTE5IdFNvWXFJU2NPMUpWbDNDR2NZSmxtN09SQnhTdkZXUUUzYk91aEowV25vUlNjSTlkLTBmb2VzUTBWLUJ0allPeDFpTUxoYXROS1Fna0pJNUc0X204UFJLVWxhOXNyeFdUSHRMRXo5dnBLb2JhRHU3WXVUMEhfMHUxZ0JMbFRubUp3RXFYUWNCMFYyd2FZZ0N2dTYtaDVzYw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kansas",
      "district": null,
      "headline": "‘Leading now is imperative’: Kansas BOE discusses school cell phone ban",
      "date": "Tue, 09 Jun 2026 01:25:55 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMiugFBVV95cUxOMWRZSndLV2ozQm42SzRyNTA3SW9GRUhKdzJ4Qk45amtLeWhTaHhQa25RNm5rdTdTZFFNUVBKWHRGbU9aZExSa0hwTGRpaGI4dVNaVXdPV05TS2llcXBndlNqc2RqNUxMdFJuTlV1dGR3S2VPUmJaTGY2dWd3OF9MM0V0clFiaXotejl1SUZhbnNfeWVrdnZNZzhFSVVOVFZ2X0xNSllUUzU5c2Rza0hKQnlFTTJrNWg5ZWc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kansas",
      "district": null,
      "headline": "‘Leading now is imperative’: Kansas BOE discusses school cell phone ban",
      "date": "Tue, 09 Jun 2026 01:25:00 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMigwFBVV95cUxPZ3lfVngzdUFnWk5yZG1xdThhX3NRY2VzcEdfS2puNl80M1VVUDVnMVFjeDZHdmc2QlVLNFFUSzh0VU1uY0lJYlVoVUxsTGtSNi1oTUxPSlVoMkp4cWg0SmQteUluemhFb25SVTVwUDFLc3M1c3VnLXRZRkpjVVRoRlByMA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kansas",
      "district": null,
      "headline": "‘Leading now is imperative’: Kansas BOE discusses school cell phone ban",
      "date": "Tue, 09 Jun 2026 01:08:54 GMT",
      "source": "KSN.com",
      "url": "https://news.google.com/rss/articles/CBMipwFBVV95cUxORWUyZl9CeXdiaHhOazFKbElZME8xOUVzcXJZTldiSXMteVFtRG9ZR1pabnRSdEZtZFRQNEluZUNiay1NTjV0Y05tTXVPd29uWW14Zjg4TTFsNkdXWlRYMHpQb1R3M0o1QjNVSUF5R2xrTFB1cXlzX3pLbTVjRWs1R1JsUzRZVzMzazFvV29oTDdQSmQxX0VDTl85aGRxMHhCNmY2NVhqTQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kansas",
      "district": null,
      "headline": "'Leading now is imperative': Kansas BOE discusses school cell phone ban",
      "date": "Tue, 09 Jun 2026 01:08:00 GMT",
      "source": "Yahoo",
      "url": "https://news.google.com/rss/articles/CBMiigFBVV95cUxOT1hibzM0T0JhWDNuU2s1S3ZEdmlxVUVvbUlORzcwd3JXZHo3RFRmMGdEeWRQX1ZRNTRBNnN6S0NpYWJabzlHYnF5dndBYnh4RURKbjRKOXRod01rVnplM1J6Y1BYUWQ3MGs3TTFCVjRyVzRmYzgzLXlGTEVpSndHbE1IeWgwSFNrT2c?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kansas",
      "district": null,
      "headline": "'Leading now is imperative': Kansas BOE discusses school cell phone ban",
      "date": "Tue, 09 Jun 2026 01:08:00 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMifkFVX3lxTFBwZjJ1RUoyN1dYNW5oaFpTN3k4VzlUN2tERlVTZ255MldDTFdoWXRid3V3V1ptdkJSVV9vcV9IT0xVVUtVNFRoX0NTa2l6VGVnVEc5Um1Rc0E5RnJMbDQ4a1R0b1hYM2E4ZWtrY0pUeVY3MDg2Wk00d0JiaGNNZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Illinois",
      "district": null,
      "headline": "Illinois passes school cellphone ban: What you need to know",
      "date": "Tue, 09 Jun 2026 00:56:15 GMT",
      "source": "Chicago Parent",
      "url": "https://news.google.com/rss/articles/CBMiygFBVV95cUxOTGsybEJZV1NTeDJCUERnb05ac3YzUTJqNmdESzV2ZDFDRW9JX1FuSmRFeFhlRklKZUdmS2prazJWWWowdllERFZpY0ZSbVZlVDh3OXVwZjBWcC16enRjWjZyX1lydzZQVmlWMU04QWtHRVFtM19pVmk1c3UydmRWUzMwckRvMmFmWktPTnk0aE5kcUtUQzh2eWotNVdOMGtvTFRhaXdWalZmbXZzdkJRNlU3RThPUjNfbWRiRk16VlNmVlBMY3BGOGh3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kansas",
      "district": null,
      "headline": "Kansas Board of Education discusses appropriate technology usage in classrooms",
      "date": "Mon, 08 Jun 2026 22:16:00 GMT",
      "source": "KWCH",
      "url": "https://news.google.com/rss/articles/CBMiqAFBVV95cUxPcWpQaFJLcWhXemZaLUVhM0QtZDgta0JuUWYtcl9DX0hGc3VOS1g1d0lUcTNLNjZ6VExHaTdNQ3B6Ml9UREs5OXN6b0V5MTR3SWozR0tFNU5jblhoTHdVb0FXOFdrdERUeEV4MHQ0YWpzaXNDVUMzQjJXcTc3elB3ZjFjeEsza0pUczhwVDhxSlZtbzQ3c2ZKUEoxLXU2QmRLcERHb09mczjSAbwBQVVfeXFMTnA2UHVUM0NfbFo0QXBIYzdPb0x0Y2xtanBUXzlFT2NVNmRTay1pSjBMVzFYelFTRWlmOHp0MGFqMW9QZUZuWGg1NkxmODl3ZmMtNnFUcW9XTzFRZnI1amw4ZEFNOFhXTnpValR4S2xYaHZMbjd5QkMwT25wR3ZiaWVRd2dhOHFfVHJ4LXdzbXd2R0xfTFVEMV9VeVVSR3l2RHhqYnBwRjI3azZLYnJuemNSc3pEUGl3ZkpGUjY?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wyoming",
      "district": null,
      "headline": "Wyoming students spend less time in PE. An expert wants to change that.",
      "date": "Mon, 08 Jun 2026 21:50:00 GMT",
      "source": "Buffalo Bulletin",
      "url": "https://news.google.com/rss/articles/CBMi5gFBVV95cUxQNXFaRUNIV2NRSHhnUzRLSG81MGgyenZwWGNDNENQUUZ6WEQzR0NVU3BVTncxZlZsLWgxRUZYSFhRb1lLNzJyVlpkdVFvOVhhblQ4eGw3anRqajM2UnFFeHpoYU9YNWNrZ2poX0dBUGlhTUJ1aFpzLUJUM3J6S2lxUVRZdE5peC1rV2JvdEMtbF95NkM5S1EzS0RXSmdldmVzd2UzTjJsT3BEQWQ0aXctcXRfWU5mOVlucWMza0dSVVRGZFpJdldWcTBXZTJGQ3I5bkhFQkVVSTdZc0lSWGd0X0N5bE00QQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Georgia",
      "district": null,
      "headline": "As Georgia high school phone ban nears, schools weigh enforcement options",
      "date": "Mon, 08 Jun 2026 12:31:00 GMT",
      "source": "13WMAZ",
      "url": "https://news.google.com/rss/articles/CBMisAFBVV95cUxNcWNMbXpNRVg0cXhfenZFcC1tdlNza28yLXM2RDdVMUE5ajFQamsyQUJ0UndLN09MNjR4ajYzSUdFYWZ4c0w1eXAtcTdJX1dCRWUxb29Pem5DNDB6NjJWbVBtV1NyNDhwWFI1eEpzTWpaQ05VaXcwR3RJWWhQQUxnbDBDX0wtaXQtaHY1ZHlkbTNuUFp3ejJrbEh5NXJHYUxaQkdwa256OXlaSkVYVEJJQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Georgia",
      "district": null,
      "headline": "Georgia phone ban now extends to high school classrooms. Now schools are looking at how to implement",
      "date": "Mon, 08 Jun 2026 11:35:00 GMT",
      "source": "13WMAZ",
      "url": "https://news.google.com/rss/articles/CBMiiwJBVV95cUxPMkw0bXJRQzdSTTZkci1BZ2d5ZG1pOHFyc1JEZEk2MTJ6TFZES2NUUldON2lwcndzQVhjZk81M29INmlDenB5bWRWVHVMTllCMlBoY24xQ0tzVF9KNnJReWF6ZXdqY0NveUxmR2VpaC1NSDlFRElPWk9Iai13TFVkdWxhdlFRN0syUnZJeHlNcDhlTFZ3MDJWci1pbjFRUF9McUhaQzd5dVd0NXQ2M0kzV2pEVGlCdm04WG5HN0gwRTJLWUF2U1Ruc0pUNE9FbG5DYmxYUDIzNUJjSDBJeGY0NnFHdnd3MTg2X1UyY2ZhUHU1YUFRVzZVcWNsQUlNYUN2X0R4emU1UW03WFE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Ohio",
      "district": null,
      "headline": "Ohio classrooms lean into analog learning in the AI era",
      "date": "Mon, 08 Jun 2026 10:26:24 GMT",
      "source": "Axios",
      "url": "https://news.google.com/rss/articles/CBMikwFBVV95cUxPVjJlTjU2cnJjY0tyeU9jSGNfVFdleWZNVmZXaVNadVZmalVjRnZnbTBQSjF4c0xaZTB6OEFUaWZsM25ubGtCODZwUnZacU9WdmJTZ0k5WEpGaUQwUU9hWmpZdU5laVJXeXFzay1ZS0N0M2hZRVVESWg1OUMtWlowMzRlc1dhdndGV1EzUHZBVjRFTjA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Georgia",
      "district": null,
      "headline": "Georgia mandates schools to store student phones and regulate smart devices",
      "date": "Sun, 07 Jun 2026 17:29:11 GMT",
      "source": "mezha.net",
      "url": "https://news.google.com/rss/articles/CBMib0FVX3lxTFA3ZDZYWXU2R3NKdzdXOF9DLVBfaHFfMHluNGpTZE9aMkpsXzZ2QVVHbE1EbXk4amZ6T0JRQ0tYY0NQQ3ZndXlCbWpmMHVWbk9IdHhlZDNPaTNWTGpIX3dRVzN3bnZUdXRWY1dzRlJ0MA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Illinois",
      "district": null,
      "headline": "Illinois’ new cellphone ban receives praise and criticism from Chicago-area school communities",
      "date": "Sun, 07 Jun 2026 11:00:47 GMT",
      "source": "Chicago Tribune",
      "url": "https://news.google.com/rss/articles/CBMieEFVX3lxTE1MRFRRdnJDNEVveFk2NTlpT19hM3hkT1NGNW45WVBWZC1zWGxSY0NVb1Viemw2UUhBZjFMUFNmM3lkbU9aQ0wxVDBZaS1SZHZ2ejhiOHlFMnNleFFvRlBtMktPdS1qcmIwS3JHOGY3MzdPOHNxempXSg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maine",
      "district": null,
      "headline": "Maine Gov. Janet Mills celebrates statewide school cellphone ban",
      "date": "Sun, 07 Jun 2026 08:36:33 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMirgFBVV95cUxObUJWOVVkd183aW41bWRsX2F3eEwxN3lxVkVlckh0TzhxTFZTcXNqbzVaZndDMjI1MFp3QTNzWjROZlZzMHFTZGlEampGQ1VndGlHajFYNURIaXBYQmtWNmNGUHN3cUVaZDJRR3daazFUZFMtd1NvQlUzcDh5MFJQQjNRM1d0ZXVhX1k3QkUyTUZPYXpQZTJ0WWFaaXJDTV82aEMteVRta1Z3V251YVE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New York",
      "district": null,
      "headline": "NY cellphone ban takeaways: Students paid more attention, bullying declined, survey finds",
      "date": "Sat, 06 Jun 2026 16:15:00 GMT",
      "source": "Watertown Daily Times",
      "url": "https://news.google.com/rss/articles/CBMikAJBVV95cUxNblk3SXZhc3N5OExnbzI2bUVXQ0laMXF0UkZqMHh0ZFJLdmd1QXlBeGdzMndQaUlaWThST2xDNlkyVV9yekJRNC1MOG9DRU1MLWs1SFN1ZjVGa0hYQ3JZYzZaTDVZQTJRMk9Ub0pQVG1nRlhqWXFpcGNFTWEycTJQRmhSaWh1Q3c3eEY1SFRRYjdRclAtWW95bE1oV2RBbW9nTzQ0TXpKZ3VCVzVsTnVyVEdnZFNuUDFZaG1XUE9zQTFRbTd5VXQ4SURBQ19jejZxaXlnU25fWVBWOHQ3XzV0NnZZcWVEc0M0V3hSeVVVaGZEd0FLdEw0cHNRcFRZcTZreUl3ZDF0NVQ4WFlkY0dpMw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New York",
      "district": null,
      "headline": "Survey: New York's school day cellphone ban improving classroom engagement",
      "date": "Sat, 06 Jun 2026 14:00:00 GMT",
      "source": "Bee Group Newspapers",
      "url": "https://news.google.com/rss/articles/CBMi-wFBVV95cUxNVi14SG1iNmJ2VGJLLVo2TF81NG9LaGtFWldURENVdUtQT0NSejRodEI4RnNWTXc4WGdIaXhzOFYyTnozQXh0T2JnU3JsVXdBeFMyMVJIVy0wRjgzNHlYNnoxREtBZDktX2hTMk15S045dXhQMmI0TmxZSXc1NkdSOHhOT1pETFFTbVB1aEtCLU91N1VPdGhzd1dRWXJ3NktfajlZVzdwSFVwZm1GM2JnSDVoUm1RQ1Y2YzltLTkxZlUwbm5VdHJnWkZWMDJMMjFPQWVTVXZBSTBodnl1WThvZW80TEhNNGZuWGxha00wWjNzTHpJUHlnd2UwSQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Missouri",
      "district": null,
      "headline": "Missouri schools see better grades, engagement after phone ban",
      "date": "Fri, 05 Jun 2026 22:30:51 GMT",
      "source": "FourStatesHomepage.com",
      "url": "https://news.google.com/rss/articles/CBMirAFBVV95cUxOcjJLdlloZWtORG0yY0cxVDZyMGNVN1oyT2NKYTlIdVh6X0Y5eUcxS3cwYUYzVGRZTU1rQXVaNE8ydFE3SnVwc3g2QXQtQnlieTBabXNrb0dnUU1wRDA5ZTJBWVN3dTdGM3RpS2lYWWUtb3IxSVoteGo0SDlZNGRlS0JZSUQwTHZVWmtZZ0VUR3NpSk5ReU5YUl9HX1VwMUlKc200NElxSVNEQ1Rm0gGyAUFVX3lxTE1TLWFsd0ZRbXVLbzhtdnVOOXNWY2NhUXN5MUYtUEgwZmRVSzhBTDdPQUJHeG11cWRTZklVRk8zUXRZSGJLWUFUaFYtU1M5clY4VkVJQVB0ckhucE5OUXB2MmNqWWpEcUFoMkhITmJRNVJ0cUJrM0wxNXg5MTlNbkp0bDgtWHRaRk9rR1hSVG5IeE51dktWTDgtcTVMVWs3U3JWbHVybDJyMUo2RFNwdWJpcmc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Missouri",
      "district": null,
      "headline": "Missouri schools see better grades, engagement after phone ban",
      "date": "Fri, 05 Jun 2026 22:30:51 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxNQ3Z6cl8zVGRSN01oQ0FwSGNkamVONlZxc0ZwNVZDa3hnMFZXdkwwdE5BVmxUV0xUTjdQT3RUeTZJMlo0UndxcURZT2hfeDgxcU1fUzhsNW9kR1dqeGJmUm8wWEl6Zk1leXh2WU93V0dkVXctNXY0NGxSMmRLTW9vaXYtUEZRbDNwZVdCWHNRX0tvS3NSbjdJTkRJTlRXSFFTb1VZVkhKaHJqSGs?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Missouri",
      "district": null,
      "headline": "Missouri schools see better grades, engagement after phone ban – KSNF/KODE",
      "date": "Fri, 05 Jun 2026 22:29:20 GMT",
      "source": "FourStatesHomepage.com",
      "url": "https://news.google.com/rss/articles/CBMisgFBVV95cUxOd2k4VjV5cFh1N1I1ckZndEpwNFI2Y1lQR1RZeVZZMXdSSWxqX1FHa21QS18tQ2JaTDM1TGZnenFvRWY0UEtDM3NNaHFjRklwLVRoWlZOdWdFejhNUGhEOUJvMFNpSGNETmk4aC01VlRWU1RGSzlhbkh4VjdTbVlOWnJkZDdYYlJwb18zaFBaUXdpTHFCRmZqQ0tUZXNlcC1WRGxYbjNWRnQ2VzBfLXRVaWhB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Ohio",
      "district": null,
      "headline": "Phone ban in Ohio public schools sparks research on effects",
      "date": "Fri, 05 Jun 2026 22:12:37 GMT",
      "source": "WDTN.com",
      "url": "https://news.google.com/rss/articles/CBMingFBVV95cUxOOFBnYml6Z0ZKYWVTTEFYaDBXZUM4a0tQc0xrZ2FWZGt1em5fUG9CVWtCdHVQZXZYVExRQmZzMk1qY0xYU3JJdldGM1dmTUNvbnBPNHQxbFl1YWNpOHZJRUZfb2NPLXpGaVRuZThta1A2OUNHTmV2MlY4SS1xR0V2SXF4RHNJbUkwZWxPbTJMYTlDVkRnUDlSYTNSdUlnZ9IBowFBVV95cUxQMTZsLWYtOXNuQ3F0YmRUbUlVak1UYXZpSzBqWUJDZGJuOGlrckl4djh4YnlOWTVnWG1kZU94UzAzUm80ZHk2bjFZNGJEY2Vxd0p4ZDFXcHZFcTV0eFZVWWxEdHhHT0FSUFJkbDBWbU5fbGJNb2hqRzZnZUZMOU1USWtqWTRzdUoxamlEQVZ6TzBrN2d5UEF0X0tnc29lVkJub3dN?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Indiana",
      "district": null,
      "headline": "PA law would restrict cellphones in schools. Pittsburgh already bans them",
      "date": "Fri, 05 Jun 2026 18:22:00 GMT",
      "source": "USA Today",
      "url": "https://news.google.com/rss/articles/CBMitgFBVV95cUxPZDFPNGE1bjBpUFYycHJxam9JMjJlLUpHdW0wT0ZpYUZzdExLVjRWcVpmRzRGSUZ5Nno3dkd4ZmI3TG5wZEN0a2RtX2FWelZUdFpVaHJmSFhZNG0tbUc0aUFRVi1XZ0FFdzJjdGI4VWV3SmFsX1djeVM0NWJjX1dwcmxCMWdWTjV1RVo1THJ2c2gyT0g1eUdWMEZqX2pubDRfazVncDl5SWl5U0RHV3hlUzloblR4Zw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Pennsylvania",
      "district": null,
      "headline": "PA law would restrict cellphones in schools. Pittsburgh already bans them",
      "date": "Fri, 05 Jun 2026 18:22:00 GMT",
      "source": "USA Today",
      "url": "https://news.google.com/rss/articles/CBMitgFBVV95cUxPZDFPNGE1bjBpUFYycHJxam9JMjJlLUpHdW0wT0ZpYUZzdExLVjRWcVpmRzRGSUZ5Nno3dkd4ZmI3TG5wZEN0a2RtX2FWelZUdFpVaHJmSFhZNG0tbUc0aUFRVi1XZ0FFdzJjdGI4VWV3SmFsX1djeVM0NWJjX1dwcmxCMWdWTjV1RVo1THJ2c2gyT0g1eUdWMEZqX2pubDRfazVncDl5SWl5U0RHV3hlUzloblR4Zw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Pennsylvania",
      "district": null,
      "headline": "School cell phone ban passes House, protecting homeowners and more!",
      "date": "Fri, 05 Jun 2026 15:53:00 GMT",
      "source": "Pennsylvania House Democratic Caucus",
      "url": "https://news.google.com/rss/articles/CBMiZ0FVX3lxTE1fbFQ0UkJ0QUxFSERBcEhFQ24wV2tYbWFSYzV5RlEzTEVIZ1l0Ujd3aGotWWI0NnlNX1QtS0JfZGVBOVgwSlNZdnB4WUFYeUNWa0lSOWFLRkp4U0NUSlBmaFhET0VpaXM?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New York",
      "district": null,
      "headline": "New York banned cellphones in school — teachers say kids are social again",
      "date": "Fri, 05 Jun 2026 15:16:33 GMT",
      "source": "Baltimore Sun",
      "url": "https://news.google.com/rss/articles/CBMisgFBVV95cUxPcElxY3RrM2RMRktfcmw5RDlTdXlKTXg4cEtEUzh4bWRoNTdwY3BsQkthYVJrQURsM1FMdFczOTNPZXYtS0c1ZWwwNFVrcF9wOWl3M2hIXzk4THdEVHZBejBvQWp3ZUFzREpuSjk1R3oyc21fRFg1YmhuOHhtaE9GOEtMQVpWdEV5ZEtwNFNkVHJtbzVmbkg1eVc3QXAxaTlhZldiaXFoVkNHdFpubDVNMEdB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Michigan",
      "district": null,
      "headline": "After Michigan school cell phone ban, most districts haven't | Opinion",
      "date": "Fri, 05 Jun 2026 14:44:00 GMT",
      "source": "Detroit Free Press",
      "url": "https://news.google.com/rss/articles/CBMisAFBVV95cUxQNW5aMnFTX3FqQWV0MmdTR21abXIwQVUwNUtxRUxIMUVhVm5qREZhMGlUUktjYVNGMjdaTm9rU3Z6V092ZWRudU10OHRtczFpd1VOR3pSeWN3eUVXd3BLN0xUOEZUZ2kyTnhFcWlub2RQd29BRFhQSXZmZzJNM3hIaUd6OHRmMDJISnNib3ViM0kxS1diTi1EREE2c3NUem1ZWmw1eWViUmtBam1xbWVOTA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wyoming",
      "district": null,
      "headline": "Campbell County teachers, students and parents speak out against full cellphone ban",
      "date": "Thu, 04 Jun 2026 18:43:00 GMT",
      "source": "WyomingNews.com",
      "url": "https://news.google.com/rss/articles/CBMihwJBVV95cUxQUHd6RC00RlNQaUhVNEotUlBnbmZpcmVXQ1UxX25rSDBqQUI5YWdiQzdMbXdwc1Rad1lxSmlVRzA0ZEpVNmhwakJ6bW5aYVIxX1AtNGVrbE1sMTRUU0tabXMzOUhXQS04VXJ5MzB1YVJvXzFkME16OTl0eFdNQnN3dlpDdXNVM2owMmRVb0gyZTExS01GelRkZjRpRzJ0bjM0UkF1dk1acVFNcU1rWFlVdnljTWFBOWRSYmd3eF9jVEJsanp2MGRRWGJSRnE5ZXRVZXVUY2NkYVBEcjRqbm55N0dmeWNIRmhfdm5UbDE1YVBxdmJrNWxiNWFhSC0xeHVTZ2huVWhWSQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Pennsylvania",
      "district": null,
      "headline": "Pennsylvania House approves bill that bans student cell phone use",
      "date": "Thu, 04 Jun 2026 17:21:40 GMT",
      "source": "MyHometownToday.com",
      "url": "https://news.google.com/rss/articles/CBMizgFBVV95cUxPbXI2bENWTVAzT3lZUzcxM1FKUUNuTHV1Q1REOFpSeDdBaW92WVVhaUJ0ZVc1NkxWSW5uSFNJeTFZMEUwVzRaWERLUTdHdGFrYVhrMmozOTExUHJ4dk51ampEa2VJUV9sODNqTmQyV3UyMkVXREJKRlNvV0RYdUw2cVJRekdvZ0Zhc2FRQ29XT3pGVmZ6bERmdmlmWF9XbDU1SUhYVS1yYmlFV0I3bW9vU1VQQ0dRb3hMZzA2TTBRc0xORzNsRTFMRS1TanZLUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Pennsylvania",
      "district": null,
      "headline": "The PA House voted for a state-wide bell to bell cell phone ban in schools, but why wait a year to implement it?...",
      "date": "Thu, 04 Jun 2026 14:38:19 GMT",
      "source": "Tri-State Alert",
      "url": "https://news.google.com/rss/articles/CBMi1wFBVV95cUxQaUhnTFE0V3B6MlJkNTVJYXppbW5MUHFUZzBVRG9qWkpsZmxlazZpM2ppbFZUWjByYWhzMGRQSDVhZ21SVlRGYk92Z2lveWpuNDRtT1psdWFsdk1XZ0FjWHloQ2ZCbVZycHJpcEx5SFcya29NbGVmMjZjQU41S01FVndDZ1pHZmF3akExTUt2MVRVTlVvQWk2NmhRREc0enRPLXVsSFBQcTYyY0EtN0czMTdRSVpvVmNQWWR2V09PR3RzeUNVNTUtc0pEd2hDb1RjTF95dDFMSQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Indiana",
      "district": null,
      "headline": "One year in, here's how Kentucky schools are enforcing cell phone ban - The Courier-Journal",
      "date": "Thu, 04 Jun 2026 13:52:00 GMT",
      "source": "The Courier-Journal",
      "url": "https://news.google.com/rss/articles/CBMivwFBVV95cUxOV3VnQnBVU1pBcHlHUE9GTFlVRDRTbnVJSk9KZDBWRlFDVkkwNktqdVd1RlF5b0x0SkM3d2xuNDEtV0JkUEppQVg3R3gtdXRGOUhwSE05TlA0R05HV01fQjA0SjBuMUhCVTFOSVRQUWxoMzZPTWw4TzVhVUsxTTBaN1ZoYklkWDktU0NwTGFDU0xlR3ItbjVuYW5vQXpYVFBGWnV2aGdOWVFwT3BHVkxhY1V2aUlZNjV3bHVXTmJTdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kentucky",
      "district": null,
      "headline": "One year in, here's how Kentucky schools are enforcing cell phone ban - The Courier-Journal",
      "date": "Thu, 04 Jun 2026 13:52:00 GMT",
      "source": "The Courier-Journal",
      "url": "https://news.google.com/rss/articles/CBMivwFBVV95cUxOV3VnQnBVU1pBcHlHUE9GTFlVRDRTbnVJSk9KZDBWRlFDVkkwNktqdVd1RlF5b0x0SkM3d2xuNDEtV0JkUEppQVg3R3gtdXRGOUhwSE05TlA0R05HV01fQjA0SjBuMUhCVTFOSVRQUWxoMzZPTWw4TzVhVUsxTTBaN1ZoYklkWDktU0NwTGFDU0xlR3ItbjVuYW5vQXpYVFBGWnV2aGdOWVFwT3BHVkxhY1V2aUlZNjV3bHVXTmJTdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Delaware",
      "district": null,
      "headline": "Some students with disabilities rely on screens at school. What happens if they're banned?",
      "date": "Thu, 04 Jun 2026 09:00:00 GMT",
      "source": "Delaware Public Media",
      "url": "https://news.google.com/rss/articles/CBMi2wFBVV95cUxOOU1ESERsTUpQeFF4MmJNWkwwVEg1eXRMYVdKYm96RlFYb1c4VEtUbl90Yk55RDVVV3I0aDJhMXZoTG8tZ3M3b3hJRFZteEJ0bEtKdklPRzJraHd3TkN1RjhLTzYzc2FiT0tRbkRCNGN0SGlUNTBReXN1cG5XUmY1TjhvN3lULURVOE95dml0N2dWdC1MMW9tQ2xvbVdSZG12b3ZHcHppN0xjTzZkbTdfMnUxSHAwU2Z2QkRwUV9CMVMzS09iVzl2cjF6Z3ZJbTlycWYtdUVZc3h6Zjg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Hawaii",
      "district": null,
      "headline": "Some students with disabilities rely on screens at school. What happens if they're banned?",
      "date": "Thu, 04 Jun 2026 09:00:00 GMT",
      "source": "Hawaii Public Radio",
      "url": "https://news.google.com/rss/articles/CBMi6wFBVV95cUxQNk5aUmpPQ2NhZVJUWnNGTXFSSTZ5MGRSOTF3WGI5NjBldWFLV1NlOE1hQTJHOHNVYXFNR2ZJYm5ZUFZWNFZyVEdFSk5QMUw2TmNzNnZOM1lrYUItZU9fMzFEc1dKdnFGN1F3dVZ3czQ5VU4xZG4yOEVKUWtYenZGVU4zRUJiMU9ZdFhGay1YS0dXTmEzMXo2bnoyUi1ablA5VjVlY1lTTHRaaDJ3OGJmeHpiTFoyWDh1eUxYT2xQcm53Z1hGVkszMlR5MG81eVhhZlBuV2YxMVRrMGd5X1ZYVEl6TXFqWDJXLUJB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wyoming",
      "district": null,
      "headline": "Some students with disabilities rely on screens at school. What happens if they're banned?",
      "date": "Thu, 04 Jun 2026 09:00:00 GMT",
      "source": "Wyoming Public Media",
      "url": "https://news.google.com/rss/articles/CBMizgFBVV95cUxNaFFGcW1vY3RrcFg2UW5XWEF4dnpLMXVSSnRWWlpFQUxzRnoxV2l2b1Z4empEWk1zckhHNktKczVwYklTam1PN25aMndqZ2gzZkxJR2FzZVY0b0twd0NnSVVmSTJLeXAxcHBQTElETWdtOEZBdmhvWUk0N2VuRnVwdUtjamtVUkYxRFV2eG1rRmtDekdyYVMyVEtzR0JjbTBnSUU5NnJlQzB6Z2hXcmk3VUxyM0pjQXNtZlZCOWNONDhRUUtiUjNmVXdlVHJxdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Jersey",
      "district": null,
      "headline": "New wave of laws could reshape school for US students",
      "date": "Thu, 04 Jun 2026 07:00:00 GMT",
      "source": "Central New Jersey News",
      "url": "https://news.google.com/rss/articles/CBMikwFBVV95cUxPemdSdWNLNDVfMm5YVV9Ud1V4NWd4NHRqY0R4R2ZLOVh3b21ieU9aellZY1preDhreTZyTXBhM1NneGM1VVVVWnRPQk93XzJ4RkFVU19pNkk2YzFEakdNVUQ5VVV3VzhwZlJ5WDlxVGgwX0M2LWE5c1BwMldnWUYtcGRXR2t0RExlbl9ka3IxWXZoZnc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Pennsylvania",
      "district": null,
      "headline": "Western Pa. students, parents react to proposed school cellphone ban",
      "date": "Thu, 04 Jun 2026 07:00:00 GMT",
      "source": "TribLIVE.com",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxOSG5ja2djdlpjUy1tdDJ3MFBmSVBlbnp5Z2kyVl9DZEFzaDQ1YzZyblZGcGk5R2g0aXYweTVoMHlCY1lKd2ZoUGxzZEttY05tajdNZ3FOcnNCR0FPT3g1V1psVHhNamlBb2lINEpvakRid0lVU3NYSW5vb1JEajNTYTR1VmFHWEFUWXVOaUNPbVhJY29UVGxHZzQzUTBDaExUbC1oUzZ0RVNUeE0?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Pennsylvania",
      "district": null,
      "headline": "Pa. House passes bill requiring schools to ban cellphone use from ‘bell to bell:' Local legislators vote against...",
      "date": "Thu, 04 Jun 2026 02:45:00 GMT",
      "source": "The News-Item",
      "url": "https://news.google.com/rss/articles/CBMi_gFBVV95cUxPeVVnWEhrcHNJOTBWYVczOVZ2bnU5MU5Wb0J5SEE3dDIwVlpFMy15Yk9ELVpBNG1mRnY1ZUF3TUxvMHNpR3hrR0xHdi1DWUFtNWtvb2dHSTk1OUtFUFVJRmctN1BrM21OelFPNHlnWUh0MHdQZlJMNXg5ZktSaUE2S1ZSal9OQnF6RVNEd1d0RVlFSjRfbUdidzNjWkVPYnBLekpSdHhLWWZIdjdXMVBhb3NJeV9vWXdIZmgyZUtkaERqSUx2Q0tydUJkTVplUkJSNS1mZG90OVFyQ1N6WWx6bzBvSjZmejZxWnYzNUJrSlpMMENtTWQybnVWdWM3QQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Illinois",
      "district": null,
      "headline": "State-wide classroom cell phone ban legislation in the works for Illinois",
      "date": "Wed, 03 Jun 2026 23:26:00 GMT",
      "source": "WREX",
      "url": "https://news.google.com/rss/articles/CBMi4gFBVV95cUxOTUgtZTlfaHhzeFFEMUx3ZHNYTVhxLUpRR01ZbVk4V284dEZaNzg2S1d2YjJfQ2MxemRwamNMbS1ZdVlxbV94RVlXMXVlOE51MExyOXdqbDh2WVEyLXAySHgwdHR1YzB1WURxYzF3OHNXYUlBUzVYeDhrUm0tWk1BeGtEX2Y1OXE4SURrbUg3R1gyVXdjaENDRzMwVHBpdWNWN3F2eFhNaDJoSnRZZHZVcmpmR1Z3a1NOeWFpRTk1Y04welNyY0NudElEYloyYl9BOWFwOER2dFFBdkpROXNKX0FR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Illinois",
      "district": null,
      "headline": "State-wide classroom cell phone ban legislation in the works for Illinois: How school districts will shift",
      "date": "Wed, 03 Jun 2026 23:24:00 GMT",
      "source": "WREX",
      "url": "https://news.google.com/rss/articles/CBMi_gFBVV95cUxOd0JLZS1BbGRPOE5iUTB1Z0ExVk1sbUdXd0hKLTVhX2NvMl9xbmR5aWhuRllRZlMyWF8zQkVZTnFCTXVHeDNvY21adHRRdmY4LVpmV01sZkxkZzI1ckJNa0RfalViY25CZWpqdFlrbDJyTGRvd3ppNGNiVXB5eUx0em9YdlR4TnRFWk0zVjBYM09fenRsX2MtWXB0cEkxUU4yY1JIVlVNQ080VEVqWlB5THFVMnhMS193VEtoeGktNDdYSTRJN0EwaFJvVGs1NUhUSzNPVklMWFRIbzNlWWlZdkRzV3owWEFNWFFMNXBEektuWVBJSXVqd2hnUC1qZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Illinois",
      "district": null,
      "headline": "State-wide classroom cell phone ban legislation in the works for Illinois",
      "date": "Wed, 03 Jun 2026 22:43:00 GMT",
      "source": "WREX",
      "url": "https://news.google.com/rss/articles/CBMi4wFBVV95cUxNOVBWNGJLYmhiaDBXeUc2dEEzY0V2UENtazdFUE43VlZobVdhcHFyRW9zS01BTnhveHFXRy1VRFRpcWNEZG5GTU9kLUtZdVB3TlRiejJqR0staTZvMUMxR3pjTkhMTC0xWnhUR2RTLTRlVjBhVUNHQjJUQm14aFBEV1VOXzVWUGdRNTB4N2k1NHpHa1VBLWlFUnc1bHlmU3c3NVN3bWQxVENZUU9QYWp5LW5yeVoyR25NcGVGRzZ2N0J6QXdaZEpTdTFBZVVHOGh4LUQzWk9MbFNsampBR2tpQnA3Yw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Georgia",
      "district": null,
      "headline": "Georgia school districts must have cell phone ban policies in place by July 1",
      "date": "Wed, 03 Jun 2026 21:37:31 GMT",
      "source": "AOL.com",
      "url": "https://news.google.com/rss/articles/CBMif0FVX3lxTE1mVEkyakFTcVhvakg4V2FPeXBadmpNMGh5TFFmcElOZGZrWWFfRG84ck43WVRRUWVhZk1rVXg3aWpoN3cwVHpQQ2dRdm5OSWY2N1RCQ1lxTDFqdElxU2E2bk9KSERBQ3Rqb19penQ0UFcwdnU1d1U5ek4tVHdnclE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Mississippi",
      "district": null,
      "headline": "Federal judge blocks Mississippi’s ban on ‘divisive concepts’ in classrooms, fuelling national fight over DEI an...",
      "date": "Wed, 03 Jun 2026 21:28:17 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMingNBVV95cUxQREVGRFNVV3pNZ28xbWFiX1cwQmhXZFAyZ21tNFpIaW9ldWxXMXhyb3ZRX0xWMGM4VzNNVHNXdUthODY0TkkxeExTejAwTHVGcktnNHBFYVlQZlpPOGxrY28tTHFOX2JuZkNOY3FGRHZIbEU4MDdwc3c3WmdDektsRFY2YUkybU5WVkhDNDlWUTh2d1VIUkRrQllLc3hIRzhyZ3VnbmxyVEVnU1k3VHlYbDlHRnptMEFVMENZVjBUTmdza2xacHdBcGgtZ1NzYmZLSjZzbktDamU2aUFhcXgyQ2k5SkpxR21nS1FXTlQyYW1mZW04WW8wVjNqcDdwR0JHU0gxZk1iY0pkTjdyM0toV084NGxpSnZ1NGI0aWY1YmJKdF9zWHpsOUR0ODBFTzJWbmhCNU9yd1c3X1pxZl9MR1NMZmJwWl9wWTlXQzRNRGkxT3RKWkJBSDhoeG5xc1lvQzU5MjlUV3BkVTl3VUxDblpSRzJMdG5paW1GMU9uUVF0TTRQNmdreXV5VE9WZDFlMGRtNTQwRkJjZER5dWc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maine",
      "district": null,
      "headline": "Some Maine school districts are practicing phone-free days ahead of ban",
      "date": "Wed, 03 Jun 2026 19:46:34 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMiuAFBVV95cUxPRmprTHVwNlE5WUhfRzVOWjY4M0VpOFlsZ2k4ZS1RN3VZUkRUenR4MnRWNUdmWU9xb24xVWRjMGJGTjBEYXVYUmRJTDBZeEQ1TThkOHdwdThUd2xMR3RNQ09pSEZLRElOTU5BR0lKR2E5VHpOTzduVnhkNWNQaG9OanU5OHJqQ05IVl9Yci1iSTVDQVJ6b1FsZzQ3eDAtc2Z1TldKRk5NdUpSSS16ZkROcHc0UExYUVk2?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oregon",
      "district": null,
      "headline": "Is Oregon's classroom cell phone ban working?",
      "date": "Wed, 03 Jun 2026 18:20:27 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMikwFBVV95cUxNSWYwVVd2VHpKUXJXTnp3T3c0T1RZYUZmYXlmamJvc0dWVUxqZzdRcmwwTVZmUmtMR1NKSXVMUTZZQnVaT0I1TGJIdFFvRzRzZFhUQWVuR0JmTksxaDVFemJva3YySmxNb3BPaEVhMlB5T0FwLXExNUktcTI1a0xRQ2k2UkcxMU5CSmp6Q3pycDlrSzA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Delaware",
      "district": null,
      "headline": "Delaware Changed Cell Phones In School. Pennsylvania May Be Next",
      "date": "Wed, 03 Jun 2026 13:04:36 GMT",
      "source": "First State Update",
      "url": "https://news.google.com/rss/articles/CBMiowFBVV95cUxNSEVDZ1FfazlmMkpLV0ZqYXBIb01FTGtaeWNabUc3TGViY1BsaHdYdkRGTWFLLTdnYVVLc1dJVDJsX2VvVlg1TFlpd2I0MkV2Sm9MVG04b3JhWDlqRGlnWGVtSm1Ic1ItN1JxY3pWLUpWSEJQWnVoeEZFZmtaN21WZHlZcWRJb2xxakdTVy1zMDlJdDNuWllnMDczdmtxWXJXa2Fr?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Pennsylvania",
      "district": null,
      "headline": "Delaware Changed Cell Phones In School. Pennsylvania May Be Next",
      "date": "Wed, 03 Jun 2026 13:04:36 GMT",
      "source": "First State Update",
      "url": "https://news.google.com/rss/articles/CBMiowFBVV95cUxNSEVDZ1FfazlmMkpLV0ZqYXBIb01FTGtaeWNabUc3TGViY1BsaHdYdkRGTWFLLTdnYVVLc1dJVDJsX2VvVlg1TFlpd2I0MkV2Sm9MVG04b3JhWDlqRGlnWGVtSm1Ic1ItN1JxY3pWLUpWSEJQWnVoeEZFZmtaN21WZHlZcWRJb2xxakdTVy1zMDlJdDNuWllnMDczdmtxWXJXa2Fr?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Pennsylvania",
      "district": null,
      "headline": "PA House Approves School Cellphone Ban",
      "date": "Wed, 03 Jun 2026 11:32:40 GMT",
      "source": "New Hope Free Press",
      "url": "https://news.google.com/rss/articles/CBMiiwFBVV95cUxQckpmdXZXZjFDa25MeXBabzdYZ1FwUUh0QUZjS05rTTB2cXN0LWpoZjRfZTAybFA0elFRVkpwYkUxOFMzczVjcE9nVjNTYVNJYTdhWlk0Q0xvSFBwcERSdm1kdVRLbkNSSmhKdExfMDdtY3FlVy03Ylc4ZDFZM3pTck92cHU2NDl6UENj?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Georgia",
      "district": null,
      "headline": "Georgia school districts must have cell phone ban policies in place by July 1",
      "date": "Wed, 03 Jun 2026 07:00:00 GMT",
      "source": "WJBF",
      "url": "https://news.google.com/rss/articles/CBMiuAFBVV95cUxOQXJaMGNNazdzUWRnYklWNGlQR3Jodl9SUzhsdy1lMGc4b3A4UW40MXBPNjhSR3pHcUJXVzZSNms2RXBJNmRGOFEwbVBOOXJscDY3Q0xHeDN3TGhic0E1b29uRHRKY0tndzNSMDliREdscXNlMENoLVA0alU5VC1BRkxBU0lJU1ZaX1kwb01pOG9kdzRyTF9nS2tOZUN3dHcweFQzM1JNWHVFUzBMUUR6VlVfU2wtQXRq0gG-AUFVX3lxTE1XalRpWlFvcXpQOXBmOG8wZjd4RFJiWnJ3MkFnNl9jMGI0eWF3VFRnU1Z0enVzeUNOaHdRNXRGMGhPdTdOR0JseHA4Y1Exc1VVZGZhMFQ0M2doaG0zZ2xhV2Y4RVlZY1FIWTdKc3czRzI4SkFTY2d4LXRkOTVRLVRtMWZRSGFvS3RqcVhuVWFlNTc2Z096eXJ5ZWJiQmRuZmNiYkFSbGV0Wm1wT3gzR3dKNjJpV3hIdGZDeVo4bUE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Georgia",
      "district": null,
      "headline": "Georgia school districts must have cell phone ban policies in place by July 1",
      "date": "Wed, 03 Jun 2026 07:00:00 GMT",
      "source": "Yahoo",
      "url": "https://news.google.com/rss/articles/CBMiiwFBVV95cUxQX2hLNm40YWFrMy1pdjNmV2FDdFlZYUZHcWtlcUprMTYzbkVDT2huNXNrTXZlbmF6SENQcmxEbEJGd2hHekM1TzlVcER3aE9qQWpvcmpuNTktMUdSR3M5bkxqUDZYX3lsY1pNM1NHV0tneTNIZ3NiYnVUZWpJMkcxTVFJbUgyam5iYTZn?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Georgia",
      "district": null,
      "headline": "Georgia to ban cell phones during school",
      "date": "Wed, 03 Jun 2026 07:00:00 GMT",
      "source": "Yahoo",
      "url": "https://news.google.com/rss/articles/CBMihgFBVV95cUxNZnViblpMd2pBeThDTWYyVk9ZMUw4ampvT1Y0ZVkxNUluUUgxajlrSTZmVWR1SmhtalRJQTJERnV4VnpjZ3ZpazlSTnowRC1ia1NhdXM4QmExVkV5YW1pdjV1dDBWNmFUX21sYWY3VHVuaWFBV1RwYVVFRnEyZVU2WTVxWi1vQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Illinois",
      "district": null,
      "headline": "Editorial: Illinois finally gets phones out of the classroom",
      "date": "Wed, 03 Jun 2026 07:00:00 GMT",
      "source": "Chicago Tribune",
      "url": "https://news.google.com/rss/articles/CBMikAFBVV95cUxPNFhsNjVRTHh6ZkV5Tm16bVhwRVU1UHpzbHlvMTVmUFpXMVdnQ2ROai1iS1RyUUhFS2hsX1BXdElIaGVUMzdsMmVhQ0d1Qk1xTWg3MGE4aTVIVVZsSjJKZk5xclpjbGZFam5qTmFQUkRhWnJWUGpyUmxqdHR2MS1HLXBDcm45UV9EeVBoZHlBWEs?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maine",
      "district": null,
      "headline": "Some Maine school districts are practicing phone-free days ahead of ban",
      "date": "Wed, 03 Jun 2026 02:05:15 GMT",
      "source": "fox23maine.com",
      "url": "https://news.google.com/rss/articles/CBMixAFBVV95cUxPYlFNT2xNOVMzdU5RQno1cC1POS1oNnhSSkhkUVRNd0dpQkJCV1VQS1ZCaHFNbjJ6ZGRJSXhxdVlQV18yWmlNbVlZRGt5Q2lZTm5ybmhsbklhbVBDV2JiZkZmdHpvcTc4QmFOY2dFcG9la2dSaFlQT3RXQmZfOFBHa2lCX2NBZ19SeFFCUHZjVnBJSTVhNmJONGNSNGNMdjgwNWRMVTdsckRmTG42TWJOdVJOVkZ5Z1NtaE9TNU1lTmtoM01u?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Indiana",
      "district": null,
      "headline": "Indiana schools prepare for cell phone ban policies",
      "date": "Tue, 02 Jun 2026 21:19:26 GMT",
      "source": "WANE 15",
      "url": "https://news.google.com/rss/articles/CBMikgFBVV95cUxQXzhzaktvYVdKcTF4QlNZMW5XYU5Ob1c4QUVUWXJaelJrV3RRSlRCdVBpVjJZbTFFT0ZjQXdjWjdKMC1DVlJIRFZjdXBCQjNjRUZPMEdyLXhDRmp5WXdCMFRaTEhNdjhVT1VQSEl3T1RLUS1KNWhjQWtWLW11RGpsNV81SzdjTnNJRkF1RUxXRk1yQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oklahoma",
      "district": null,
      "headline": "Cell phone ban officially law in Oklahoma schools",
      "date": "Tue, 02 Jun 2026 21:13:00 GMT",
      "source": "KTEN",
      "url": "https://news.google.com/rss/articles/CBMiwAFBVV95cUxPN2xlVUZRVDN5a1RiUzBLWEp5UUVaOW5vYW9IMGwzWUI1eWNOWmVCZmp6cnRDLS1LWXdYdWV6VVdCdkpVNVhHTDJDX19LMlpEcHk2MUtwZmxBaUpiX1BfZU8zX2ZuSU9SRGo5MFM0dFFqbVRFOVNraFVFYlN3RG56dEYyXzkxM2lUcXVEQjlad2pQSTZicWlPZjQ1aHg5OXBHYzRMZi0tZFVKVkdZM2NWX1VsSkNfOU4yLXlZUzdGSWw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Indiana",
      "district": null,
      "headline": "Indiana schools prepare for cell phone ban policies",
      "date": "Tue, 02 Jun 2026 07:00:00 GMT",
      "source": "Yahoo",
      "url": "https://news.google.com/rss/articles/CBMiiwFBVV95cUxOQ0VFQVNIaDUwdDR1WnlIUEpkUUh4el9ibTV5S3lkSlU1Z2NrYVRxTEhTQUw3ZTZ3cVE2UlBwRGZmOTFYaEVqRzlIOWY5LVotd0hDT0p2dlNzb1ZNT2lHVTU1S1BUcGpBdU1zMnNka1N3OGVrM210VnpWZWNlS1RDMC1tbDh5X1FxWFpZ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maine",
      "district": null,
      "headline": "Some Maine school districts are practicing phone-free days ahead of ban",
      "date": "Tue, 02 Jun 2026 07:00:00 GMT",
      "source": "WGME",
      "url": "https://news.google.com/rss/articles/CBMivAFBVV95cUxQV2d2enEwcEZhaEhSX2p3VHFuZW5VVzhJanoxVG9ZekxiQ2FRRlBKeUY1V2pvTGNCdlItNjMyMERIWXd0U1RzVllZMWRtZjE5U2c5d3kweUlkZU0zMXAzX3hSTkJQNl9USEhZVVNiZ0N0b2ZVVHhYX21lbHBkeThGZ05sY09SZTRxR0c3TWd2OEtwS2k1VGVWMkF5TURzWE9iUXUwcTF0Nk1SbHdGZ09CNE5pTExCLWQ0N2JDZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Hawaii",
      "district": null,
      "headline": "School phone ban leads to more reading, improved classroom focus",
      "date": "Mon, 01 Jun 2026 07:00:00 GMT",
      "source": "Hawaii News Now",
      "url": "https://news.google.com/rss/articles/CBMirAFBVV95cUxNc0VHMVRPLTZtRnI4anNFVXdVXzhaaU5TOHA4ZlpQYm5NRDYySHpTdkZnLVU2YzRiNW9NSjRXN2Y5b0NITU1PT2RVQXFpWlVPZVdXQ0ViMmNoRGF4SXVWNHdvT0JNWlU3bF9ndWtMZFdZWDNqalc4elNfS0w0eDRqRS1Qdm1fR2VRYjdiOEQzcnd3a3RfNTdyRTN6TlV1eERha0Vkc1Itc1RzQmJz?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Missouri",
      "district": null,
      "headline": "Phone down: Missouri schools adjust in first year of phone ban",
      "date": "Mon, 01 Jun 2026 07:00:00 GMT",
      "source": "Sedalia Democrat",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxQQ1A0RDFyZmJtUzZrTmZua2pXSUFJSjNBMUhlbzJtLXRyUWQ1Y0VnVFA2Vk43SXV2dE5aSjVsWElnaVBEY3VIMmtkV1FNcXEyanFnU21JY1d6c3RRZlpIakZIUTU4bFlkVzcxMW1BU3hvS0R6MXVpbFBIRTRUQkpBbGRtNDFOWVlpcDd2c3hsUi10R3BTREJSdkQySEVTTWMxQWlKcDJmb1o0VkE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arizona",
      "district": null,
      "headline": "Local opinion: Year into cell phone ban, results inconsistent but promising",
      "date": "Sun, 31 May 2026 13:30:00 GMT",
      "source": "Arizona Daily Star",
      "url": "https://news.google.com/rss/articles/CBMiiwFBVV95cUxNUk42OWtEbVRpUzZ6YllkaGpCVGtUM29qRk5kZlVucHRyVkFaaS00YXpFOTIta2xCRkZqdUdpYm5CYi1aYWQ0RHJzaExuX3RsYzlGdGljTk5CbEpNd3NVcnFLc2NWU2hiQ2I5NFpSZ3BBb1NDQVBRbjJubGktWlpQaWNXS2RiWFpwcGY4?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maine",
      "district": null,
      "headline": "How Maine schools are preparing for bell-to-bell cellphone bans",
      "date": "Sun, 31 May 2026 07:00:00 GMT",
      "source": "The County",
      "url": "https://news.google.com/rss/articles/CBMiowFBVV95cUxNY0pYdGhobEZmb2JjRTFzZjNXUUZaYWdFa184R2xHTHlWMmNUbzNqbW56Yzhsb2ZyS1NkeC1peEhUWXdPSWx5MXJFa19tNi1NNVAxSWhqRWIwelNxZ1E4bDliaHY3SlNSNjg4d2I5c0pPMzdNaGw4V1VDSkhLU21KTFVTQUFtQ2Z5MUZRR1JadUtXb2RoY3NlQy1TTW9JMnJEZHpR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oklahoma",
      "district": null,
      "headline": "'Bell to bell, no cell': Governor Stitt signs legislation for phone-free Oklahoma schools",
      "date": "Sat, 30 May 2026 04:18:52 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMi4gJBVV95cUxOWEZpOG9LZnNWLTBXZ3ZPUGFVRWdCa19QZzN6SGNCZC1fU2hYSmo5d0xmV1JCajNqZm40TVpoTHBFbExjVWgweDhodWthV1hudVZSYjZ3T2FKRzQxbnZtNG5kb3IxN2ZpQ2hEYUtNQktGUUljX2RUc3llLUhUcXNiOEtDR1RMWEJneGc2UjVad0JXWnpwNnIwLUpRM2R1ZWV2RW1PQ3pHY3ZlMHFmNzdnaUZKUDFnUVNzMUNUZG9ab25YSTdRMGk4OGFaNUVLV1VGcmQyaUV2VVNlejhlZGQ2ZmM5VUZUODF4N0V0RUV0bGJ0R3UyTVB2aE1UekNJY2ZaWEhsWG1ZME9PbmJGNHNTYlVRLXZvMTBRd2tzcU9YcjZrRzgxUThPZDljTFI1RjNTUTVxTVUxUk9rOFZPQlVEV2FFUklaOGUydlhOeWdycEhIMVFZNHU1dTNIdnZJSGotRGc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oklahoma",
      "district": null,
      "headline": "Oklahoma schools face permanent cell phone ban under new state law",
      "date": "Sat, 30 May 2026 02:56:52 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMisgFBVV95cUxNengwUXNzSExINERWTEU4aDNGVGRxX041SnhPdGJZX0otVm1TRDJLaXBkMW9EaXBkN0pvTGI5Rnlja3UtZ0p1NmhZZlZyRGtpX2x4ampIZmRvTEZhNzNNQ2F0MTF3ME8yZmx0R3g3ZTFXenFfSlVrTjk2d2hJNm40Z19xNmFsYkZRMmt2VUJTX29DSzFjM0ZQX25FYVFIRER2UXlhTjFHU3RnM3FmUzItQXRB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Dakota",
      "district": null,
      "headline": "North Dakota Launches Statewide Survey on Classroom Devices",
      "date": "Fri, 29 May 2026 20:57:13 GMT",
      "source": "govtech.com",
      "url": "https://news.google.com/rss/articles/CBMinwFBVV95cUxOT29JWlZEOXIzNEJUZk9XTkdCYmoteVNBQlJhZ1FtaVhrUmc0MHo4REJSUmJ0T2JHeDF3LTRoMDdwV3lkbWJwZHJHRUtpYktfS29IUDVLMnVwMjFvMXRrRkQ1WktKVzBnX2dMM3Z1Q2dMM2luazBWUWRkb1ZGSTEwVW1ZUzBGN2FhcXM4U2d5ejNpa1JwODNYY3hLU3J5d3c?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maine",
      "district": null,
      "headline": "Janet Mills Holds Ceremonial Signing for Statewide Bell-to-Bell Cell Phone Ban at Westbrook High School",
      "date": "Fri, 29 May 2026 07:00:00 GMT",
      "source": "The Maine Wire",
      "url": "https://news.google.com/rss/articles/CBMi2AFBVV95cUxQZmZ3dVk5OUVVUE1CN1dsekpZNzZRNUxIblJxVHNsU2ZzMEpiUWlMTUtORmxyeW1Xd1BIME40WnhCZGxKdXNoT2kzQVFaU1FLbEs0UEt4bW5UQXpDNXBqc3dSb1JLZjR3d2RXQmpneUR2ZFpkU2RWWkRVa3g1bVRFa1NTSXRoZS1vc3JCaWUxVHFia3VINlQ2TFBhVVh6N3VFY0duR3FFY252UzZiVDZiWWpEMWczU0FXazJud0wyU05CckIydVVJWHhtdllrekpfR2ZIOGV2cTk?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Montana",
      "district": null,
      "headline": "Montana education board proposes removing licensure requirements for dual enrollment",
      "date": "Fri, 29 May 2026 07:00:00 GMT",
      "source": "The MSU Exponent",
      "url": "https://news.google.com/rss/articles/CBMigwJBVV95cUxNR25SSlJkZHlheDFrajc4TGtrZnFrWmlZZEtPT1hyekZwSXo1QTdIZnlUWTBMaTJBQjdMSERwZGJ4d2NaZlVrSkdXcHVQSF80MWxQMTM2N2pHQ1dZSndRUGc4Sk1wNXdUSjN6bW1uRno3Um9NelA5RkhKSlZpMTdDZmEwemJtbUpTRWlIZFpPMHRlbHMtRlBsbFVlUC1oVjFITUdPelV4TS0wZDgxcnJvUnRyNEpCYktlcHRfcURiVFFrbG9ZMk9UTlRWUk5oRDU3U3V5Z2RNY3BjU1hTRzc2aGMyMmxUWXlUcVJSSkRjOGVqYm1ZbUs4QXA0cmd0ZlJ4b0tv?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oregon",
      "district": null,
      "headline": "Is Oregon's classroom cell phone ban working?",
      "date": "Fri, 29 May 2026 07:00:00 GMT",
      "source": "KVAL",
      "url": "https://news.google.com/rss/articles/CBMie0FVX3lxTE5NeUExdkZjaFBMUVBLYlcycllmc1NVeDl6bXV3OUJ0SVNMdnl6S2dfekZZOWVGMDRyTk05cW9KX0FRRW9jajcyQWxkM3ZrTXdtOGVDQkZaSFoyS0x6bXN5cjhrZlR6VFpHSHlQUjRPa2VGc2xKdERGemQ1cw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Indiana",
      "district": null,
      "headline": "Concord High School implements new system for Indiana’s cell phone ban",
      "date": "Thu, 28 May 2026 07:00:00 GMT",
      "source": "WNDU",
      "url": "https://news.google.com/rss/articles/CBMinwFBVV95cUxNU3FHOWhZX2lGNlFQZGxGaElDVkgzX2hYZ3dySlpMREVpSkQzQXZzR0xjdmFfSHR1Z2cxYnR2S2pMNjNJUVZUZWV1NTlPaWk2blBwWEp3WThQeU40SXBjTFZDSTVkMm5SVW8tVkVLQmo5ZmU5aXlBU2FqQnhzdENQYVVJSlhoMWNiQ200aEI3MERaOGNIdmxULVdkWXM1alXSAbMBQVVfeXFMTVNfamFMNGQ1TVhWX1FTa2J5QTdUNHBxekQydUVMRFVqSERJaWJ2aEplTXNra1ozM2pOMTZVeHFPVjhXTncybmZaaWhuQUNYX21lMlQtQ0RhQ3V5Ync5ZmtUTjR6QVBYYjIzdzdvaWFoNnRodkFBTHVkdTFDTm9sS3l3N2dFaERuWXZPLWdlYVkwRkV1NXZxQ1RuLVRIWkpFOVBmellHNVl0WWZzQlVtbDAxQ0U?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Indiana",
      "district": null,
      "headline": "Concord High School implements new system for Indiana’s cell phone ban",
      "date": "Thu, 28 May 2026 07:00:00 GMT",
      "source": "WNDU",
      "url": "https://news.google.com/rss/articles/CBMipwFBVV95cUxOUHh6SWdkb19JUjVqZHY1ejBoQWdGVTFpOE9KSXJvWVNWZkFvaEFSTTBnREY1N25WZ2RWU0g0bGl3RjJsc3JGTERwSndyNzZtZFFtX1lFTVMyZHd2T3hSM19TNk54N3RVYkZCSTR1VHlROTM0VzRGQThMb3pQZ0RROXJyZVdSVmlwMzVmYlBZSXpMN3RDNjhFbEFRTV9MaEpaZ0toQ3U1UQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Dakota",
      "district": null,
      "headline": "Public asked to weigh in on technology use in North Dakota schools",
      "date": "Thu, 28 May 2026 07:00:00 GMT",
      "source": "North Dakota Monitor",
      "url": "https://news.google.com/rss/articles/CBMirgFBVV95cUxPVXRGX2VXdmRBekJSSjhmRnJKTFFOSm50WXhJMHBQdmtNdnFZT1h1cUd1b3d4NVZKeEQtbmt2eUEyNmJ5aV9Geko4N0JNSjZZLTVPa203UGVMNHFKSnU2WXRDbmJDSzRUZkpkeTdnZmxEQ2h4REpoa08tQmRJTWxBWWlRX1pFV29hXzJMZXZ1eHRxa3RmUzZtcTZZaHpPWnNVZkxXdmpBclBjelBTanc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oklahoma",
      "district": null,
      "headline": "Oklahoma schools going permanently cellphone-free as Stitt signs law taking effect July 1",
      "date": "Thu, 28 May 2026 07:00:00 GMT",
      "source": "Tulsa World",
      "url": "https://news.google.com/rss/articles/CBMisgFBVV95cUxOSm5SeTg0alQ4dHd2Nk5nV1hGQXVYLUxtSldMbkpmY2s5V0tJdWt3VHFqR2hCRDlpZVI4ODNwOVFuTmoxZkxscjlRZl8wTDRyazdlOGctWnpJV1d5V1o3Uk96Y2ZHNFFmWlpTRGxQcF91UTlRNWJ6VndnX2NxME1PWVllNTctWnk3MV9iY2FaaURXcEVVWUNXZzdBdUpJcTFwRnNka2t4MkNjcXBySGVEek1R?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maryland",
      "district": null,
      "headline": "Maryland law requires public schools to develop bell-to-bell cellphone restrictions",
      "date": "Wed, 27 May 2026 21:46:14 GMT",
      "source": "WBOC TV",
      "url": "https://news.google.com/rss/articles/CBMi8AFBVV95cUxPOEEyc2VPSlk3V1ZGZ0tkMElWUDl5dXkyT0QtNC0tUnR0U1FaV2k4cmNMMlFoWkNWVWRSV2RtYXhYZUppLVZsWUJWV0loUnNhZTlMSXpsdkJ3enZ0MmpfOWRWMXBHRlEyN21XZTlTVDUxdmRxUGdqZVd3Y0UyZHdtRXR3SXphNV9lZzUwSnBOVU90WWktMU1neTJkM2xrbW1kWHpQVFZkbzBQMm9DTWE2TjczbVBHdk8xNDlCUGFNUFVGV2dtWXpJa0JselJpNEFKblRSVjhRc1hwUWxRUUlwcWxpUWM1T1FZY3FDLVJ6NFM?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oklahoma",
      "district": null,
      "headline": "Stitt signs bill to permanently ban cellphones from Oklahoma classrooms",
      "date": "Wed, 27 May 2026 18:20:09 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMixAFBVV95cUxQV29DNWtWRnVsTXBEYVBUUmRuS3JSNXY0WTR5TTk3T1hjcTkxczQ2SWFsNWc2RzNlZ3NJRnZCaDltS005b0lRTjlvVU8zXzB4MEdXUS14M3ZsUFd5VDZpdGFvdkZ3ZDJpeFVvN0dKdzlMeGswSndlOHI5Q2J4X1dBeDlEOS10U1dWVmxHZVZybUxnMjlVVV94YnNfV0M0Vml0V296eHhCMG9iaHpBZlAxUTIyRWhJcDJtM2ZJejhkWEtfWXh3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arizona",
      "district": null,
      "headline": "Arizona’s tribal regalia toolkits aid Indigenous students, families and schools amid grad season",
      "date": "Wed, 27 May 2026 07:00:00 GMT",
      "source": "AZ Luminaria",
      "url": "https://news.google.com/rss/articles/CBMi4gFBVV95cUxQYUJpUmwxTE80TC1nWDJFM0lGUE1xYzF6RVMwRHNVRUZvXzJxWmg4ckdHS0YyeXlRZzZVd2tid0JtRUcxWFpza3ROYVZSQTNsc0FBUXpvMWEzN2pVYXJ1bjNKZnQ0bjRISUVESHNDM1d3Q0NZRHJrNGphVkJpanNiRkZHeDZfMjBOQTJhNlFnamozMEpDNzdRUjQzbnVHM3JjaFFxQ1FocUlSWUhodUh5ZjlWYy1rNzM0U3RLVFJuSHZ4YzJHcURHUUtZN3p4UWZGOTRrQXBocmFFcEhxOEJ2NnFB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Colorado",
      "district": null,
      "headline": "Colorado schools roll out stricter cellphone bans ahead of state deadline",
      "date": "Wed, 27 May 2026 07:00:00 GMT",
      "source": "SummitDaily.com",
      "url": "https://news.google.com/rss/articles/CBMif0FVX3lxTE9PZnphaGVVVFRoM0FEaVliR0s2Sk1BNW84RnB5YXNMbDRuZmY0ZUozbGIwUDdNZkxBMklTMWt5VG4tM0o1WU1ta2d6Y3NOelNMWkt5c2VoaUNuYTdrZUI2OVlvRGV4UjhRVVNRMURCV3BqVWdxVy1heUpwRS01XzQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Hawaii",
      "district": null,
      "headline": "New cellphone limits coming for Hawaii students - Honolulu Star-Advertiser",
      "date": "Wed, 27 May 2026 07:00:00 GMT",
      "source": "Honolulu Star-Advertiser",
      "url": "https://news.google.com/rss/articles/CBMipAFBVV95cUxNbDJPX05kTUpmR05QWGFlYnNRY0Vvc2xrZ25xSk1HWmpsUGExV2Q2cHJaNzl1cW5TTl9hLWI1ek9CWHBaWkl4R1hJbGVBMWgxc2lRc3dfRjIwWEo5UjlTNFRzQW5JSFE1T3FHekFQX1U3TXRoYmxnZnNsMzRka2VhdzlWR0ZyVnI1c1JhcnFFUmdJQzNhMmJaemVEY3ltbVdrcHp1RQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maryland",
      "district": null,
      "headline": "Cellphones in schools restricted across Maryland under new law",
      "date": "Wed, 27 May 2026 07:00:00 GMT",
      "source": "CBS News",
      "url": "https://news.google.com/rss/articles/CBMirwFBVV95cUxQb1pkYUVHak9Fa1RMeE84a3NCLWhXRVo4RzFkSENOZmNkU1ZQZ0FCNV9IbDZHcTltWnVKalVoaTZnNEc2LXdnSkpBUWFwcGhTSHluTTRGTFlOdUJ5T1ZIWXBoNHJyb0xoR1ZhdXJpbG9HWGY3VThUaEFTLTJlNEgySnlZMjBJd2ItdHg0cXdyUlVCX0VvQUFJYXo3XzR2WkVxSGJBZFRQd0lCdHByT2Yw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maryland",
      "district": null,
      "headline": "Maryland’s school cell-phone law earns good grade, but will it make a difference?",
      "date": "Wed, 27 May 2026 07:00:00 GMT",
      "source": "Baltimore Fishbowl",
      "url": "https://news.google.com/rss/articles/CBMikAFBVV95cUxPcVJlamFRdmVJNzg5N3RrdEk0X284TWFxSjh6QlQ3cjJkWTMya1lfLUhPZTJ5VmRzMVNJMHRXOXZXdUpQTUFvVDY3U2oxSDlUY1VSNDVvWTdyYVlZYVhGYkVwY3NYNEZFUmRiZUhvdlJ4bjFLZG5kY2MxbnZWMkJWYWZyUXA3M3cyQXU2c3Z6dFo?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oklahoma",
      "district": null,
      "headline": "Oklahoma Gov. Stitt signs ‘Bell to Bell, No Cell’ school phone ban into law",
      "date": "Wed, 27 May 2026 07:00:00 GMT",
      "source": "Tulsa Flyer",
      "url": "https://news.google.com/rss/articles/CBMie0FVX3lxTE11M1FMSkdwc1hqdzltMlEyelU5RW9BbU1EQVhmcXZyamRxWVZwZ0k3aTVXeFlzdEZSUzVINHJORThBTHV0bHIxNEgzeWlfR19lSWVWZC1yZ3hjM3JJZ1k3VVFROXpBTHhXT29ZckZDZDhOY1p6WmViZUNyNA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wyoming",
      "district": null,
      "headline": "Proposed full cellphone ban met with skepticism by local educators, parents",
      "date": "Wed, 27 May 2026 07:00:00 GMT",
      "source": "WyomingNews.com",
      "url": "https://news.google.com/rss/articles/CBMi_AFBVV95cUxPU1ZTdF9KQkt5cG9RVGVybnJaZkRmYW5meHNpQlV0QzVsSWd3TFp5YXVZZGhtcmVlZXhOVGd3NTZaM2JhR3J5ak1tRENwLXgwZ3NNc0RtamdMMk9SVFAyQ2RacEp1eGJZTmRwVEY5eDJtai1wak5iaWRmOTZ1cFpvREM1SlN1UUNFTEZLaWlZcVNaVUF0RGp2Nm15dGhxZWh6RV94cnVxZG5SYU40RkFjUTdYY0NBY0pUb0JjT2dKVHROQXladExfYi1JSzRaQWhIbnF4NnlkZV9wd3RWRE11aW81V1RqcVBBT1hqZW1lWWdfbmZoekJITWdsdUY?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wisconsin",
      "district": null,
      "headline": "Madison school board under pressure as teachers and parents call for tougher cell phone restrictions",
      "date": "Tue, 26 May 2026 07:00:00 GMT",
      "source": "Isthmus | Madison, Wisconsin",
      "url": "https://news.google.com/rss/articles/CBMiwwFBVV95cUxNMzQ0b3hRVTk4SHZMUHBkNWNtMnlPdGF2M1dTaXlQT1lqbHFhRlhBVkpWOTcyTExfTWFlQ1BzZ1lvbjYyTzNaeWlWZ19qSnVFamVJX0xnV3JkMW00bUJ6cVFnQjN4Y1hLWWFzNnNiNWl6NDkzN0MwTk14S1VEMDRXa2tTRkxIdGVkUmtLX0RqTkw5TjB5Wmh2MmszS3EzZ1J0OG9wX3dfM2RtMENCeFZHaGU4VFROdWp0SmoxbndXMzlTZVE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maryland",
      "district": null,
      "headline": "Q&A: RM community speaks on the Maryland Phone Free Schools Act",
      "date": "Mon, 25 May 2026 15:06:52 GMT",
      "source": "thermtide.com",
      "url": "https://news.google.com/rss/articles/CBMinwFBVV95cUxQbHR2YU5kRWFSRFNQRVgxaGhIM2kwcXVyUkRjdldQOVVTZEI3dy1mbWwtRTdzc21JZGpMZElobHk2QXFlaS1Ga3N6VzdJcm5YRmlUbllRdzhxSnAwN0o0S1FlaW4yWnZsNGl5S0NIMEU4LWtlWmlaOWdmTDVMUDNfYzlNX0tXX1AtdUhlUUUwMTBjbTQ5ZmlFYkhwV2ZDSDQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Iowa",
      "district": null,
      "headline": "RFK Jr. backs Iowa’s new limits on classroom screen time",
      "date": "Mon, 25 May 2026 07:00:00 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMi7AFBVV95cUxQek0yM29iX1d3LUV4N19pQXBLTkc3SzhvY3FNQVNSQl9taEFTVThyTHlvQ1pxdEF1ZGpIaS1MOFFsZ1ZuMkNXZS1CS0gzUnB3RmhXR3FjNHV2dWZ6aWI3UDNSVHFPeXNUTl9ZMnY3MWFNM3JtejdENTRoUmNVT296ZC1tTTVQa3FNUnFqZi1xeGgyYnBERXhBdUhFYVpwODQ4b0lGcHlmd0hIR3B1bmhQYlRWdmVEc3l4NWpWaE9nTm0taUtNQ0JqWGNIQTcwbHk1X1pHSllMQkJHRnpQOGtjdTZabk56WmxKODZaUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Mississippi",
      "district": null,
      "headline": "Mississippi maintains an “F” grade on phone-free schools state report card",
      "date": "Fri, 22 May 2026 07:00:00 GMT",
      "source": "Picayune Item",
      "url": "https://news.google.com/rss/articles/CBMiqgFBVV95cUxQOWlLUzQ1UEtzd2QxMzZmZ3FBVzRxT08tRjZ6OTZNcUVCOFNWb2dxZ2o1RUQ3MFd5SllscGdvbGdwUjRtR1pDTmF1Z0pHaTZGQ1pKVUtlbWFjZlJIY0hVYjRTWXVNTFR4QUQtM0Mxd0s2X1VVRk5SQmRGZHJsdDVZZ2Z5a2hjOHhEWGQyV2lZZk5TcFhMTDJNOEtMc01KM09EWG5wNHNBSmZiQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Jersey",
      "district": null,
      "headline": "Cranford BOE Questions NJ Cellphone Ban Rules",
      "date": "Fri, 22 May 2026 07:00:00 GMT",
      "source": "Patch",
      "url": "https://news.google.com/rss/articles/CBMitgFBVV95cUxQQmF3cEp6UEZ6SFpqRlhVQ0p2Q1Z2RG9GSkh3OFhHRnIybG9fQ1ltc2F2V3I2VVJybHU4aE11OXFFSXQ2eUtGczFITm5LSnllanNIVzRVNDRVLTBOWmpCZnppUTZZU25ReTRyNGU4YmZhX1NsdVA0OVN2MHh0SG5qbHp1UUpveHM2ZHhmYXpxUE0tek9sSGJyZlFhVmI4MS12cDdQaDN1ZExXZFVVb3l4TURaNzA0Zw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Texas",
      "district": null,
      "headline": "East Texas educators reflect on first year under state cell phone ban",
      "date": "Fri, 22 May 2026 07:00:00 GMT",
      "source": "KETK.com",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxPS2NHc2Q3WDFjWGtIMGJST2Mta3pxSFpJN0JvQkRGWmU0TGdDNE92S3NUWDY0ZElkMDVnSU1rbGE1VWdwaHk0dXlqYkFGWVhldTFESmFXVkNzUy15LVd4Z0g5RVQxak8xX2UwdGRtM2VvN2NXeWd3d1ZBeUozUjd5N3Q3dzZ5cGRON0FzVlVMNVpfU1JJM0NCQk1YZXd0NG9TanJ6SThTc3JWUkHSAbABQVVfeXFMTmxmUDJQUjZWVEFkZlY0U3pTM3hWQ2h1dC1pQ2VncmR3SlhlZlZsa0VvNmFWbXhkNU9Ibk5yUGtuSm9sQW1iLWFGNUFQYnRCY2t6bzBoakRma2h2UF82Q1dGYmR0THpLUkVkbTRSV01oajBqX2QyVk9CNm9lbUpvSTZGNGhtdURBQ2VTSFRJRmZyTUVOdDI3ZnRWR2dEc0FqVDJJSVVYS2Z4SWpBWlltRVY?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Rhode Island",
      "district": null,
      "headline": "‘It was time.’ Infante-Green says she’s ready to hand back keys to Providence schools",
      "date": "Thu, 21 May 2026 20:49:33 GMT",
      "source": "Rhode Island Current",
      "url": "https://news.google.com/rss/articles/CBMiwgFBVV95cUxNQnh5MW5KTXhzelNMMFJwbWpGZ09FSkdBVXBfSmsxWlRRTnFnaHhPQnVqSFdFQ0p2WFhnS01XMXAzXy1KT04zbnNvR2xFNXYxYjZ4TWxzRWo3ZU01VW5NNERmQUpKVTJlRkZxMXNHN2Y1eFhFRGtvOHA0X2JFNEtDb2Zoc3hWODlURHBhbUdzYlUyRWdfd29rVFhNN1hyR09BNXFMdHdWVUs0bWFfTDNuT2Z1OHg1cjFkcnBzWDZoRDVZQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Idaho",
      "district": null,
      "headline": "High school group challenging Idaho’s trans bathroom ban drops lawsuit after student’s death",
      "date": "Thu, 21 May 2026 07:00:00 GMT",
      "source": "Idaho Capital Sun",
      "url": "https://news.google.com/rss/articles/CBMiygFBVV95cUxPYlRxSXlQS0p6THNadUQzV2Y2VDRsSW5UbV9xdnBXeFA3YS1ITXJDalVzVzE1TGJaOUJ4ZTJhbFN1d0NDWGt0RmNaaGx2d0ZpVDZQU19yZTNhdWw5N1R4cTI0ZHlDcS1aSW1KdUQ4VUU4blR0LTg3VWJHNVNCbzJmQkhGdGdQY0dGU1F1YlROTlN5RDgyUzdmWWdGUE1XbkVqS3czeHI2Qm0tNjZtZGNYUkptdkVtOE1pdDBVTlJMTG4zNVo2d28teWJB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Idaho",
      "district": null,
      "headline": "Challenge over Idaho’s school bathroom law dropped; law ‘fully in effect’",
      "date": "Thu, 21 May 2026 07:00:00 GMT",
      "source": "Idaho Statesman",
      "url": "https://news.google.com/rss/articles/CBMifkFVX3lxTE52d05EQ0VJWnVLYzZRNi1TemVRTGtWNE9YU2dJZ3JpbVpMNkpVNzVzbHFSUmx0U1ZMNUtvNW8yMnBDUXUwaG82M29CcHhkcHBPWUM0UUlaRDEwTEVfeXhnQzVpUWxTZHJUWGN0bWZuU211cXRudHF5N1ItNEhwUdIBfkFVX3lxTFAxLWtNUmpjZk5NYmxjaUR1N1huVHlQY1ExeDQ3ZUxlMG5FVUp2MU02T1pMQkY4MmRxb0pSOXdyZk1jZndHWjJZcWtnZFFWbVFFZkZnRWVHNGpkZ3YzdVdZZUF1c0dvYkthNkhjZEJFTC16WEROeXhNTnRoZFFHdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maryland",
      "district": null,
      "headline": "The state of Maryland passed a cell phone ban for all schools - Tri-State Alert",
      "date": "Thu, 21 May 2026 07:00:00 GMT",
      "source": "Tri-State Alert",
      "url": "https://news.google.com/rss/articles/CBMilgFBVV95cUxOUzFJaWtFWGxRSnVyWGxIMmhKRnQyZ19XRkpUSC04YXFieGpEZE9CaER6VGZHUDFpOTRtS0Rucy1OaDNpUjVnSGd5bmM3RTNpTWJoeC14YTktY29WVnJxb3oyUU52S3lqQzZ2UHhqLWlmY0ozMzQ0ejd2dTJFYnU4ZGVScDlGaHJ0SFVxV3J1T2NONWxxbHc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Michigan",
      "district": null,
      "headline": "Michigan Gov. Whitmer signs school cellphone ban, saying it will benefit students",
      "date": "Thu, 21 May 2026 07:00:00 GMT",
      "source": "Grand Haven Tribune",
      "url": "https://news.google.com/rss/articles/CBMihAJBVV95cUxOVk15M0ZFZTFLSkhVU0owNWFDalVvbnFJQ0xla25vS0Q3UmY0aVo3aXBKb25VdGxHa0g0cnNMYU5ndnJBZk9YMzgzNkR4eE5yWFF2WldEQ05jSVM5a1NKOWk5Qm5kd29wM3habXBKSG1qbVVKZ21aQjVGX3dBUHR0aEJfcWhQMXFWckI0ZTk4Y1RXRm05Tk8zMzlTaDJpakFoaUJ3eTNYdGVnV0ZjeEJJR2ZHclBXcVFBUzlPXzc1eGVsODIwSjdZNUFPekpmZi1aZHhVbjRTSmxieEozME1WZWw2SHdya05RclpPT0hDc3BIUXJzSDBfR1VVMkF1SmxPSkp6TQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Hampshire",
      "district": null,
      "headline": "Phone service back after outages hit police departments, schools, businesses across New Hampshire",
      "date": "Thu, 21 May 2026 07:00:00 GMT",
      "source": "WMUR",
      "url": "https://news.google.com/rss/articles/CBMihwFBVV95cUxOWHJ5Tk1VMkpsdTJaRzljMmlZSm41cEZ2bEI2eGRqaUR6MTY3Tk5iZWg1MG9DeWtQYlQ5bDZUUmt1dFhHRW9GWjIzUHBTVTl5Y01wQmJmRHFEUFVrR3lMaEtCTlJ6QkFSZmxRVDRmdzR3U1dGNzQycFgyUk1aMkhremN0WE9FdW8?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Iowa",
      "district": null,
      "headline": "RFK Jr. delivers youth screen time advisory while in Iowa for MAHA bill signing",
      "date": "Wed, 20 May 2026 22:46:34 GMT",
      "source": "Walterboro Live",
      "url": "https://news.google.com/rss/articles/CBMixwFBVV95cUxQNFFSejJnNUpHOURFUDJfNURnV1BiWUplVVZleld1T1BoZkp5dFlGWWRUaGNBVS0yV0w1cS0yWTBiN3NSVmVvZEJyV1JuNWdRYWVET2pZbHRHcU9vSklTeU41bExReEctbXlpVkF6YUR5QlZyY090YlhFeDdiODU1ZFBEclJpdTBlY3JZYk9xamt0VC1EZzJCdlY4LUhTRWpkZVg2Vkhja05DdlpXc1NRMnM3UXlTUUo1bHBMMi1xbU5wODQ5RV9Z?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Indiana",
      "district": null,
      "headline": "Indiana Schools Prepare For Phone-Free Classrooms",
      "date": "Wed, 20 May 2026 07:00:00 GMT",
      "source": "InkFreeNews.com",
      "url": "https://news.google.com/rss/articles/CBMikwFBVV95cUxPSkJ3bTJDM2lENEdVMnZkWjBOX3EzeHhGSFZZTTBXSmJPMDdrcVFWMGhPeTVlcmFhQ2k2SjdvWGFLa1NjUk5HTzdodW42MF9SZTViMXhDZ3h0UV9OeFdtNXVqdllERHRqbnBBRm9lNTQzRDJtbU1vZHp4OWJfQjBGYWM1c3l5NVRqb1pNTmNraG5DR28?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Iowa",
      "district": null,
      "headline": "How a stricter Iowa City CSD cell phone policy will impact students - Iowa City Press-Citizen",
      "date": "Wed, 20 May 2026 07:00:00 GMT",
      "source": "Iowa City Press-Citizen",
      "url": "https://news.google.com/rss/articles/CBMi-AFBVV95cUxQLXlVc0RBaWtVaHBZX1pyRzBBN2sxNTZXMGVVQlVSMGFGMHVuNDFfblQ3VmVXZ0ZyTlpjc082LTZmYlZ3VDBJY3pyRk8zU1dnYUNVbjNwVld6bi1uQTFtUmZuUWZEd3hyT0dGNG4xZFZKanVaeGlXM1pBTWxzbHhJVTEtWUF0Tll1VWhPcHVQM3p4cWdSQy1KT2NjT2ZEd2wxaFRiLXFTTS1xLWI2ZUg5Q3RGM25KTkVibXl4d2NReEV6UnNmRnl4VkxIaDZMbWxjT1NLajlYbjRsOWpSZmZ4bUoyTmd0QWdub0laZ280ZkN5SVREWHVQOQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Iowa",
      "district": null,
      "headline": "Iowa limits classroom screen time following new surgeon general warning",
      "date": "Wed, 20 May 2026 07:00:00 GMT",
      "source": "KCCI",
      "url": "https://news.google.com/rss/articles/CBMiugFBVV95cUxOeHZUSzdtc1d0cXJRSV9zcnRITGlyRE5FS0VtSGpFNjZGQnA3aV92b09HWVd6VWNGYndzVC1EUl9yRkc2OGZVd3hiU2FST1o5d2VLcmpHZ2pIcVFYR281ZTdEMEctRjVqdTNJM1dSU1hvQWhmVXFZUmI1TFpId3VDSXVCaGhkTWtoeVNaZEM4Yjlkb3BQYWluY1ZCUlF5blpDR05McGxTREw4VzhMdDFNeDJCSW9HYlFYb0E?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Indiana",
      "district": null,
      "headline": "Indiana 'Bell-to-Bell' Phone Ban for High Schools signed into law",
      "date": "Tue, 19 May 2026 19:24:53 GMT",
      "source": "starcitytv.com",
      "url": "https://news.google.com/rss/articles/CBMi6wFBVV95cUxNdS00WG9FR084b3R3aWhqdDltWE5VS0NBV1lkNlpGRTRlWFFiTW41QVQ3RXZGeEctTGtxcWlyTTdUOTZTUjFpOHRWc1o3b3VlRTJMQVphX2RsNGp0b3NZYXhnY214UmNVUUd0ZnRsXzZ6TVFjRzktY2tobWZRNlo0T0Ziai1QNHhqQjRZX3pfNzFOT3JzZWctSGJ5YUtERUM1N2ZRd1JWcFp4VTB0VU1UWDlqS283d0dUTWg1LUtGeWo1UzNtQ3otWWNmWVN5eXVGdVp1dF9yOHdLdFRKX0hXT1Z2cFVpY1JrZllB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alaska",
      "district": null,
      "headline": "Alaska Legislature votes to ban certain synthetic food dyes in school meals",
      "date": "Tue, 19 May 2026 07:00:00 GMT",
      "source": "Alaska Beacon",
      "url": "https://news.google.com/rss/articles/CBMirAFBVV95cUxQZ2Y2N2I1TjZSMXAzRXhweGVPMFlWY0R5UFAxcU9jTjdpd0F6SUxtRjdrQnBvVlF0Tl9vNXozc19rdWNyM0xTOXFkYlNycERmT3VvSEJrM0hTM1VjRUs4Um9yWmN2YVkyYkpKTmZBQ3l1STJ5Mm55dnJEMi03WVVUMkRGM0FxNW1GdENaT1lxMUNKLWxBbWlDdTVraFUwM3NfTF94a2hPdVZLcDEt?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wisconsin",
      "district": null,
      "headline": "Wisconsin school districts put cellphone bans to the test",
      "date": "Thu, 14 May 2026 07:00:00 GMT",
      "source": "WPR",
      "url": "https://news.google.com/rss/articles/CBMiigFBVV95cUxPVnEzSFA5ZVBIREVTVDRJbUw0X19XUEotNjRLRTZiLUMtRVBBSlJ1YUVzeFdBVkQyQzNLRlVBMW5wSmhLMlFEU2djX2FYbkFqc25FaFM2U1QtQl9ZS0tVWjl4UkNtSHVwOWZJbEZ5eThxcWNIRDB3UzZXWjBkWHl4Z3c2THk4OWJib0E?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wyoming",
      "district": null,
      "headline": "Wyoming Supreme Court Overturns Block On $50 Million School Choice Program",
      "date": "Thu, 14 May 2026 07:00:00 GMT",
      "source": "Cowboy State Daily",
      "url": "https://news.google.com/rss/articles/CBMitAFBVV95cUxNZldQZlhTRDJ0bmpqTXpZOFdnSjFRdU5uWWpURVJ3akNrSUNERU1HdzNieW9QLWxGb1pkQWhIVnFXZlhmUjRhTWVBM01UQXQwNzNOTW5aYzRVX3lVejh1SEdGU0hHVmU5Z1lnaHZUeVpIeXc1TUVGRE9sbm0tVEUycFU1TDNDQnU3N1ZyZThzYzg1Ni1uLW16Q0FMQWVGay1CdEd0Zk5IS0o3U0JxQU4welpNNE8?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wyoming",
      "district": null,
      "headline": "Wyoming schools face cuts to sports, activities after state funding reduction",
      "date": "Wed, 13 May 2026 07:00:00 GMT",
      "source": "Torrington Telegram",
      "url": "https://news.google.com/rss/articles/CBMixAFBVV95cUxPQUtSUlpJTW9yN1V6bGVrbHNmVFo1WXB5TmppZXBvZ1psN0o3SDRyVDF1SGlZcWI2cC1lTlF2UmtqcTdsX0xLX2h2dU52WGQyRUlnODQyLWpCczVORmJxTF9KYS1yTTBOamhjWHJDOXVtdGE5ejFRQWUwQi1ZdTVnTVpyRE1WTXVhOTRJTFU1VVBSREE4OGtTRmpNbVVYZGRHakdieGwzNkpPS3Qzb1hzMzlsQnRpUXhIVWU2d1h1amYwSEIz?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Florida",
      "district": null,
      "headline": "Cellphone ban led to improved learning, attendance in Florida district - K-12 Dive",
      "date": "Tue, 12 May 2026 07:00:00 GMT",
      "source": "K-12 Dive",
      "url": "https://news.google.com/rss/articles/CBMiqAFBVV95cUxQemxoSF9yYkNEVDNkdC1XZlNJd2Z3LVBMY0lEVnBSUEJPZ1czWG45RUMtU05LTVRHNy0yN3YtTGFPeHZGZkdHUUV4VXY2dDctS0hEZ2ZxdFJLclRfNmROdlVuZzNRWmhoNVUtSmd5TjZxT2h3ZlFCdnZQQXNMVjhwbjQ4Z0dWMGZsaXV3akVQcEdNeVQ2Yy1kc1RGYjVVazRXTHN5clFUc3A?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Florida",
      "district": null,
      "headline": "Florida Study: Cellphone Bans Promote Academic Gains … After a Year or So",
      "date": "Tue, 12 May 2026 07:00:00 GMT",
      "source": "The 74",
      "url": "https://news.google.com/rss/articles/CBMirAFBVV95cUxOUVdKNlAzRkM3aG40RWVwTFZmMm9BZ3l2ZUF0Z08xb1NrTTVlc3NueFZyVWtiS0Y2dEE3aUJrX3F0cnZuZC1BQklxcWVDc1BnQmxlSXd1QmE4cW9Ha01nLVowOFdsMkZBTjJXb29XUG5JTWZmdENBVGtzNnVORWdqY3VyaERBczZ0cGpTNWpRdWpidVpBZkpUcVZKR2QyNXQtVnRIQ3BGQXpjVllC?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Texas",
      "district": null,
      "headline": "How is Texas’ school cell phone ban going?",
      "date": "Tue, 12 May 2026 00:19:58 GMT",
      "source": "KXAN Austin",
      "url": "https://news.google.com/rss/articles/CBMijwFBVV95cUxNZW45MGt4YTR3Qi12QS1fTzI0X0V4YWRrWkZwdXljb002czR0b21fTEFudHE0dUs1WnVqNjFEbTFTRTdqeHROWFhJQ3ZQN2FHWXJpRE9HZGtERm44aXJWR25yOXR5aktZVVZ2S3EtY28weFU0RExraEhCaUxWVWRLcDd0bndySnRuZ2xZWUZjcw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Texas",
      "district": null,
      "headline": "How is Texas’ school cell phone ban going? Committee on public education checks in with school leaders",
      "date": "Mon, 11 May 2026 07:00:00 GMT",
      "source": "KXAN Austin",
      "url": "https://news.google.com/rss/articles/CBMi0wFBVV95cUxQS1ozcFBBSVVhVzlVeFlpX3Etb2RodkMtOWtnRjF2bHVjWTV5YUlzelZzVWJtbjQyVThPVzRpb1JrNzdpNGtvdXY4WkZGVE9SQUtwSm9vVUtsTzVQOENqTEdSMmk5QWozNm9IZmtlT2l4QzJUSkFDbkd6T3dDX3BRN04xYWlWTkhSZlFsWXdkR2w4d2MyMGxGRm5URW5IN1JISDVNS0E0WGstR1lLTGhlR0pNRGRaSDRRMVdMc1NmQ2hEc1BBRzJ0elY0Nm9tbjZ4Vm1J0gHYAUFVX3lxTE1DUmU5bFMwNHdTZmx6aWc3SWxSWF9MTTZZZkVFN1lBNk9sMmhndWlCdjRwNGFvdktDX0NtOHJYQUZ4cWRFY1NKMWl3eTllNUNXUGhYYmVGa1ZVT3c5Q09NVVZlNGFNQW80Q0J5dmRndGtVRG9Hc2g4ekZ0aXdBM25yRDdDM3czOVJYMU9TVFl4LUxVX1VhcXRSeDNtUS1hY3lGWmgwVFBoU0tyVWVHX00tNTZMd3V3WkxPaVc3X2pIanAyVEFpS0IwR2dfay00eElnd0QxazllZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Connecticut",
      "district": null,
      "headline": "Statewide cellphone ban in CT classrooms fails to make it to finish line",
      "date": "Fri, 08 May 2026 07:00:00 GMT",
      "source": "Hartford Courant",
      "url": "https://news.google.com/rss/articles/CBMirAFBVV95cUxNSXRwSGdqX1ZVcHhSdmlLeGFrTUEybmtveHpKWndXYXA1RGNJcEpLcDhhcklHR3V6Nk13MEZBYk1EekoxQ1pWanduU0wzSmoyc09TRHZkcE5Cdm9QX1RNdmNBMTRQVHlFVHZPa0lNS0dWakZFMDkyd2RxSldyci1WMlY3bDIyQzI2T0ZHdjR4bnV3YlFTRzRnYXVhbmNVc21tUFFrcUpadFFURnNn?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Massachusetts",
      "district": null,
      "headline": "Phone-free schools grant aims to improve student mental health in Massachusetts",
      "date": "Fri, 08 May 2026 07:00:00 GMT",
      "source": "Western Mass News",
      "url": "https://news.google.com/rss/articles/CBMiuAFBVV95cUxQWm9JUjY2YXNkdXdiMnhJZHFENGtXSlZkRm1Pcjd0ck9VOGIzSUltdnBxd0g5UXM5ckp0eGFhN0ZUanEwUE96ZEhfM2NWUFZSZ1dacWx4eVFuVjR0VG5jRDVpR2xCOEx1SWJ5OGZaMHRRVzBoQWRoMkpyT3N6S3RxdFBjT3ZvTG1zZ2JLZ1J5TWkzX09wTEZ1MnJJNXA4Znd6NU9nT3VYUjVDTnBfc0hnRGFXOG8zNkwz?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Montana",
      "district": null,
      "headline": "Report finds mixed success for school cell phone bans",
      "date": "Fri, 08 May 2026 07:00:00 GMT",
      "source": "Montana Public Radio",
      "url": "https://news.google.com/rss/articles/CBMinwFBVV95cUxNcjJoaTFTR2tCNkItZEtfREV4TXFlU2pQM2d6b3k2eDhSTWRWa2pBM1MxeWpmdHM0UWI5RU94TlJZZ1RiUWpvdERGTDdSZm12OGdQUS1MLWdLNFplQWJNc1k5clhicnFEa0xXY05wUXlKQnFFT3UybERKMUx0VTFzZERBUXNSSTRWSTkwZm1jSEVVTW1kS2RJTGF4NDZkbXM?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Connecticut",
      "district": null,
      "headline": "Why a plan to ban cellphones in all Connecticut schools fell apart",
      "date": "Thu, 07 May 2026 07:00:00 GMT",
      "source": "CT Insider",
      "url": "https://news.google.com/rss/articles/CBMiqAFBVV95cUxQZXNoLUU0TDg4OF9oMzM1T1FBdjhyS21lelFxa2dHY24wNlBBZmJkMXlJUzhqM1RXTk9EQ1JPb3dQam4wRTNOX1FhaTFJcHRLWkU3TGl1OFIyLV9wLVhvSzNKZHFMZDRkajZKekZvanh4SWVCbnk0SHhWekhlWnV2ZlFoNTRUTG1wVVdCRVcyRzJlanlVV2NTNHVwR0JXVkhlSURZdWVqRTQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Connecticut",
      "district": null,
      "headline": "Cell phone ban bill dies in Connecticut Senate for second year",
      "date": "Thu, 07 May 2026 07:00:00 GMT",
      "source": "WFSB",
      "url": "https://news.google.com/rss/articles/CBMikgFBVV95cUxOOUlHcUdBLUxnTE5HeENUXzdSWlZ5SXI4Z19MUDZuX3FZR1NtV0Q0M1NQVWIzY0hLcjNpcC1uU3pFTlBaQUJzOXBzZVJucVhiUExxR3VpWVJRS0tYMktJWnhzTi1id3lHemRZUUhsTUsyandPWFhhaVozLU0wUk5TUHdUSXNLdHVhWWtXcDllTFdwd9IBpgFBVV95cUxQTjg3ZFBreDgzX1NxNV9pT0xneUpORE1xS2pHeTVHdG50cnNiSy1KX29odjNEOEtEdkF5SFQwUk1hMWh5WTJjVnUyTlF0OTd1WjdDVTJ4bWJKcXBqMDMta3puUlQzeTNfZVRHRGUyYWJNc3Iwc2dqTnMwcmctcVVSYnY0a241Xy1ZQkNkZC1vaDhSQUxpdko2MFBsX3VTekoweGIxa3dB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Connecticut",
      "district": null,
      "headline": "Legislative Session Delivers Major Wins for Teachers and Public Schools",
      "date": "Thu, 07 May 2026 07:00:00 GMT",
      "source": "Connecticut Education Association",
      "url": "https://news.google.com/rss/articles/CBMikgFBVV95cUxQOWp6ZFphNll2LS1KM1Q4MTg1THBUSGtUVXRaNEVMUFptOWozZHlWcnVpcGwzWnZySFpkOFU5YjZsb3Y1bThYVy1Fc0lJZ09VMldiY3Uzek5faDlJMVlvdjJJaFV1ZEh5MlZsNEtiUF9SWXo3dFNaMHRHTnBVaG83a3RHYzZibjJEczBlN0lLb3ZBZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Connecticut",
      "district": null,
      "headline": "Connecticut's School Cellphone Ban Bill Blocked by Senate",
      "date": "Thu, 07 May 2026 07:00:00 GMT",
      "source": "govtech.com",
      "url": "https://news.google.com/rss/articles/CBMimwFBVV95cUxQamRhY3h3ZDc1a0lxR2NuTzY1bDhuRjg4MjgtdXRtSDJGVDhNOElQQ1dPbFFBMzJxRU1VZ1VqZ053OEl6ZjViZXNtRFpzcnVKbmR0M1ZNNnFObUNieEN0amZQSl83SFRMLXpZZnM1VzF3dHliRmlTLUU1SjFkUm1ScldTaU9yLThXVTdMdkNHZEI2bUNjbUV5WDBjUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Colorado",
      "district": null,
      "headline": "Don’t take their phones — total technology bans are not right for our Colorado high school students (Letters)",
      "date": "Wed, 06 May 2026 07:00:00 GMT",
      "source": "The Denver Post",
      "url": "https://news.google.com/rss/articles/CBMif0FVX3lxTFBXSG1ITE1yMVNGZmZQenlPZTBqcHV6d3doUVJqbG9qS1ltcEtrVGxvZm1mWVowaVI5R2ZVUmtySF9RNTZiTnF4b25lMFVUYjJuSjJybzQyeTNHTFl1Vjk1WGZrRkl1ZkhxSWNKcGs5QW1jMXZuTmxmRElxaERabjQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Connecticut",
      "district": null,
      "headline": "Ct Lawmakers Drop School Cellphone Ban On Final Day Of Session",
      "date": "Wed, 06 May 2026 07:00:00 GMT",
      "source": "News12 | Connecticut",
      "url": "https://news.google.com/rss/articles/CBMixgFBVV95cUxObnVSd2RyNVExX2U4WTdOWENGWmtGaWRheGwxYnpXR21VY1M3RGJwNldDSEd0bG1ULXZ4bDFzWXZiLTc1cDNELWVlcDh4NEpueE9NdnRvMGMwRUR0S0JubDFqVmxNTzdjWFl6UWR4Y1JKR0VEZTNaZ1d0WHBwU213SXhDc0l6aHBkTFZzMUFpRUpkXzRMTHJQaW1zc3Z3VjB5SE9ydzZnNGlxRnNKV3pYVExvdzl6SVh0UkFONHlRZUwydW5HbEE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Connecticut",
      "district": null,
      "headline": "Lamont’s bell-to-bell cellphone ban expected to die in Senate",
      "date": "Wed, 06 May 2026 07:00:00 GMT",
      "source": "CT Mirror",
      "url": "https://news.google.com/rss/articles/CBMimAFBVV95cUxNd3ZpLWYyWWY5d2NudWljY0RjY2cwNEZvZzIyemJPSm1QVEYyUktmMEVlM3VDNWFqRHN0a09yNVBIWkhDYWR1MmYyNHNaSWJta2NPTFVWUnZzWFdWRlVXdWF0ZllWSUp5NUpOSmNvcTBwcnlJY2E4bXFzMU5EQlZ5NzBDaWRvOXJnRHZ6UHpVcms1QXpQaHROUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oregon",
      "district": null,
      "headline": "In-class screen time is the next frontier in the school technology debate - Oregon Public Broadcasting",
      "date": "Tue, 05 May 2026 07:00:00 GMT",
      "source": "Oregon Public Broadcasting - OPB",
      "url": "https://news.google.com/rss/articles/CBMiqAFBVV95cUxOWG1MeUhjOVoyUzlZLW5hOWlPSzUwY1A2YUROekVnS2lXOXVsei1HbVczUWdVclpCVzVLLVBLUWFmVEE5MmpJdW5MMjQ1U0xGSlV6bGY3QVBXUzlEQk1ueXp5VWkzSFVFNWNja3c3MHA0LU9rMkNOeGVwZTlNRXlFM0dnd1hkTXdfXzRsT0FheElGT2ZNM0x6N2dhb2VFWWgxS1B2R3pnd2Q?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Vermont",
      "district": null,
      "headline": "Three Years After Refusing To Play A Team With A Trans Athlete, Vermont School Wins $566K In Settlement",
      "date": "Tue, 05 May 2026 07:00:00 GMT",
      "source": "GO Magazine",
      "url": "https://news.google.com/rss/articles/CBMixwFBVV95cUxPZURLZUVsc2xPRkh4ZmpuRnFoemRSUGpTeDRLbjlOOEVKVGhSTnhOdGo1MW9jb1lqU2RxUnBlWGN4SDgyT1lETkphMHhNb3d6VGtYeXd3eFV0Z3dWcXRXaHpicjhYUk5hWXpFbVJSV2EycFJ0Qi1DRnpRYjItMzFMQldQUHZScWkybUY4V29lYW5BZFdGREhqV2dCdGVGV2EzZmtMaGc3Yk5paFhkSDlEc194N2VhenEybmQ4dWMzU2NYZ3hock5n?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "West Virginia",
      "district": null,
      "headline": "State Begins To Collect Funds For School Mobile Alert Buttons",
      "date": "Tue, 05 May 2026 07:00:00 GMT",
      "source": "West Virginia Public Broadcasting",
      "url": "https://news.google.com/rss/articles/CBMioAFBVV95cUxNUkw1TlNnOG1VQUxrT1UxRzBqdlM5VkVyTlI3VlBocHhrWG1QT2pBSEZpNmJUNXV6MF92c1VieTdVTGpySXY2SFl3ekNjdGkzbDBIdnduemp0dG5nTjJRT3Rzc2NwaXctUjFsUmEtWVNWOW1Ia3V0Z2J0YmgxLXdrck9QaUhnQkZGQ2RwbEMtMnJUeWhlOUhUdFVTQzdjSG9S?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nevada",
      "district": null,
      "headline": "Is Nevada's education funding on the chopping block in 2027 if the economy dips?",
      "date": "Mon, 04 May 2026 07:00:00 GMT",
      "source": "The Nevada Independent",
      "url": "https://news.google.com/rss/articles/CBMiuwFBVV95cUxPOEdibk5VUVRLNHRBR1FYc0xydEJUWDUzWG43RHV4OGd5S0Q3bzU1aHpQa2k3S29pbXZpV0toMVBieWczQkJkcllRMnVIM04xOGtWTXBWaVQ2WWpwTDRUdTdsNEpmYXV4WlhrcHFaWWhNVlRfQXdHTzhvMnA5V3JheTVVU2E5Y2k5c0hJODQtd0FqU3dUX2g2STZGaXlteElXUU5ITnNTNjNNREtTcFA3ZE5mRkY5T1ItcmFZ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Louisiana",
      "district": null,
      "headline": "Several states — and the LA public schools — are setting limits on screen time",
      "date": "Fri, 01 May 2026 07:00:00 GMT",
      "source": "NPR",
      "url": "https://news.google.com/rss/articles/CBMiiwFBVV95cUxPZ2JhbGlXOEJPcXJpR2UtRENYZG5HemMtdlVOa3BZdm5oaVVwaEtybVpGd0JpaVJEdUVmZm5VeHFiWW93ZEJDamhKc2s3azViZF9yM1c4bXB2TF9BeXNJTjA0U1dRUEIxUm8xWUhxZkNieFJqMFBNQ2J2TnVMbVMyRDFCLURRQWxReGY0?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "West Virginia",
      "district": null,
      "headline": "West Virginia school system goes virtual after two days of bomb threats - The Herald-Mail",
      "date": "Fri, 01 May 2026 07:00:00 GMT",
      "source": "The Herald-Mail",
      "url": "https://news.google.com/rss/articles/CBMi2wFBVV95cUxNT0tUTEpNZTUxNFZMblNrTS1TVV8xRHpTZTNmN0FpekNubzZTTnlBSGx1UDZ0ME9Cbi1lTDF3RlM0Z2h5YkIxdmNQODBtX1Q2VlB0bmdId0h3Q2JYc2NfMTc4NmlFcHphU1hpeTVsZVdoUzRrM19aaHNYTVktZHVHc3RSR1lNckZQUDN2ZzhXWHRYYjRiQl8wUC16ajAxTGkwY2E0LUtlaFZ1UGtvRXZrR2x6S1hGNGxHUC1qT2tPYVotN3gweW9SRElwTlFEb01Tb2RfY1JLZ0J4YTA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Montana",
      "district": null,
      "headline": "Montana State STEM student admitted to prestigious pre-law program",
      "date": "Thu, 30 Apr 2026 07:00:00 GMT",
      "source": "Montana State University",
      "url": "https://news.google.com/rss/articles/CBMiowFBVV95cUxQMWJUemNfa285SGdnLUwtTkJYUVBKMmptR3RFV2dVdEVXUzRVTUlHTzFlc01BWV9QeThlQ0YxQkNUT1B6RWYyZkRGeGZnWG9UT0VScGJ6WjNGaE9xMVpjN1g2c1N4SVY2WnpNUG5CTFhuMzBGQ2Z6SlY5X0NJcUI1SUNUS2VQUS1VT2dKaXl4VjZCSU9KY2ctbjhPdFh2SENOV3Q4?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Texas",
      "district": null,
      "headline": "Public schools in Texas banned cellphones. One district has already seen 200,000 more library books checked out",
      "date": "Thu, 30 Apr 2026 07:00:00 GMT",
      "source": "Fortune",
      "url": "https://news.google.com/rss/articles/CBMiuAFBVV95cUxPcVRuRmdZd0ZGVUxBa2JUNG1pTUs0ZUtMZ1lCTWZreERGQnIteTJUaEZEV2NQbXJjOUFOMFAxaDdZeEVZQXlRREd4bm1aWFRwWUduS0hpR3VNOGt5ek84MXdzT195bFBlUFlCTG42OXFrT1BBdHJ3NjhPaE4xc3JSZXlBcV9zaVA3Q20wRVJjamdtRV84SXUwakFXYTM5bU8zMk9tQkhHM0tmTWs4b1F5N1ZjcWxrOVJL?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Virginia",
      "district": null,
      "headline": "Fairfax County Urges Parents Not to Give Kids a Cellphone Until After 8th Grade",
      "date": "Thu, 30 Apr 2026 07:00:00 GMT",
      "source": "Northern Virginia Magazine",
      "url": "https://news.google.com/rss/articles/CBMi1wFBVV95cUxQOHZVbm5WaUJjVnNHVklWQ3M0WEdMUlZWX0RZU0drcmNDRnB3cEppbDB0WjNiQS1QdGdyYVM0TVdRUzJXZjk4a3dGVW8tanlBNFZZdnNQSnRtM0owNjNLLVY2OEhsYU1IYUxBZzBDb3FQVjdtWDZoS3dnRHU2NFBoSjBRVzItWm9xUS0xWUlHbzJ3a3dCblFNVkp1bnZPSTAtYTRPdnhnN2ZxakhZNS1GZFk5eEJGbVFwemxQOHd0WGVNRVJUU095dE1rcVdRdEZuY1k2X3pxSQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Colorado",
      "district": null,
      "headline": "Colorado’s school cellphone policies are being decided right now — with or without you (Opinion)",
      "date": "Wed, 29 Apr 2026 07:00:00 GMT",
      "source": "The Denver Post",
      "url": "https://news.google.com/rss/articles/CBMickFVX3lxTE9FVGRXVGVrSkdWOF9Oc2dRRDhWaVM2c1VGWnNTY2tNOUpsbFNrb2NJcGRRcHoySWsxNU8xOHdxZ29FS211QXoxVTJFa1Rja2J4cDlGZFRSTHFCU1hjeXBZTW9ITzJGY3o5ZnE1b3NTYktydw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Hawaii",
      "district": null,
      "headline": "Bill to ban student cellphone use in Hawaii is shelved - Hawaii Tribune-Herald",
      "date": "Wed, 29 Apr 2026 07:00:00 GMT",
      "source": "Hawaii Tribune-Herald",
      "url": "https://news.google.com/rss/articles/CBMitgFBVV95cUxQUDJIb1JfTnh6VDRuVld2dkt4bWN0bS1GVFhHUkduYTNIdWljSHJtdmRwUG5mOTB2TWF1aGRlcjZRcFJLQmJZTllGTWlicEV1T0NGZUJlOXQzQW95eDZhRExNLVUtOXZHcEtlUmRPYXNJYzJqN1A2cDBtQlNoRThqakhUbUtRQm16NWQyVGpleTV5RU5ha0hxYVJoRVZfcjFpaGhrMnRNUjFnSUZ2NXBab0hRWmlNQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kentucky",
      "district": null,
      "headline": "Banning cellphones in schools by law: How it works in Kentucky and what’s ahead for Indiana",
      "date": "Wed, 29 Apr 2026 07:00:00 GMT",
      "source": "Indiana Public Media",
      "url": "https://news.google.com/rss/articles/CBMiwwFBVV95cUxOOHR1TU1rY1E4U3VVNlR1aHJZaFkweEhscjM3THBQYUhWb1l1NFhBcEZRSnFOTFJJdW5McWZXemctbUFQQVVucjZKUlpuc2dHdzZ0OElFZkxhTjhNcnRKa1N1Qmg2T25sd2RaVWNhQjZuT2owc0lVME1xbFdwN0FUNTdZM3Bidmw2end5SWxRSkJ3QmVHb1pYVHhrdGoxT2dRNGNsSVFVTXhWcll0QjFrUTFrdkVxa0QtYXNOVktBMDg0MU0?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maryland",
      "district": null,
      "headline": "Maryland General Assembly passes bills to boost AI literacy in K-12 schools, higher education",
      "date": "Wed, 29 Apr 2026 07:00:00 GMT",
      "source": "The Diamondback",
      "url": "https://news.google.com/rss/articles/CBMibkFVX3lxTE1NcGFrLWlYTDlVbDFYYmUtcC1YM1pzNWFsZVQ5YkhxQlJ1MTRMRmdUTHNldGM0TTB6TDhIMzNpcUxmdHhnQmxRUUxmdkxHbFl0akY1bmRxRXZodDRuNUEyQmRxQ09PTmZLZUtxUEZ3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nevada",
      "district": null,
      "headline": "ACLU asks Nevada Supreme Court to reconsider ruling that keeps some school police records hidden",
      "date": "Wed, 29 Apr 2026 07:00:00 GMT",
      "source": "ktnv.com",
      "url": "https://news.google.com/rss/articles/CBMizgFBVV95cUxQLXhJeTc2czdiU05QTm9VTVlwYVVKR1owOUJlVTZvQXZYSnJFNFd6TG54dll5S1ZrUk5BRWRMTUhvTTNuLVRQWllGQlhzdVBfUG1lMkhPQkl6ZDAyLVRQdVI3ZXNTc3JWNUpJYXFxa0xNSFQ1QzlYQTMwU0prU0dSdlY4cFhIN0Ntc0hvQU9RWlNiRDg2MlhPWVRWR3JZV2tjb3plVkFLZnB0Q3c4Z09yb0V3YkU0QzlvUVJIRlFxajFoNDdtUm5IR2lvOFZsZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Texas",
      "district": null,
      "headline": "It's not parents, but Texas that hovers over school districts - San Antonio Express-News",
      "date": "Wed, 29 Apr 2026 07:00:00 GMT",
      "source": "San Antonio Express-News",
      "url": "https://news.google.com/rss/articles/CBMivAFBVV95cUxOZTBUMU9CV1JNemhSR3BtbGg0RHVpQmItU1hIdGJvRUtFSl94dTBPalg5NnNGTGpoTFpvcVFQb0ZEYkdmaERfRThZcEdSMTdiTFpXb3JoQTFFcEJ4azlPYThSZFNoMkxkdzMtOS1HMTgtalpyeDBvVktQX1ZBOFpXZTdVSXFMS2k3V1F6Mnl2REJfM3BMRjdkSlFwb0p1LTE1d2h3TGIxMFFkcS0za0dFTGlRNXd1eGZ4WURRbQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Vermont",
      "district": null,
      "headline": "Effort to ban artificial dyes in Vermont school food falls short",
      "date": "Wed, 29 Apr 2026 07:00:00 GMT",
      "source": "WCAX",
      "url": "https://news.google.com/rss/articles/CBMilgFBVV95cUxOa2E3d0wyNFRpV1BTcnpLcGd4SWhhdE9tNlJVUDFvZExoUVMwQmtUcDBQTk9oRTZHVEE2T09KemI4TVNqY3BNaDB0QktwbjRSbUNzVVVRY2J3VkdjdHd4S2RiMVFVSTFLajd5MVNHLWJvNGw1NElPcEY0c2F3S3VfYmgxQk42RXpfa1NTaXY0Y2ZnY2JtMnfSAaoBQVVfeXFMTnM5Tm9WUTU2bGgzNHUtck5RMzVILXkyNXZ1T244YUFORW03V3VCaXBxWThpZmhCUnlWQWNhaTNIQjI4dXBpZk5zVHcyRU5oanZIWWJCYVZZMm1WUTVUbXh0ZmNDcW16SjZadXhLeTk1MTdKeXZSNU1aQkc5LXFGdFRlNnowNnZDTVhHQXRWM3QxYU1HNGp4SElEREs4REl3SW51SGl4X3g4Rmc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Massachusetts",
      "district": null,
      "headline": "Massachusetts eyes limits on student phone, social media use",
      "date": "Tue, 28 Apr 2026 07:00:00 GMT",
      "source": "The Worcester Guardian",
      "url": "https://news.google.com/rss/articles/CBMimwFBVV95cUxNeUtSNGVtZTgyaWQyOWUzWHpYMk1mNjFjQUZPZElCNnQtUWRrZjBTak5ZNjVsMmFMUno3T1pJckotbkUtOXpKdnhFZ0lPc2RaQkRwU3FrTjhJQ09GbTFDY1dVNFVFTGZKZ09fM3VXeDNaUXpMMDFkUXoyNXpJSjBBZy1KQjhReDcyWUd1a3ZWemNWb2ZrYjlLNDAzUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Texas",
      "district": null,
      "headline": "North East ISD votes to change its cell phone policy to comply with state law",
      "date": "Tue, 28 Apr 2026 07:00:00 GMT",
      "source": "Texas Public Radio | TPR",
      "url": "https://news.google.com/rss/articles/CBMiugFBVV95cUxPYWNHRzJHaUlqMVVISDJ4aWlhRWJ6Z1VVcncya3BCcnlVNmN1MXFYenlwQXdqOHVTY3V5QUNIWk45TWNWWUtNcXJRQWx2X21aazNoc2lXSWhDcUdLZUNhSnpVdk9qUm9ZOUFMZWFwbUcwYXZ4UGNQR3AtLUkxdnlLR0FrZ0wzd0NhVmUwX0d1QWlSOWNwWjl5Vk92b3loZkhvZ25MWGFGX0ZDRjF2dV9nT0VCdzM5WmJDVmc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Vermont",
      "district": null,
      "headline": "Vermont pays $566K in damages, legal fees to Christian school it banned from all sports competitions for years",
      "date": "Tue, 28 Apr 2026 07:00:00 GMT",
      "source": "Fox News",
      "url": "https://news.google.com/rss/articles/CBMiqgFBVV95cUxNV2pVSW4yVUUwZmJkcUo0blFkTzlNVkRSYXpBUkRKbC1IdVZ2ajliUkpPZVVfWW11aWJHNThNLVhjdVBObWV2VXlXbU11SUhzWHpfV3ZnOU10MU9UeC1qQlJ4OGVqQ3RDcFQ4anEtUzB3cDNzdk5vbVBwTFRTRXV6NFdNRHZzSXZJRGdmV3RUWmNBRVA3ZFZzOUhEWHZzZHFEczN1aFYwQXJFZ9IBrwFBVV95cUxPejcyYVhZbFZITVZUeGlyUXowbFoyTWh3SlRWM25DMmFJRkU1cVR1LTd1UDZURDM0aFBiWlc5ZXhOYXJyV051ZWV0SmtiZkh3UjJ2aS1mOHJTX184YlZJOUxmbG1RcEhsTGJuTEZRVENvX3g4Y0VKSFFKNUNwY3kxMjAzWG10c3UxQVJVZVJnYnJyVWpSdVNpUWxtdk0yN1d5UXV5bjFPZ21yOXg2ZmxB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Delaware",
      "district": null,
      "headline": "Wilmington elementary students will hit their own airwaves",
      "date": "Mon, 27 Apr 2026 07:00:00 GMT",
      "source": "Delawareonline.com",
      "url": "https://news.google.com/rss/articles/CBMi1AFBVV95cUxNZEdTZTBlMnZvQTNoU3d3a2ctLXd4TUttMFJFd3d4Qlh2Yk9tVmhhUjdvR2FMb1FOUzVKeldUaFA3RWNuN0Y5TkVhdDdxdUFRd0d6M2gtV2hSQTgyRFJXLTVrZ0xsSEZGLWNvUG1qRDdXZHZRSGowUWtjOFJrOGU1TjJnRFRYSDM0ZGpXQk1GUF96bVhZc1AwdERHWmNwcXJheW5tUWpWQnNCbzRfNGRhakd2emdxd1Q4WkhWYnZTT0hSN1lRbnBYM3JhTkRQTjFtWS10NA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Michigan",
      "district": null,
      "headline": "Report: Michigan's new cell phone ban doesn't go far enough in schools",
      "date": "Mon, 27 Apr 2026 07:00:00 GMT",
      "source": "WCMU Public Media",
      "url": "https://news.google.com/rss/articles/CBMiuwFBVV95cUxQOV9NcXRDc3VPU2N6cnRSdTlfbDdXN3pJbllZdFQzUlZhVmtqMlZDYTZyMUF5YzNXQ1Axa2drQjVkM29NSC1KcjJMV0pqVUtYUWVISDh0V0Z4MExoMVVEZm5kWVVRbmd0SnEtdjFhai1fVkE0Q09kSVJZZmVyQ0Z0akZoUk1JemFxMWg3VjkyM01tVUd3MERDSkVtcC1lYWdueUdSc0ZIUXl3VlVNdUcySS0wdTNOV1R4XzFR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Mississippi",
      "district": null,
      "headline": "Mississippi middle school students stop bus from crashing after driver blacks out - NBC 5 Dallas-Fort Worth",
      "date": "Sun, 26 Apr 2026 07:00:00 GMT",
      "source": "NBC 5 Dallas-Fort Worth",
      "url": "https://news.google.com/rss/articles/CBMipgFBVV95cUxQdEVwNnpOTVhHazY5SGtiUHpvZmFpRnZvdVF0OUxSSmZYSERIR3cwZjhkS3BxVUVkSW81eFk1OUJFLXB1dGhrTkJvTEZCSUY0SHJVTzF3M2dRODNIUk5XR213ZXBWeURqZjhMMGFQNnhrX3ZXR18zdk8tVWlpdERGLTNwYWlodHVqQTJPX3FCUXptMnFOMVhRMjRGcG5wb3QwNEMtNVFn0gGuAUFVX3lxTE9hUTcwX3I2c0NZLV9NUEVITFhwRGJfQXd1bE0yLWVKa3FaUlRKcTBWZm9YbnFKMnp2MldOcFRNZ3A4V2wtR3ZzZDBRbXN3cTV1aFRyS0NBT1BiSWRWLXhFb1BWMVV4ajliQ3ptYUZxQnZDTDQ5bHM5QmtwakRXX3ctVDBUamhaZUxvWXVIa3FpQXZROFhKYmZXN0RyY0NqZWFsTk12VnFKdk9YdEVVQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arizona",
      "district": null,
      "headline": "Advocates step in to help families of students with special needs navigate Arizona school closures",
      "date": "Fri, 24 Apr 2026 07:00:00 GMT",
      "source": "12News",
      "url": "https://news.google.com/rss/articles/CBMiowJBVV95cUxNUklSOXE0OWJ0clp2WUp5RVhpRkRjRmVsQlF6bno5ZGNQWlNNaGJnOG82M3BVY2VPMnNkVjlCYTc3Zkw5TDNtYVRjNjNvT0Eyc0ptMnQwdGtOU2JhWVhUVkxQMUdncjdra2MySlhPb2hmb2xhNnl3VU1lWDZXelc3b2d3SHhGX2hvci05N1NKdEsxT1FmdFdOM19DMWxlY0lPVGdTWG02dU5VQTJQZjNWU1dfWm5KdTc1NWNzOS1CQUxCZWJsa0R0d1ZCQk5BQldicXZ3VkM4RkxfdDI2RFRVV21hYmdiS2FOdjcxOG9lM3U1UzVuUHVSRTRQNEF5WFctSHlYbWg5cXRfNTYxQnk3YVlNd0h3ZThTbDBJSVNpWFMzV3c?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "California",
      "district": null,
      "headline": "Proposed smartphone ban for California schools changes tone",
      "date": "Fri, 24 Apr 2026 07:00:00 GMT",
      "source": "Courthouse News",
      "url": "https://news.google.com/rss/articles/CBMilgFBVV95cUxOMXlnR2JSYV9WU2pYNmlpcU1qcXZFcEtLOG9HYl9KUzJ6eEQyamR6aEZJM0pRUThqVS1GQ1BScW91cnltSk1ob1h5Y1RoYkFlNFh4dnNfQUdsaDRid21yTlNfV2ZoVUlNWWw5ZUR6Y01TUkxzbzRFWVBCbnVhNmNiX2Z3NVNBaXdyWUhHcHpnZldqQXpXSUE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maryland",
      "district": null,
      "headline": "School districts say Maryland General Assembly phone ban bill undermines their authority",
      "date": "Fri, 24 Apr 2026 07:00:00 GMT",
      "source": "The Diamondback",
      "url": "https://news.google.com/rss/articles/CBMifEFVX3lxTFBsdy1tS09SMS01Z1lXaWczakFIYWcxUHI5MlQ4c1k5T2FaUFU4OWYtSVZWRkloTWp2YXE3X0sxQnNGVlF1NTNSd2hhM2JqYkZFeEJrajUtZHBkalBFeWZndWpMcWhYZlZQVDI4VUp0U2tPcFNCb3ZDWGw4Znc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "California",
      "district": null,
      "headline": "California tests limits of school phone ban movement",
      "date": "Thu, 23 Apr 2026 07:00:00 GMT",
      "source": "Politico",
      "url": "https://news.google.com/rss/articles/CBMipAFBVV95cUxQc2hsaE9vZXdoZEJNbjF1TzhwUDFnN2J0R0xjSTJySlhmbHJKcHQxTWE0Y0RzR2JmLXlOLThyQU11V2xERUZPMzdBTVpTTURCRGlNSTN4WW9vbTA2X3RDN3M3eEVCdFhiaGFjeDhDdTBhbl9JNnJYUXpVWU5FQWZXNFpBWlBJM0o2UzV4ajFLQ2MzRDFQY3pOVFFnQUhoVTJodEJDSg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Mississippi",
      "district": null,
      "headline": "Mississippi students test their financial literacy",
      "date": "Thu, 23 Apr 2026 07:00:00 GMT",
      "source": "Magnolia Tribune",
      "url": "https://news.google.com/rss/articles/CBMilAFBVV95cUxPWG9YQTZoZThUbE41MTdYTGRFbUNPVlFreTdPUjEyZVlydFNoWTFvbUw5NjcwekVxTGczXzdieTd1Mmd6cFB3UndFSi15TV9heE9kVEZqV21sQU1zMWFEWjRmdlk3d3lRZTJDaExXR1oxOE5RTWZMRkx4anhOclRmVU9LVldnSG51cG40WFI3VF9NbUlp?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Louisiana",
      "district": null,
      "headline": "LA public schools pass screen time limits for students in a first",
      "date": "Wed, 22 Apr 2026 15:15:20 GMT",
      "source": "Mashable",
      "url": "https://news.google.com/rss/articles/CBMigwFBVV95cUxNMnVFRFJiMXZKYXlTRHdLUnlOTTQ5Q1BQMlRsYU5LMk1uN2d3MzNGUlVGSEx4cFVRZFhZOVpNb0lRR0twcmNPOVFMU3JPbjJnRHhHYnJIdi0tdmxLZ2l2MzQ5TllhOWoxN2N1WnBsLUpELUk3TmNnMldpU1I1MDJZU0gycw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arizona",
      "district": null,
      "headline": "3D-printed weapons are showing up in Arizona schools, investigation finds",
      "date": "Wed, 22 Apr 2026 07:00:00 GMT",
      "source": "12News",
      "url": "https://news.google.com/rss/articles/CBMiiAJBVV95cUxQMU5kd005OEppNFRaSHVZSXlVRmJ5VGp2S190TVNhWWc3eUpwdFNoRGg0N3pfT3h0elFWcTR3VFVsZVE5d2RIUzRVNmRST18tWHh5eThvODlRdUFQTDhYVHg2Ty1nbHBXaFJkbzkyUkhIZkxER205dklZZ21XeTlLb3I5VmcwM3ZQM2d4UjRoS0tfaWlyWHdxRFVHV2I1TVRqb1h2RDZCMXA2cFJFZTBqRmgwZ1UwNlR6a0RJbktaMlJjeFJMM2lVc01vOWx1Zm8yenRHMEIwWDFwVmdaS3lmUThVeUxBWXlCNWlROFNiZTVyeEJua0pyUGlpWU4yS2NXcF9GWERrNmc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nebraska",
      "district": null,
      "headline": "Nebraska Passes Special Ed Bill Without Proposed Protections for Students",
      "date": "Wed, 22 Apr 2026 07:00:00 GMT",
      "source": "The 74",
      "url": "https://news.google.com/rss/articles/CBMisAFBVV95cUxPRllORVNaYmJVODE0X2J4d1hLYzNQb2Naa3R6Q0hpVEhRRU1vVzVJSFZPVFBNU211RV9Pa2owWXNNeXNVWk5wTVdKLURud1BZQ1p6Q1RuekN6YzdFNFJuU1dqRllUTjZ1ZHFSSnpaYWUzb2ZJVGFJak9veWJBSFNKS2NRYW81Z1FmUjNBRWxEQ2VWMGFzUFU2Zzd6a2oxVzE2ZDNoZGZKZWNuQUxTdkVKZg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Louisiana",
      "district": null,
      "headline": "LA Unified School District Set to Limit Student Screen Time",
      "date": "Tue, 21 Apr 2026 07:00:00 GMT",
      "source": "TODAY.com",
      "url": "https://news.google.com/rss/articles/CBMioAFBVV95cUxOUzJfOVF4cGg4MkgxUWtlWmZxYjFHV29ycEx4V2JKUEo3eDFYa01rUDJYcGpNVXJUVVp4S3kwYTVuZ3p3UGxHMnh1ekRnQ2ZvYThkY0lqclZCX1NrTUQzaGpLMkFrSWZYSTdCNmJfTE5UWWtNb01LVzhvUXhaUWZSdWh2MkJwVmdNcGw3T1Q0MTE0ZnZJRTdrRW5CdEhRWGdU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wyoming",
      "district": null,
      "headline": "'Threatening' phone call that led to April 21 Wyoming Indian Schools lockdown posed 'no imminent danger,' Superi...",
      "date": "Tue, 21 Apr 2026 07:00:00 GMT",
      "source": "County 10",
      "url": "https://news.google.com/rss/articles/CBMi3AFBVV95cUxOaEdKdEY4b3NMbkhFMjlGaUxnQWxRSUk0NTUzcmlzMWdrRVMzQnRuMFY4OVRzRElTblFmMlVYRWdaNWk0eU9WbDlfWjhlM2lNdVdHeUZpa0h2Qnhjb0VvRnNTd2syaUpYTHFKZGhnWGVrOWFHd2dMbXlHZkxzNVJZVEdFUzBiSGFzNGtORUw5ZlB0MVlzSFh4MVlQWVVKdHFUdjduWVdaakJ0b3NUOXNsaDhOTW9ob2l4TGw2VVcxYlRrR1Z2NTNoSHJtZjFUb0RMS3U5bjJGZEZCWDNV?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "California",
      "district": null,
      "headline": "California students author new ‘digital wellness’ bill, say school cellphone bans fall short",
      "date": "Mon, 20 Apr 2026 07:00:00 GMT",
      "source": "Times of San Diego",
      "url": "https://news.google.com/rss/articles/CBMingFBVV95cUxQX01paG45WDJkNWEzUGNoeE00M3lMekt5b0lXYWt5NFJDd1V0ZWIyNUhtVTh3eVE2TFlYNjBxdzczVXo2ZzlLSk9DTGQxTzlzQWdFbDItcWJQc04zTFpKREhoZ0RvS3FudnNRWHJyU0FER25POTc0T2licmJMeDBmck1pNm9IQ0RRRWdvUHdEam93U3JsSTdyckxHTVlqdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Montana",
      "district": null,
      "headline": "MT Outdoor Podcast: Transforming Students Through Archery in Montana",
      "date": "Sat, 18 Apr 2026 07:00:00 GMT",
      "source": "Montana Outdoor",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxNTG5kMUdVUHFnTlYzblF3UEg1cmF5LWZIRGhiQ2Z1SFVucFJmblRncV91NVVTV1dzcDEwd0tveUlVaXVHNFB5VFVGbFhnYlZ4ZUNKX0o3UjNJbWdkQnV3ejg0Vy1uS2dmM21BaERQbjRHM1A4VzNJS0lNcGFzRHhpVVFwMUkwVk1GTFBrSnFORFhzcW5lUDJTa1pnWDlfaXkxLWk0LUZ3SFNtdXM?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "California",
      "district": null,
      "headline": "California lawmakers lead bipartisan push to ban smartphones in school",
      "date": "Thu, 16 Apr 2026 07:00:00 GMT",
      "source": "FOX40",
      "url": "https://news.google.com/rss/articles/CBMihAFBVV95cUxOMlhVYmN6NFctdE5WTktjcWZ3dWV2a1JMSFJqV1I5bTFlUFFSSzd3NGd5Ylpyai03Z0NSSWowQklxdi1OT3R4emVUYmQtTjlDTTd1alR4dWVDT0dQUTNMVkp1RWk0OFlTejZXeW1tN3o5a0JtRWxOcTdOMnpLcXVCbURma2_SAYoBQVVfeXFMUDFnSzZfV1RUZkhuc1dCZ3hMV2pKcXlPT3A3eGNiM0RxMk9xak9OVDgzOF9ycGJZbmNlOXE5WUFfQmJfcFU3eHhNM2dsZFduREt4SmRtUjlQbWdfSUZ0cFhLT1prV3RmTWVYQ2dla1g3MktxWDhiYjVBc3pZc1NORTMxbzdvdFdJN2Nn?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "California",
      "district": null,
      "headline": "California students author new ‘digital wellness’ bill, say school cellphone bans fall short",
      "date": "Thu, 16 Apr 2026 07:00:00 GMT",
      "source": "EdSource",
      "url": "https://news.google.com/rss/articles/CBMib0FVX3lxTE9KU25UNHd1VUNKaWp4aHlrbVMwUlVHczFVZ1Y4VVZPXzFWT3VJZWVKX01Rc3hoZC10am51azdJbXAxRFVVcFlZVTNRUzQ5MFVRMXI1cjlFNEd5M2dRX3lpYldSMHRLaVFGbmRFU2hxc9IBd0FVX3lxTFB4ckhaVlpBemw2dGRlV1N2cXNkSlR4amZJMWxsT05ma1dZdnFtbHpnOVpfMXA2TTR3Xzk5OHd0SF9aMlZaRk5BYUg5ZHBPOUhDNDFFZWlld0EySEtzUWFqNU90QWt5TjVkcDd1ZzF5S25QakIwYnVV?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "California",
      "district": null,
      "headline": "New legislation proposes smartphone ban in all California schools",
      "date": "Thu, 16 Apr 2026 07:00:00 GMT",
      "source": "The Mercury News",
      "url": "https://news.google.com/rss/articles/CBMijgFBVV95cUxQbloxajZPX2VTNDNTQVZqVS05LVFLejdzS0pzX2ZhNnNkYnl3YlFBaGo1WlM0R1o2ZDljSzBpLVVTUDR6OTdQamNrdm1Kc2tMRGdqOTBKVnZKZWxXR1k5N21zX3E5YmdoRUk2WGRHd0NjRDNYMTdoTDhZZi1PRTMwZkNQU0N5dmJtTlRVZk130gGTAUFVX3lxTFA0UjAzWjJRb25rX1B5cU5ubTRDaWtTbklLb3o0SGYwX002Y1I5bnRKMlh6SUxqeldraGxQOHlzY3UtX1FuOXQ3VlN4UC1KdC15Yjc2eXpjUVFESUFFb2ZhSVprQm9IVEJzTmk2NmpkNFAyYjdScF9GenVUcEhMelYwRVdHN0NkdktYVEJVSTAxeEswdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Hampshire",
      "district": null,
      "headline": "New Hampshire Senate passes bill aimed at addressing bullying in schools",
      "date": "Thu, 16 Apr 2026 07:00:00 GMT",
      "source": "WMUR",
      "url": "https://news.google.com/rss/articles/CBMiiAFBVV95cUxPNHJqbnZMTEMza3dNbVZ4MlZqSm5SRlpBNWdUVDJra1RTcGp1RURROU9TRnJaQ2hqOUd0bzVfQUw2clpsV0d0WTdXRHg1X2QwV3B0QldKQmVFUzZyUEljMmJ4djNfOWhKeGtTSEU1MlpnTVZuN1B1Yk5Sa0RlcUF5c041NndoYTRt?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Hampshire",
      "district": null,
      "headline": "NH lawmakers move to scale back a ban on school vaccine clinics",
      "date": "Thu, 16 Apr 2026 07:00:00 GMT",
      "source": "New Hampshire Public Radio",
      "url": "https://news.google.com/rss/articles/CBMinwFBVV95cUxORlZkdFBFTGNJYTlNSDVxd1REOEFiTko3b0w2eFV4a0txRnUxbmFOeDZSazYtaklkNXlRMEZEM1oxRGlza0RlckhGeWhFajExRkk0eTFzZkE1RXZTdG9MaEZaVjRhS25kcERhQzh2azhUUk1LbWQ4TWQtZ3lOTGdFS3F1TXFDQXJxSThqdVo3UXpycVdvX2drSll5bmZqUDg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "California",
      "district": null,
      "headline": "California bill would ban cellphones in schools",
      "date": "Wed, 15 Apr 2026 07:00:00 GMT",
      "source": "Courthouse News",
      "url": "https://news.google.com/rss/articles/CBMigAFBVV95cUxNTHhVQTJrZzRibkZOeS1KMXdib0Rra3pRcjlWXzBIUHNodjBSUW9xY201cmhHeU5SNEJJbnU0QXNDTG53XzM2U2lxcWM4QUdXVDJPQWJYaUI4YTRNZzZjNzJETTBOeS1WOExRQ1pQRlN1eFg3bzFkVnZieEtjUEl3Wg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Ohio",
      "district": null,
      "headline": "I-TEAM Special Report: How Ohio’s cell phone ban is transforming the classroom",
      "date": "Wed, 15 Apr 2026 07:00:00 GMT",
      "source": "WTVG",
      "url": "https://news.google.com/rss/articles/CBMiogFBVV95cUxOaFVscnl3M1JvU0VHSGtpc3p5TFNTZFY3RmZuVmVTTVkxaWxGTklzR1pjWW5NTVRYcks4ejN5Rk82MnpBd2tzNzhBN2JudDA5d2NYWWFoN1dwOTdacFJ3Sy1CbUFOOE9ZUGI3RDI2MVVCNzRxZDhINm5EMDVmZ1ZkQkVaaXF6dlJMMlZxekNKVFN5YmlWM05BSmU1cXhjN3lGX2fSAbYBQVVfeXFMTVRkbWUyMzZnSGwtYUZBTjZNanlGXzE1Qjh6RE1nNWpwWXpDVXVsYldsSVU2eWliT0ZMN0JndmRULVhGbGp1blYzWnhZQzZocG4wSmIyX1VvLVRJeko4ZFhpZmM3RUt5LXAyMHlyRVBTWDVFTkFKS0dpSEFLYlpCV1hiNFF1Mzd5X0Uzc0dDZ291LTBObUF2UTZzbUFDOTV2LVE3cGI3d1kwRFdDUE14TnBHMUE5QkE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Ohio",
      "district": null,
      "headline": "I-TEAM Special Report: How Ohio’s cell phone ban is transforming the classroom",
      "date": "Wed, 15 Apr 2026 07:00:00 GMT",
      "source": "WTVG",
      "url": "https://news.google.com/rss/articles/CBMisgFBVV95cUxPa0JiREFENEYySkN6TFFXei1NSGJZSkhORjRoa0wweDJZb3RiR1piQVF1bk04MGJ3SnFPUnpYNkowQWFYYUhJaThScS1hWW1haFVnTWp4bHFZd2ZoN094dDJoVWFsRndJRFN4YVZ1QUYtQzJfWl9LSXdJVGxMSjA2ODFVeE05RTZTblZHdlUzdDhUeDdNNDN6QlNTX1cyWXpoZ05XR0NadktQU3Y5V1pvVER3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Maryland",
      "district": null,
      "headline": "Maryland passes legislation to restrict cell phones in schools",
      "date": "Tue, 14 Apr 2026 18:43:08 GMT",
      "source": "thermtide.com",
      "url": "https://news.google.com/rss/articles/CBMinAFBVV95cUxQdndtVzd1bWNTNGMtWmhvQWhEMmNoczNBajNBbTZMMVJNVFhKVWpBZkhEM0hONjFfTklXNTZ2VTVQS3hFRnl4ckR3aFVWTE9ab0pfajFDSkdaaUdYR0tIVUgzRkM4dXo4UXZpamJVQlBSMXdncWFpVGtPOG52RzR3UjI5X0g4NUJ3X21WM0FxV2tUUko4Ukg0YjdjT3E?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Florida",
      "district": null,
      "headline": "David Figlio | The Impact of Cellphone Bans in Schools on Student Outcomes: Evidence from Florida",
      "date": "Tue, 14 Apr 2026 07:00:00 GMT",
      "source": "Stanford Cyber Policy Center",
      "url": "https://news.google.com/rss/articles/CBMitAFBVV95cUxOUzlMM1cwVk5JbGUwR2ZwQ0VybTFGYWdIOWl4REdjaEdYLTYyMk10U2pPZElWZ0ROSU5ycUpFX2VucFM5RmtmSVNLOS04SVhtTk9SNUNKR3p3aUJxVWY3UFI2NG9mSXF4bDY2czJndC1ZWUE3c2xLVXdJWkU3NTg0V0NlM1ppNlBjUXY1UWhzOU1BNGM5ODdfalB0di1vVklpNUc5aTB3ZkRkcHlrYVdDT3FhekU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Michigan",
      "district": null,
      "headline": "Michigan Public Schools Face Smartphone Ban Starting August 2026",
      "date": "Tue, 14 Apr 2026 07:00:00 GMT",
      "source": "WRIF",
      "url": "https://news.google.com/rss/articles/CBMimAFBVV95cUxPeks1VWlMSXd4ZnM2OTg4SlhrZ19LQy1QaTF5WEV4alRhZndhT0dRcHVFbXZrNVgzUFNueWFpTUJZakRhWWp5MHk2a3B2NkhuNDd2X2hscHlYZEVPenByOXl3U3FMYzFWTjR1a0Z0ckYtVlNqQTladkJQVF9UcGhwRExwazZNUzZlcXhJU0VROExWd0JPMUFvag?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nevada",
      "district": null,
      "headline": "Washoe schools reverses 27-year-old ban on swings",
      "date": "Tue, 14 Apr 2026 07:00:00 GMT",
      "source": "The Nevada Independent",
      "url": "https://news.google.com/rss/articles/CBMimAFBVV95cUxQd3U3a1J3VDhBTHM2eWxMVDk5TmpKUmxKNmsyUXByWnRUTlRjOEFqa0UwNGJGWFljZU5JaUNPU1A2N0VPdmRKb3RjT0laa01uNzJJVDZzbVAweEtPdEdRVzR3LUc3NmN4SDNCZU9xcy1zZlFpWjgyTUxhZmF5UGVpbDdQcndvRm4wLUdheGp4VUcxRHhfWk9Vdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Ohio",
      "district": null,
      "headline": "Life after Ohio school phone ban",
      "date": "Tue, 14 Apr 2026 07:00:00 GMT",
      "source": "WTVG",
      "url": "https://news.google.com/rss/articles/CBMifEFVX3lxTE53UEFVazFNRmlxamNwNTlHblV3NVZiMmpBM1ZEczFGclZmSUJLbVpYell6Zm1kY0QzdEZSUV8tcTZJLTliRXhWRnhiMkZDTHJtekRkTHgzVXNCRzh2QU1BNHdmbWdFcjE4di1Bd0tMQmJnMGxDVzhqNkVScHI?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Virginia",
      "district": null,
      "headline": "Va. tightens student cell phone bans under newly signed law from Fairfax senator",
      "date": "Mon, 13 Apr 2026 07:00:00 GMT",
      "source": "FFXnow",
      "url": "https://news.google.com/rss/articles/CBMitAFBVV95cUxOYnU5N0M1aTFLLTlqNnRGS1R2ZTlNN3hYSEJQamU5bmpnZFBaTnhlWFJCWVlsX0JWMlc0YUJrTzZFejIycDZjWUZpWjNTZGJVMUJPOE8tNEZDWGRTaDh3c3hJN2lHZFdUdmRwMnc0VHhUZ01LY2pXYXh6WDJkejlNZEVvWHVaRmtadkVKNGNfQVBhSG8xdEIwRUoxSU05RUFLcVBaUGxuQmk5clU1Q1FnVTcxSHc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Massachusetts",
      "district": null,
      "headline": "Massachusetts moves to pair school phone limits with tough youth social media crackdown",
      "date": "Fri, 10 Apr 2026 07:00:00 GMT",
      "source": "Biometric Update",
      "url": "https://news.google.com/rss/articles/CBMixAFBVV95cUxPejJkSWtQLU5pRmtzMDJxSGw3UjZwU1dtQWo2ZURjVk5EM3FYdjVOZGlJT2MtLV83QVNsODVzSFlMS0tyU3pLMnd4Y1VlV3JEb2QzLTFCdnQwbzd6TGRveVZiLTEzV3pKaDM1ZjMzM05JMTBKODNtTFMxbXNWaEotQ3R1NXlFWnlWWjh4U3htZ1BpR00xT3dpTkJIaGdMSGluM1VrRU1Ea2t0c3IyVVdtdGU4SHQwdnRvd3NMSkRoT1dRMjQy?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Michigan",
      "district": null,
      "headline": "How one district shut down cell phones in class",
      "date": "Thu, 09 Apr 2026 16:25:15 GMT",
      "source": "Michigan Education Association",
      "url": "https://news.google.com/rss/articles/CBMickFVX3lxTE1oNkUwM2F2UklCaGcwSG5jWkF3X25vbW1fSHF2MmZ0STg3NWZLZVZUcWd3Zk1yS2g0MjJEZjBDb3pBNmJuTnBiVVI2YzNGNkFBSE5ENTZ1bVVxY3BzbGZhSGpYU3RJTWRDVE1JQWhCQlFGQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Massachusetts",
      "district": null,
      "headline": "Massachusetts House Approves Social Media Restrictions for Teens, School Cell Phone Ban",
      "date": "Thu, 09 Apr 2026 07:00:00 GMT",
      "source": "New Bedford Guide",
      "url": "https://news.google.com/rss/articles/CBMiwwFBVV95cUxNUHJwTkg5WVJVZjlrSDZyR04tZDdRUHlJY2Zod2xfWFBOS0l6R3ZBb0R5TlhrSkhERjdvdWtIbDNWVGNhR3gyUzZBQnhwcG4zS3I4MU95TmMzbFc0VVVEOThLYWxfZENUd2RzRXdJQXNVNGFKRGFyU2Q4TVhCdzcxTWVkbEVMX2JSU2hQVV85d3BPMGFfZFBseFdZVkhkYmRHOFhOcjRiWEJkTjRkc3ZkakpSUjBKakJib2RZWXNwdTdfeFU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Mississippi",
      "district": null,
      "headline": "As RFK Jr allies hailed Mississippi’s rollback of strict school vaccine rules, whooping cough surged and a baby ...",
      "date": "Thu, 09 Apr 2026 07:00:00 GMT",
      "source": "The Guardian",
      "url": "https://news.google.com/rss/articles/CBMisAFBVV95cUxNcnplaUtDd3ptQUhmcmZodDhhQl8wa1hYZEdjY0YtaUF0VXlSSEotRUYta1h2LVozd0hocUZ2WUhNSDBJQnE2aklQbXFHTlRPMkhkak44MklNdW1Xd2IxZTA3T2VrYzk5MzlQbTFvUjZYS1VCWDJpelRDa1k1cC1FV3BhRG8wc1VjOG0wejQtbV9uZ0xUelR4Q1l5RThKOXpYOVJCWHZYUTR4WDkzNkc5Zg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Dakota",
      "district": null,
      "headline": "South Dakota receives “F” grade on Phone-Free Schools Report Card",
      "date": "Thu, 09 Apr 2026 07:00:00 GMT",
      "source": "KOTA Territory News",
      "url": "https://news.google.com/rss/articles/CBMimwFBVV95cUxQZE1SaldaMXBGenB4MXVjdFhQNUY0aWxuN19UMXJFNzlsd2J4RmRoNE5kODZjMkdHSkotMlg4Si1WWWJJSEJuN2VkMUI1b2FxeW1JVjhrcTV6NHRRZWZaM0pvQVZYQmR3MkFkbVV0cFNWV0tUcVgyYjktczhtOUMtdVBwZ1RhcmlzV1dLQ2R6UURobnd4SHFpbk85Y9IBrwFBVV95cUxObUl5OFFYZ2tpNmNwNFluUVZaS00tUjZKMXFjNXhWNFUtWlRydVo0enlfbGgxQlJtZXJBWXNwa1BDTnpTTTN1UGRqSHAzU0t1WnhDZEpydk9wang1R2FyZjhNOW5EMm5OWGVFYk1rTDhEcDFsdjVWQ1RDVWZsQmRRSXc4aF96UThlZ0gyUTE1VU81MUQtVHNoVnlva1llU3NVV25JOVFNLUp3akFoVURB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Tennessee",
      "district": null,
      "headline": "Tennessee bill restricting digital devices in elementary classrooms heads to Gov. Bill Lee",
      "date": "Thu, 09 Apr 2026 07:00:00 GMT",
      "source": "FOX13 Memphis",
      "url": "https://news.google.com/rss/articles/CBMigwJBVV95cUxPSkJTbnRla2NJQTE0TFVjZElNemlDVEJKZF9rLTlaMl9TcHJrM2xPVm1lTGZ5V01mYVdiY2djX0lyakJQUndLdi1maWRFMzhPR1ZUY2I4aDZNSmtGOVNmUDJEWGJJWlZmLTRaLW1uaG5xb2c3eU54cXRnVHpUbGJWWjR5SDRJVXBLRVhjTndVOEVTdGpYeFdjWHJvcVQ2NHBkXzVUMzV4bnVfZjRtQlBmVHREcUNMQ1hKa1FyZ2JaZmc1Y2xoT2Y5WTI5Z1NHY3d3SWlZSWs4XzVYTE9lbGNkeXlvcXp4ZWRQSFI4SldFV2sxYlBUMDVOYmhNdm5WQXZmTFJB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Utah",
      "district": null,
      "headline": "Fewer phones and more books — Cox commends new education laws",
      "date": "Thu, 09 Apr 2026 07:00:00 GMT",
      "source": "Utah News Dispatch",
      "url": "https://news.google.com/rss/articles/CBMioAFBVV95cUxQOEpGT3JYT2kzaWk4UTFJT3g2TGNBU2plQi1YVjNUTU51WURlQWx3R3U3TWFuWHlzWVNEbjhBa0J3U3MtRFpIT2x0ZmhuLU1lY0ZmV1V1dGI1dG44TGhIOGp6V3ZfcFlDeG9GR2d6ZUtjRGl1RjVFUzlvX1VmTXdQTnNVZi1Rc0VMU2NyTTZoU3lOMUx5NGxkRDJzUGxRNUM2?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Virginia",
      "district": null,
      "headline": "21 New Education Bills in Virginia Deal With Tech, Mental Health",
      "date": "Thu, 09 Apr 2026 07:00:00 GMT",
      "source": "govtech.com",
      "url": "https://news.google.com/rss/articles/CBMipAFBVV95cUxPTE5EOUVXV1dmY0JUTzRlY0xoc250TTRqVkxvT3BQWFN1QmVTaEktcmVaTFA2eEN2LXVMVUVjUXNUZ3pHM2NPNTAzWjNUUHZfWEZhcHdtMXhNNkkzeFJrS0tZdzJvZy0wbnZJMEVhZXZCU1huaUh4djZMeEx5SkRKWDk2WnVoUkZYUWQwaXZfM01zUFN4T2NOenNfWlBEQmRoelYxSw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Mississippi",
      "district": null,
      "headline": "Student cell phone use bans fail to find support in Mississippi House, Senate",
      "date": "Wed, 08 Apr 2026 07:00:00 GMT",
      "source": "Magnolia Tribune",
      "url": "https://news.google.com/rss/articles/CBMitwFBVV95cUxNRTV0cS1pRXVWd3FZTDdFMEp3Rklvdlc0X1cteHJTdWpYYmRpZERGS1dZNXc5SXByLXh5M1FhSV9vcnoxZ1hoT25pWkJMTXc4dUJkUVlhVmY5dkd3NjktaHhyZlZsNDRwbUM3NkFIVkNjS3Vla2Y0MldTelctajBwRFBvOVh4ZGZnbGFHVHJ6UUVYTTBMQUlTTnBEejlsNjJxRi1abU9SWllUMGRWWTZNNDNuTEhVckU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Carolina",
      "district": null,
      "headline": "South Carolina wants $17.6 million to teach students about screen time dangers",
      "date": "Wed, 08 Apr 2026 07:00:00 GMT",
      "source": "The State",
      "url": "https://news.google.com/rss/articles/CBMidkFVX3lxTFB6bXktTHRIekJXcGp2RVVsa1J1bS1yVXNLNF9OaWYxeDVVeGFNUEJQYl80RVlSZlcxc1lOU25yY3pHb0RhcEI0cUdzVVV0d1RXdF9WQVFPeDF0S3J0dlRVT1hEbWlFOGZyV3pRTEYySGdRdUxabVHSAXZBVV95cUxNb3ZiS2h6QmtlQnBtQ3R6b0pXQmFYbXhoV2hzYTcwNExqb2pqakNNanZLZy1HckRhc0RWTEZiUTA3NE5fVTBBbFFLRGVlV2I2MEtnT3Znc3V4eXFqZHVNRkdqUG1hTnJYcWczMVN0TElxemYzYkNB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Utah",
      "district": null,
      "headline": "Utah’s new “bell-to-bell” ban on smartphones in schools takes effect this fall.",
      "date": "Wed, 08 Apr 2026 07:00:00 GMT",
      "source": "Salt Lake City Weekly",
      "url": "https://news.google.com/rss/articles/CBMitAFBVV95cUxQMUNMR1lxMHp6TkhsWUUxWU5iQlBmUXRQYXhNZ0hBNEJlX3FGSEhQSDUtdWJJUWEzVE9xZ2RmZXl0QXpwSHFPUjJVZ25pZTVZcFM1cWtfLXo0MXZrbkxDQjNDQXdLcS1VR2x1Q2M0eWpBSF9rX1dNRnBXeWVxVE1sRHpXRXNXWklwOVl3N1dDbEZqdkV4a0FPVWIxc3JYekxzT3FwdThkS0ZzNXpHQ3hYcWhZZmE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Virginia",
      "district": null,
      "headline": "ICYMI: Governor Spanberger Signs Bipartisan Bills Into Law to Prepare Students for Success",
      "date": "Wed, 08 Apr 2026 07:00:00 GMT",
      "source": "Governor of Virginia (.gov)",
      "url": "https://news.google.com/rss/articles/CBMingFBVV95cUxNSVFTN1BTSEFaYVgwRHNFOFYxbGtxa0lTbjJWcTdlZlBROXk3WWMza0NlRWgwX3JPUTNhT0ptS191R1NBSHRSZzhiM2lPUjE4OVR0bFhwRGZVRU8tM0d5clc1NkU5Y0tWMzhCZndNSnpUT3pUalNHQWlGazJrTTNHVzVydDJJYldEdzVXcGR5SHZNeTBPamFSMksyQ1ItZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Virginia",
      "district": null,
      "headline": "New Virginia education laws tackle classroom phone use and outdated school projects",
      "date": "Wed, 08 Apr 2026 07:00:00 GMT",
      "source": "FOX 5 DC",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxQcUYtWFNmNGNQU183MTUyOTFlYllzM2hILXBpUXZmVk9NOF9IcGdTN3d1SWFMcUZUNXBmQk9yOTBVWUQtS29zb0tIbkNQdUhDN2xTVm9hSDRiZzhDTzhTaGlSR0p6V0tCVTcxWWFWdm9aUVpPRnpzWmNMbUZzei1UcmJRdlQ5cnp5NmF3cXBHRlZndkU0X3RzUGYyQl90b21pc0o2ZFRmVlJJVFnSAbABQVVfeXFMTWwzNVVNTjFhT1dLYlpWcFdsUG5oNjFGbjI5QjhxQUR2azl2TnotNk9qdV9rUHZvOWFnTzZtZUVsS0tBZFgzSkhfUnlQWXU3NG4yUkZjUjNYaVJmN2FuT3VIazI3SERJQ3Q3Y3RGMTZpTWpRRkZwUXNTU3QyczMxM2RSU0JyQWZoMWI3c3RRZWE1MXJ2ZjVTQk1mbHNQVzdzb2JkdmpuYmRJV3Z3cjJKZWY?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Virginia",
      "district": null,
      "headline": "Spanberger signs into law slate of education bills, including prohibition of cellphone use in school - The Virgi...",
      "date": "Wed, 08 Apr 2026 07:00:00 GMT",
      "source": "The Virginian-Pilot",
      "url": "https://news.google.com/rss/articles/CBMibkFVX3lxTFBRV2VOdUlLM2MtNVYtVElieDNhdTBMSXRBWnNFdVBnaUdaeWdtWk9vNldYUEhZTDB6YWhUV29ZSGlZemVURVpabFRMMFdRRnNOWll0d3luM3FIOTBkdWFkMWhBcG12LXJ4eE1NTTR3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Virginia",
      "district": null,
      "headline": "New Virginia laws target school construction and classroom cellphone use",
      "date": "Wed, 08 Apr 2026 07:00:00 GMT",
      "source": "Henrico Citizen",
      "url": "https://news.google.com/rss/articles/CBMipwFBVV95cUxPeWphODFDZXAzSFk5Y2U5azlfdk5pZEFuRTQ5VnpRcGwyNXBldHpqU1FYVEFuTFZxVHd1SU5JSFYtYlhpck1yeDZCQjI3YXRReUFicUdPRld1Y2d0OHF1cHFXVk5NRFJvd0VuQy0zUkwwR1NxMzFZcGlzWVZqN09na01WbGJLQXNtUDdxLWlGWmU4ZzBMSXdnaU5yM1pYSU5QX3JYcEM0SQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Massachusetts",
      "district": null,
      "headline": "Bill would ban social media for kids under 14 in Massachusetts, prohibit cellphone use in schools",
      "date": "Tue, 07 Apr 2026 07:00:00 GMT",
      "source": "CBS News",
      "url": "https://news.google.com/rss/articles/CBMikgFBVV95cUxOVnRVdHZRa1lINDFUdXo5MWkzSzNsS20wUnpxRmpsX1ptMms1ZzdfdlFfSlgwdGp6TkxpQTc3MWZPQXJRSld6NDMweF8wV09uS1RtRDhFWk1tRVpDR0xHQ2tCdEY1eTlvWjc5S3ktYUdnRTVrMDdteXAwS3RIeWlpS3JjV1JsS3dlLWcySnJuVjg4dw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Massachusetts",
      "district": null,
      "headline": "Massachusetts House to Vote on Social Media Ban for Kids, Cellphone Restrictions in Schools",
      "date": "Tue, 07 Apr 2026 07:00:00 GMT",
      "source": "New Bedford Guide",
      "url": "https://news.google.com/rss/articles/CBMiyAFBVV95cUxNdGowTi1Qcy1WTjc5THN1aTlZOVd3UUpsdk9WMVVLUHVzeHJZdHJITzl6MzRzWDNHTEozc2tnMUFjd05YNmZZcjFBREVvcDBKMzdyVGozWnN0NGRzbEVCTGRpeklEczZRdktOYUJWWVJ1V0x2TnBJd3BkLVlaZDFucDJrUzloT2dXNDRpR2tfZXh6dmJNbGE3WlFMVF9SR1AwLWRjbGhXQ0tFSnZtVVRjemNhNV81YzQ2ZVp0Tl81cHN4cnF3Z2VWcg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Michigan",
      "district": null,
      "headline": "Michigan lawmakers discuss new classroom cell phone ban with students",
      "date": "Tue, 07 Apr 2026 07:00:00 GMT",
      "source": "Michigan Advance",
      "url": "https://news.google.com/rss/articles/CBMirgFBVV95cUxPQXFKcUJMMnRxbFIydnV0UDFBaFFOMHA4YTNhVVZSa1BZQVRYbzF6S29IMUdvbVRCTFA2bWtGMFYzM01oRzB2bEUyMUl1QjRha1pDdUphTkp4NDRRSmpKbzExZS1mZHJBcFVxYk1teXU1M3BkWnA0eDFzRUt1ZG04aGZsNmNXYk81aXdUYXFBbWNXcFVFcUFJblh4b2d6NWNoOXItbGdNbkFCOFo4NlE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nebraska",
      "district": null,
      "headline": "Nebraska CD2 candidate Denise Powell on AI, cell phones in schools and why she says she isn't a politician - Oma...",
      "date": "Tue, 07 Apr 2026 07:00:00 GMT",
      "source": "Omaha World-Herald",
      "url": "https://news.google.com/rss/articles/CBMinwFBVV95cUxNX2V6d3VWVWJTQTdFQ3NZYVJJekJUelh6U0dzR1hmSUxzSk5rQllOSXY0akM5eldPTDFkblJoUGl4c2MzOXhETHJZaDV0cGZRYmprQlBXQ0ZUYS1jOUZYMmZxODBKNS16NFRJQkRQUkdyck1DbVJsMUhJZEFEbTl1QU54cFFTU0hGc1NaYkVIbkIwbEdBVUpoQVEyRWJSX28?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Virginia",
      "district": null,
      "headline": "New Virginia laws target school construction and classroom cellphone use",
      "date": "Tue, 07 Apr 2026 07:00:00 GMT",
      "source": "Virginia Mercury",
      "url": "https://news.google.com/rss/articles/CBMisgFBVV95cUxOSDVnR0tlWkNueGhjNEd3SURFQjh1NTlyNWxtLV9MTUtZTXdlRVljZVFsOGtucjNnNm4wRUczN2NkMjlneEhvQW8zdFRUYndBXzh1dXBWS0xTRndBTVRIclB5VUFkbEdDaDNfQ3BZemtxN3ZsaU5FZUx0QlJtTXFoZl83Y0VYakp0VWFkY1FMM1FNc0pxVlpYQzQwQUc4UHRoVnNHNnE4NnlNTDBTZjlESUVB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Massachusetts",
      "district": null,
      "headline": "Massachusetts House to vote on social media ban for young minors, restrictions for cell phone in schools",
      "date": "Mon, 06 Apr 2026 07:00:00 GMT",
      "source": "Boston Herald",
      "url": "https://news.google.com/rss/articles/CBMi3AFBVV95cUxNcmJCTnhrVW5ITnlfMks3QzYxSlROWjZpZHdBVnI0MXJVbzZpdHBLenczLUE1WVZMVGxUNjQtbnBCczB3ZmhONmk0bVJsR1lzaGhlMkhrZVAtSDVoV0JmMlp3NlNwOGNIbWt1ZGNmdEJzWTdxTEZ6Vk0xSEllYVM5LU9sVW1aVFhlbTctanFkd0FNekVocjRwOWI0RW9WcHNQcVltWGxfN1MxckI0S0lkUGxvbUZYZEpXalk4Y2wySUZDN1N6enRHQk1rSTNWd196R2NaV0RYeDQyNWs4?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Carolina",
      "district": null,
      "headline": "New statewide initiatives for SC schools look to limit students’ screen time",
      "date": "Mon, 06 Apr 2026 07:00:00 GMT",
      "source": "The State",
      "url": "https://news.google.com/rss/articles/CBMidkFVX3lxTE8tYk5JQi1EZkFoNG8zb0xvdFBDYkUwd2NfcnlIUlNGbS1RampCcE9KaTFTN3ZqUVlkUEhmdElqcDlybHoyVWdsSE1FcnBVcmpVNF9VLWVtTTE5ZUgtRzdNM2FoVEJqU1FWcVJ2WUVVbGlDXzBuNHfSAXZBVV95cUxQb21NZFkzTnRhNndfWEt6REhwMl9WVWItOXM1YVRxeUxGc1dSeVc0Y193Z0gzS2prSlZiQkV4cU9qQTRISXNORm1zc3dMVXk2eXQ0bGtWVkJ3a0Z1VHdMWDZVbFlvNVh6OTNFRkdydGpmN2wyc1dR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oregon",
      "district": null,
      "headline": "As Washington lawmakers punt on school cellphone ban, some want more action - Oregon Public Broadcasting",
      "date": "Sat, 04 Apr 2026 07:00:00 GMT",
      "source": "Oregon Public Broadcasting - OPB",
      "url": "https://news.google.com/rss/articles/CBMiekFVX3lxTFBoOE0yTEItenBNSml5dEJfN0thRDg0c1VYRFNUYzFSc1JEUlhPUGZDZGYzeVVlLU1WZ2F1dU1uUktGU3RRQmNDaVAtb0llRG44QUFnVmpONGU1X3dzZmZUTmxaM25ITlh6cXg0NnktdTZWSDgxR0ZlUVFn?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Tennessee",
      "district": null,
      "headline": "Is Tennessee banning classroom digital devices for K-5 students? Not quite.",
      "date": "Fri, 03 Apr 2026 07:00:00 GMT",
      "source": "Chalkbeat",
      "url": "https://news.google.com/rss/articles/CBMimAFBVV95cUxNb29lM0lkYkFZNlVVWXJaWVZTYmd3RzJScVNNckFIQkJoaGQ0ajZHaUE5cGQ5ZW1UbkNZa05jN0pVUXg0dkxsTlZ3NTFoR3BsWG9pR3daZ2d2RjcxOXpOYzJxWnZwVEJQUUEwUGdTUUlsUmc0bFpweWpNc2JJNGVDbW1VN0Rrb1NBN1lBbVJHcmRlRUhPU0dFSw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Carolina",
      "district": null,
      "headline": "Study questions effectiveness of NC school cellphone bans amid new law",
      "date": "Wed, 01 Apr 2026 07:00:00 GMT",
      "source": "WCNC",
      "url": "https://news.google.com/rss/articles/CBMi1AFBVV95cUxQU2ZxTGpKblE0Q0xBcWI5Snc4d0RRMGIxV0tMeTBVSVBXakdoTDFudmVIV2h5cDhwQ2l1TFhlYy12U2cxQWFaMVR1aW9zaHlmcFp4N2VQMWNjX3lFRTVuYTk1bXJ2UDJNZENvSlZobW9WcUppNEdNcnZ6SVlXT0RQWS1pWWN3R05lOFRibWF3SHVkYkQyWHBpVVpLTkZTbGl2MmRveng2UkVRSWhhb2IwYmNrMUk5RUI4TjNzLWlscE1BQ29xVW1OdkVQREp4bjFDWGZiQw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Carolina",
      "district": null,
      "headline": "NC lawmakers discuss cell phone policies in schools, math standards",
      "date": "Tue, 31 Mar 2026 07:00:00 GMT",
      "source": "ABC11 News",
      "url": "https://news.google.com/rss/articles/CBMinAFBVV95cUxOX283ZDJaYUo4M21rc2FWUGdQeTRNeW1lWF9rRW5CN1d0aGVuamxPUkRrSUQtYmtPMXI5VnkzNzZFa3VlRC1ueWR6QWl3LXc4MnVQVUNFM2hEbXZ6QVdrRHVOZmRodEdGQ3dtNHdvcGN3T3BwZXZDU3V6UEpsMzEyRzdXZ0h3MTZQdzZzVWVNVnB1T19xenJKQ09KcnrSAaIBQVVfeXFMUERFWG1NQ0V4eGpFV2tUZFJLZlYyVFhnOFRLWENlMHdSV2VDVzNLSEpzQnZweGIzVGtUQXlNMHN4LVFXRFhNRmZxMklKZThSX0JQTWNWc0JXZlNzdkZuVl9fLVNmZEgzRWJsc1VhZFFBZWpuNmdackx0R2hRVnVLaXpsU2RJN3Z6eFdCcDNKSDFpM0VNeFczNWJEMG1xLUxaTjl3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Minnesota",
      "district": null,
      "headline": "Minnesota Reconsiders K–3 Suspension Ban as Classroom Violence and Staff Injuries Rise",
      "date": "Mon, 30 Mar 2026 07:00:00 GMT",
      "source": "MinneapoliMedia",
      "url": "https://news.google.com/rss/articles/CBMiyAFBVV95cUxPTFR1MVFfeFV3MGtoWmE3M1RwZWxQbFo2TWo5bi1IVmgzS2dkWWlEU3B2NGE4ZnR4dDBEX0N5UWpxUXd3TmlXWWtfZ0lwOTFqdktJY3B2bFRZTEE1LW93XzlicFYtekVuOEFjZHU2VVRGUlA5STFJakFQM1h2TElTaFVodzIxaEpLLXdCXzlBVnYzSXl5d3h6MExTRUw2Q1U1NXpKREE2RzdpNHBBRVpHWjdmR2ZXMXBINGs3Yjdkcm5NQUxlcFgxbQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nevada",
      "district": null,
      "headline": "Nevada Supreme Court blocks release of file on officer seen pushing Vegas student to ground",
      "date": "Thu, 26 Mar 2026 07:00:00 GMT",
      "source": "The Nevada Independent",
      "url": "https://news.google.com/rss/articles/CBMizAFBVV95cUxQTGdjNkFGQTVwQ3hGVUdNWDNKVzIzUGs4eEt5TUwtOFBKY1dSY2JGMmEzc29NTTJhcFRmMzVhRkhKZlhmMHV4YktENWtIRmU2UTl5Y1I4akFSLWtLSEtEeXFvTmdwRnlsbTFUUXdlWlRrTFp4MDRnQklTRUViYkRtMkpNal9SS3Z4Vm44V2dfSVZRQW03VWI2MlAxa1o5ZmJMU2JNNGV6WFNQZzU3aVdRMHhXZE12a3FLQTRrX1kzal9SOTdvdF9pRDc4ZW0?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Utah",
      "district": null,
      "headline": "Utah governor vetoes 2 bills, including one to help put Wi-Fi on rural school buses",
      "date": "Thu, 26 Mar 2026 07:00:00 GMT",
      "source": "Utah News Dispatch",
      "url": "https://news.google.com/rss/articles/CBMinAFBVV95cUxObjduMkdHVkNfd0NnVGFBUHVSaFJwd3VJRVREeVhHX1o5MUF6VVZLczY3VTE5MXA3NlNZTUduZzVjbmN6dXlMSnpxME5JTUREOVBEZXJWZk1vVUhyMkVOZ3VwRWQ1eVJKVFVvankzX05QMTFQX1RZOU9WeW02RG4tUHI4d3Y3YmdnREw0b0ZvVkhyYmZuNGE0WG9jTnM?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Hawaii",
      "district": null,
      "headline": "Hawaii public school reopenings, closures",
      "date": "Wed, 25 Mar 2026 07:00:00 GMT",
      "source": "Spectrum News",
      "url": "https://news.google.com/rss/articles/CBMingFBVV95cUxNMzBRM1BZUklUaFlnWnYtaEN4YTNHbDZ1V01kUFA4WXc2ZkZRVUItNk9pYUcwOEdIRTk5NVlkSXNKZC02RmN2QmNabjZONkltYkdVSDNmNUo5cERFOHlwelhHT3VJbzlPTDY0bkl6bndFdDhsSDZEUTh6eWFadXhVS3hHYlNiVEdDMm1QTTEtd2t2RG03WjZIV3NTVzVDZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Minnesota",
      "district": null,
      "headline": "Lawmakers consider a statewide cellphone ban in Minnesota schools",
      "date": "Wed, 25 Mar 2026 07:00:00 GMT",
      "source": "hometownsource.com",
      "url": "https://news.google.com/rss/articles/CBMi-gFBVV95cUxQMVZ5YkhsSnd0dkdkcW91b2JSTFBKNkd3TmJ4R1MyU0hiUUJaejBvbVFCN1VkbjMzbGNYZkRwd0NFdVhqN24yQUMzLXJTSlpuS1ZzZ0h6RVZHYjB1TGFWSVQ2SDQzZ1RETVNMQXpCeFRQWU02R2o0WXQ2WmpuajhpTnlmTTFRaXB0RHM0WDZMM05XMkl2SlhxdDlwX3MyNm1CX2podjRNSXdFbnU2enlCSDZ6TEVVZzBTU0FQUmJKZ2VYbEplRnlYck9lQlRTMXcyYm05SjVTRk1Hd1lxVXhUY1lxWmpZbHRMV1EzdEZjWVpnd3dVa2U0SWpn?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Idaho",
      "district": null,
      "headline": "Mixed reactions as Mountain Home High School plans new phone policy",
      "date": "Mon, 23 Mar 2026 07:00:00 GMT",
      "source": "Idaho News 6",
      "url": "https://news.google.com/rss/articles/CBMi2AFBVV95cUxNZl9OZzdVMGI3ZktXWU5QU2dLMjM0bG92RmpjOUhNX0piYk5JSUwtd3FhM2NvT1lkajJld0Jabnk2QkRPRVp6Q0c0R09OakhlWE9qNmJYcTQyNTB4czUyVXRIVFVFNHNpOW5sZm5RVmRPMUZ2Mjc3SVVGMTR5T3ExRF9YSkxCNlFVcG9YV1p6V0dEOE50ZTRYaXhtSXdhWWFQdmdTMGJkMzNqUlhZTXFfbVpfS28wb1otcG9pQ19pQUw1RW5KN0tkZzJVZ1VMWnU4OTFuZ1VOaEU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nebraska",
      "district": null,
      "headline": "Nebraska budget bill fails as conservatives revolt over pulling private school vouchers",
      "date": "Thu, 19 Mar 2026 07:00:00 GMT",
      "source": "Nebraska Examiner",
      "url": "https://news.google.com/rss/articles/CBMixwFBVV95cUxORV9ha0ZIeEdqcEFjalJnX05OdXFDdGM4WW01MXZ6TlJfTkxWUlpmUzZMM1hHeVNvaVNmTTdoM3dKNjl4UDZEZkllUGFkRTR3a3oteUNpZ3JEcVMzYWR6UjRBQnNsUEVId1ZWU1J1bEZLRHUxZUJQOF94TF9XYWo1bldwV1FJUTV6cGJuQWlfVjdKZWdBbTR0YU1UemFxNFNmSG5XRzVEYm9ZUDZSS2VLcVE0ckdWaVFxV3FZTGJNUUhNcU9VMEY4?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nevada",
      "district": null,
      "headline": "What to know about applying to Nevada private schools (and how they differ from public schools)",
      "date": "Thu, 19 Mar 2026 07:00:00 GMT",
      "source": "The Nevada Independent",
      "url": "https://news.google.com/rss/articles/CBMizwFBVV95cUxOczJ3UElkQl9LRl9jUXQ5Zlo5RXM3SGNCSGpGRk5manZJYnRJNWUwT0RyNWxNR3VUSVJUVEFEanRWR3ZiRlZGVHB3Sl9nbmxhVDJTakY5UE1GclgzbjlpV29FYmczODltZUZrMmpJQkhxLUVoSEJLQ2xId0UtTS12ODV1V29xQ1gzZ3Q1cXpJSV80dnY3NFdPTjNWY1kxaGh0TWl6b2JPQ2VJeUZxd2NMdUNYbXg2QXJrZWVWVHhCVzBIVTlDYWNDcEFRNGZQVVk?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Tennessee",
      "district": null,
      "headline": "Tennessee bill would ban digital devices for elementary students",
      "date": "Thu, 19 Mar 2026 07:00:00 GMT",
      "source": "WSMV",
      "url": "https://news.google.com/rss/articles/CBMimAFBVV95cUxQbG0wQkprNUNWVEFJVWE1b2I1RkxOV3FEXzZ6R3FvM1k0VUlyd0ZOWGFSY2hncGZFbVRNamVNN3YyVzhXdkxIaHZpSDg1MjVWNW0yWjkzWkRqSXVlREVlRWMzOFBwQjdCWXVaNXJ4dHFtWGg0VkhjbTBBTVhXSEU0YjdpQ0hvdHYzbm1vWjZOZHZXQkU5ZENESA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "West Virginia",
      "district": null,
      "headline": "'Away for the Day': Statewide cellphone ban shows mixed results in public schools",
      "date": "Thu, 19 Mar 2026 07:00:00 GMT",
      "source": "WV News",
      "url": "https://news.google.com/rss/articles/CBMi_AFBVV95cUxOb0VzYWhiZDV6cExSTkhrSFdmV3QxVE9LTzlzNGFMSWg2ZTZyVlRyQ0FoUEZpNFZPUlFTZWFsZlpjbGdZN2xsSjQyVnJNcHQ1TU9CUjZpalI5X25mLUVQQW16NEJxNF9pa1REak81WFVvNzJ5cUpFalRrMVIwcXhSSi1zcTNTQmZKZjdIdGdqX1NEYzBaVFVBa3VmaG1lYkRpT1lMbmdMOHUwdU93S1hPMlFwT2M2RTdvWVZERVlSRG55VURmMDBQZ3k4RHhzeGYzdVQ1bUEzMzlOR3hjOVVpanFnZVhIU0NORUE1aUlnQkRtX0E0U1JlaHdzenE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oregon",
      "district": null,
      "headline": "Oregon schools see benefits following classroom cell phone ban",
      "date": "Thu, 19 Mar 2026 01:50:54 GMT",
      "source": "KEZI",
      "url": "https://news.google.com/rss/articles/CBMi3AFBVV95cUxQelpxR2hXRjVrd1U3MTlQczl6bVpoZ0pGQkg4bVpnaDByYUJZNnROb2g5UXlIOHJwdzZlMDE2Y1J1dnJUVThNU3BOMUpRbTRibG5INW1nOUl5eDh4a0ktVFNvd084NzBsSFljU0dSVmMtRjJvM0lRc09qaENUY2wtNXpCeWp2RnMwRFFqTkpBUEdLZ0UtbEM0ejRFRjZXUnZhdWh0S1d5UENIRklwOWQ5bWI4aHJ4Q1pjQkEyRXB5Z256LWRvTk9ZTXdCNlF4M0VsQlYzaFluMktGd0V1?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oregon",
      "district": null,
      "headline": "Oregon schools ban cell phones: Governor Kotek's order in action",
      "date": "Wed, 18 Mar 2026 23:50:46 GMT",
      "source": "KDRV",
      "url": "https://news.google.com/rss/articles/CBMi4AFBVV95cUxPd3U0Y25oSFQ2bnFRUUx5cEN1M1F5RUZyT3dKWXRodHhXQ2c0UHVNbHhYb3g5VGpYRG9XcDBDWUZDZGUtVk9xODl3dnplbW90V2JkWkk4UDlQSDJpRnBieVVKTVZWOEE2ZDVQcXVaSkxmUF9ZX2RTcmVCT01RNDl1enVfQU1JaXpSbk5va1NTMDBnUmdZOC02eHR6QzdpdE9lcFFXcExKMVFDYTBnM3NKck9TUVZNS3EycUhGdXlaUjNXOEpGeEh2Q0IxOEVzQVBOZEtzRklEQk1fX3JfMWRQOA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Oregon",
      "district": null,
      "headline": "Oregon Gov. Kotek says school cell phone ban working; Not all students convinced",
      "date": "Wed, 18 Mar 2026 18:35:01 GMT",
      "source": "KATU",
      "url": "https://news.google.com/rss/articles/CBMiwgJBVV95cUxNUGRtNm92Y1U1bEQyRk5oUl9MRHJlaEdGbUZzZDhlQ0VIekxEa2l1OEFqaUdVRW9fQ2RwU0ZoMmpMRmJ3cWJBM3NFLXY2YmRWcmczOV93SkpMdndpSjYzWlNQSzdOcWVSUjJGZ2ZsNGhPN0ExLWNOYklJTFY4MnBlcE9UZlpVQ0Y0LW5xb0VVUkNKdEZlT0tTRF9RM1AyWXVRVnEyTGJobENHb2RJUGExX0R0QkF3YzZVa3BnYTlGT2gyY2ZlWDNGSnB4Qm0ybG5IdjVhb0I2aXREdWoybV9KYnVGWXJlcU9RM0RleUVNbHU1c0lkbGRBczZ5MGtYcWx5bnl3cHNNLU1jbV9hdnloclI5eWdJOWh0dkxFOEJwWUNCbFNhQU9LVVdaSGROOFBzRnNBZmROOXM2SlVMZlY4V0RB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alaska",
      "district": null,
      "headline": "Alaska bill targets homeschoolers, undermines parents, centralizes control",
      "date": "Tue, 17 Mar 2026 07:00:00 GMT",
      "source": "Alaska Watchman",
      "url": "https://news.google.com/rss/articles/CBMisAFBVV95cUxNZzJvNWMydWFDT0pEbTdYZXRSakdJbHJMblpaV3JrNXVqaHFMb3F3eGI1ZkhTOC1mQ2d0VG5GN1JOMmQtaDBWcTc3OHZlaHNUc19PcU81TmQ2Ulh6OFVqd256Mll1OUF6ZHlDOUZiaHZtQkx3bkJDWFMzdHlnU0NSa1hYdEx2RlJTbmVKdVBrbE9yWUtDdzBKbVFLaW9nSGh0SUdyWDJyM2d0c09lVExBMw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Ohio",
      "district": null,
      "headline": "Schools Are Increasingly Telling Students They Must Put Their Phones Away – Ohio’s Example Shows Mixed Results F...",
      "date": "Tue, 17 Mar 2026 07:00:00 GMT",
      "source": "The Good Men Project",
      "url": "https://news.google.com/rss/articles/CBMigAJBVV95cUxOVlNnOV9wc3ZxMzdOM2c5eDNUdVFHSXAzQ1AyQjVnZG8zaU9iTWlEYmNRM19XZGZhNlc2c19FMXFvWHAzMWY1X2hUcFljX0U5dW5tYTJfM0JKVTQ4WEVCTVJENVRxNWdsS3d0MklzSnVSSzJhVUZET0lrLU5PaFlVeks5QVpvMzI1b0NVRDcyM2lCcDBKaXhkU2laUW12YnlwN2NhVllGckhMdnhtdWNxWnlLMFVDblhZVW1IWEIxT2tuSTJqRFFBcTlhRXJSUHRZMkZNRF9aWVRXWVNKWU5ILWtkRU5wcWlUZm1qWnJ5cGMzUGZoUl9PY0hMSV91a05v?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Ohio",
      "district": null,
      "headline": "Ohio law bans cell phones during the school day. Teachers and students have mixed feelings",
      "date": "Mon, 16 Mar 2026 07:00:00 GMT",
      "source": "The Statehouse News Bureau",
      "url": "https://news.google.com/rss/articles/CBMi5wFBVV95cUxQbDBzYVIycWRIMXdZd1dFbF9TelRReWxvekx6LXI0UXROLUF0aTMyUGpIT3UwQkR0d09oVm9zRnJwM0ZTMTVYQXJNREpyWmtnNjlmdXc0Z0M1TmNGTy1oMnhCTE84S0xJS2hzdkpWNktPRWJLYzlIaGxVM1g2YkpibURZemk0dklmZFAtUzJCMUJqSkppODJzaFN4ZkJFYVJTSFBLdjB0S3FSN2JXNEZ4LU9TcXdlQlJLUkgtTjhlNmhWZVZpWUNPLWh6S3VMUGoxZjRLencyMkVhWHEwazJraExaV01mQ2M?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Ohio",
      "district": null,
      "headline": "Ohio no-phone law (HB 250): local schools report smoother days",
      "date": "Thu, 12 Mar 2026 07:00:00 GMT",
      "source": "Your Ohio News",
      "url": "https://news.google.com/rss/articles/CBMiiAFBVV95cUxOZ0JXRlMwXzBtYmh1QmxheGhIRU5Zcm5SWno3bUJxelFIYXFVZGNma1pYT2F2ai04SEs0LURBeHZPUzhrempYaFIxLTFESzNWZEtPNDBmcHFUUFo3NEhYb2dOcFBiTGQ2QVV2QVU4RWpVVUF4MnQ0ZnplYkZwdVdMTDBXR3I5OFdS?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Missouri",
      "district": null,
      "headline": "‘It just makes it easier to go to class and focus’: Missouri school reacts to first year of phone ban",
      "date": "Tue, 10 Mar 2026 07:00:00 GMT",
      "source": "WGEM",
      "url": "https://news.google.com/rss/articles/CBMitgFBVV95cUxQWnVaSXp3cmduU1hyUnpZZm56eEpqZlN3blo4VEs1RTBZc0g3S3dWYUVqQy1RTEF5OWFaaTFRRGdfaFBYUEVFZkRYOEhrWWJuNlR2eUt5aHhlQ0Z2Sk1WQTdtbUhRckdrZjZCQnN4M3ZmR1B0MTNQWTlfRFY2eWVIdHRiTWRNTDZzaV9RYlNGNDFUTXNva2taOEEwRHVaOWhGdktIWjBsay1yM1kwcmRRelpjcTdNd9IBygFBVV95cUxOdUtFckpKeGpDeVBxb2dQaFpOVFFvNzBnZEJUQXJ1bEtBMjdJWFBNUExPbXMxSkRfUDhQZjZCWVBNd0pVSHc3VXlHb1cyVlI3ZlZkLXBMNE1zaVEyWTVUUUZrVzYwd3BkckptZFJXeUxXek5TYXRfT1FxdDU4SWYzanl5VkVkN1NHT0lNUmstVElSMWd6MWxIUTJfem5WZUxOa1ZENmJoRG95MU1KbzlBcEhtVDEwVXl5SnA1RTJ3bnJZT0dWYUkxNjVR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Michigan",
      "district": null,
      "headline": "February 2026 Michigan legislative roundup: Cell phone bans, free lunches and vaccine exemptions",
      "date": "Mon, 09 Mar 2026 07:00:00 GMT",
      "source": "The Michigan Daily",
      "url": "https://news.google.com/rss/articles/CBMi2AFBVV95cUxPN3gzbHhRU2xyUnZtZERhQmpibU5NVnd4R1ViNG1acHdraFQ2Wkg0X2wybGJhVXRBUFdPWEhsWFhtV3VVeGtIek42QUNRbGh3VzZBMFpIUlQ1b2dFcmJmN0t3TFRTa25vTG9SVVFibXhqeGZZZmUwNmxCWHFfMi1yWEVBZk5ONFROSDlRRUxZb3FLS3ZZUWZYeVBVeE14VFlFWHFoMlNlNW1HZ21mZEVuVTlKblUyVkVZYlNtenAwX0h1cFNfcko5VUJWeERkdUhHT1IwNEVQc0k?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nebraska",
      "district": null,
      "headline": "Omaha forum of experts and students to delve into online and digital media dangers, safety tools",
      "date": "Mon, 09 Mar 2026 07:00:00 GMT",
      "source": "Nebraska Examiner",
      "url": "https://news.google.com/rss/articles/CBMizAFBVV95cUxNemUxVnlUZXctMXNrZ2xnM05zX2h6Q1ZQcmk3RHUzSERIRkFJWGlpYTVkTUxVSHNLNzZJdlVwWHdSdURSMTg5UUpIWEE3amlvOWtCODYxZFhPN1phUk5vTXV4RmZ4NlFqVXRCNnFDTGY5R1hCWGE1d3dLV3V2UmRDSTNhRENFWmhWRlpLZGZNc0xtLWZYQndzOWVaUXJaZ0VpVkl4Unc5Y3F6QmNjUkRTWkdqOU05MkJIcHJnNU11eFh3UkFNUTcxNGhZRUo?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Tennessee",
      "district": null,
      "headline": "Cell phone violations at CMCSS schools are up",
      "date": "Mon, 09 Mar 2026 07:00:00 GMT",
      "source": "Main Street Media of Tennessee",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxNbm5Udm1hY2JvR1RuRmJ0V1dXUFhyTTVpTU9lZE91dDFUQkg5WTIxU3BBOFlBazdGYUNDb0VKeDBWRkRDS0Qtc0JlVkFwdF84N2FyU2Y0UDhyLWM0UXVoWEVDdndkT3lGX2Z0dTgwOElvSEpZUlhoLUFzS3NqV2Q3LThfRVF3VlNCQjdvbExGOGpSb1RRS0x0c0FNS0RkRFVhcjh0czk2Nkl4ME0?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Iowa",
      "district": null,
      "headline": "Iowa City school board considers stricter policy around cellphone use in schools",
      "date": "Sat, 07 Mar 2026 22:48:11 GMT",
      "source": "thegazette.com",
      "url": "https://news.google.com/rss/articles/CBMiggJBVV95cUxNX2l4MXNBa2N3eXV4M1B4aGJibk4waGJtQlNONlkwb1V6Z3pCNFA4eUlNUUMwZ2Z2Qk1sV3Zvbml4T2V2TklOQkxmMlVtZTRzOWNoMVZmdG1WOEpWRkhjYlIxenBtWTlHamFBb2lKUFNoZlRFTFFrUUhNb0pGLVFTU0VadDNwYy1WTmtQb0I0TUZQbHNlTzh3SGkyc0V6LWpfZ2RsbmFvREVhbWdteHlfYmwtTEJPRE5NTlBZc3V1NXF2SmZIRWtucUdNNWFDTU1iQnFKZ3hvbDd6cHhqYm1lVzhqX0VEaWduXy1Md1lSVlhwTmNRRDVrOFZlVDhyZXJTZ0E?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wisconsin",
      "district": null,
      "headline": "Wisconsin school cellphone ban could be expanded under new bill",
      "date": "Fri, 06 Mar 2026 08:00:00 GMT",
      "source": "Spectrum News",
      "url": "https://news.google.com/rss/articles/CBMihgFBVV95cUxNZ1J2VVIwdTZaMDZvSTJfVHEwaUZBRW5ITFUteVRkaEVHS0pLbnZSRGpKb05iU1pTSG45YjgyMUFQaTVWbU1qa3VZVTdvM1NRS1FqQ3FndUdKMTR1QzBoTFFoeXYxLTUwVGFiOWlpWTVIX0ZIMk5rNW1ISV82enB5TTFrY1V5QQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wisconsin",
      "district": null,
      "headline": "Wisconsin bell-to-bell school cell phone ban heads to Senate",
      "date": "Fri, 06 Mar 2026 08:00:00 GMT",
      "source": "The Center Square",
      "url": "https://news.google.com/rss/articles/CBMilgFBVV95cUxQY3RHdVFJRndIeWpRQzlkeGdydy11UEQ5N2dhV0xhSmdybDNBSkZGQjBINkl4Yk9rQ0k3SWtQa2xXQ211b2NheU1EV1dwcDBsZkhuaXRBR1FUWnJGRUZFXzNHZXhpbXQwVEVzcFo4WmZrNlNrYUZuZ3QtTHl5V3dkYmNkaGgxZlNaY1Z3SEFBMjc3RUkxTHfSAZsBQVVfeXFMTzY1NVJ4d1M5RFRQNW1SM0djOW5xY1MzZV80cjEyRVhLVXZUaVg4emRFTjc0eUdpZU5WeGtnX1N2YS1XYlZFc0psNjA4YWd2cTlTcXJCNXl3TVA1ZlVGbW5WRTJ5MUs5Q0dMVTM2aTAwTjdNcGZwQWRhYUR5YTRjOFJWaFlWZGFBX2dnbWU0eVp1OHd1RVplRFZleE0?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alaska",
      "district": null,
      "headline": "After historic education funding increase, some Alaska lawmakers aim to boost the BSA again",
      "date": "Thu, 05 Mar 2026 08:00:00 GMT",
      "source": "Alaska Beacon",
      "url": "https://news.google.com/rss/articles/CBMixgFBVV95cUxQR0NyaUhqUlNWNXBpZlZRRTFuU0poN3dReXhEVnEwcGNyQzNySHhKdjBfUzZ2VjNsb1BnUWp3Wnh0T0huT3VGakJqS1ZLdjYwMjZUUWlTc0IwNVRVcXdvQ1dPMFkxOUd6MHlROHNHX3dvX3N0ZW85SHFlVWpMS08wNFU0S2pCRUduSml0RDBXVDJqYk5KYWs4MUphMEowbjVmZU1nN3Fua08yRTA3d21mUkFOSm5ESXJNNWlDak1IY1pEMkJVTmc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Minnesota",
      "district": null,
      "headline": "Minnesota lawmakers push bill to limit cell phone use in schools",
      "date": "Thu, 05 Mar 2026 08:00:00 GMT",
      "source": "WDAY Radio",
      "url": "https://news.google.com/rss/articles/CBMirwFBVV95cUxPS3hoWE1PUmdMOXZrS0t3Z0E0VTlTbTJpQ0JwUXktZmwtQ0pXaDRiWTdhbEJxZzZ0WG9iSHVWWXpkWWxNUlVlc0ZPM081OVMyMmpHaDVrcUVOYWdlaHdBUjg0Wk1mby1jOE4xa0J6N1N1OTNmRjB5YjctYllvQ1FMNzNYQ1Nlak5IenNFWjNYT1JFdVRiYVdHM2RsTHk3UU53X2ZoNFVXMUtKUHFnb25j?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Dakota",
      "district": null,
      "headline": "South Dakota leaves school cell phone ban on read in rejection vote",
      "date": "Thu, 05 Mar 2026 08:00:00 GMT",
      "source": "Argus Leader",
      "url": "https://news.google.com/rss/articles/CBMi1wFBVV95cUxOQ1R1akJXMk5raDhGeks3b0hKWDEtOWh6YWw3LVJDSF9vRHIzU21ZY05wc3pxdXB5YS1BWktMbG1wT0VHazVpS3ZfaThpbTJ6aXRRbi1nZXIyWmJNZlBCM0Q0VkhudUlhdHh2aGVQRzNyYVZ5ckEtbUs4OFVRbHI1S2RGdUdfX2VTUlJDVEkxY3VLbloyZHE2aEFsamIxM2RJbWR6RXVyNnFkU2NfUlNLckdVMjlIV0tzazVJNkp3bWNuMlZNUDUtdTVQWE91U2ZLbm1ybWVLbw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Minnesota",
      "district": null,
      "headline": "Other Opinion: It's time for Minnesota to rip off the Band-Aid on a cellphone ban",
      "date": "Wed, 04 Mar 2026 08:00:00 GMT",
      "source": "Brainerd Dispatch",
      "url": "https://news.google.com/rss/articles/CBMiywFBVV95cUxNU25aYzlKSVVLNW9hRHRsSFo5cUE5MFhybXRWMkI2dnNXeG9QUWE4LXJxTHRNaTQ2ejhlZWYwSk9ISkxmbF8zZzJBYThLbndkZXo3WnhRVVEyd0J6YzNlSnlPWEwxWjZBRG5PNnpNNHBuUzUtbVJxUjZwWWVlYk10X1hqMnVVaFFQQVZmZlZjZjd5ckxuNWZuSGRYWjBEbzJ1S0ZOanQ1TE53NFZzazlaZUdQNlh2Z09BZVlBR3JXcVhpUmhRNkQzLXNpQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Missouri",
      "district": null,
      "headline": "‘It’s definitely boosted social interactions’: Checking in with Missouri students amid statewide school cell pho...",
      "date": "Wed, 04 Mar 2026 08:00:00 GMT",
      "source": "First Alert 4",
      "url": "https://news.google.com/rss/articles/CBMi5gFBVV95cUxNbE9mUjhVVDQ5YVFPd2tmelJiTUJadTJBZjJZeVZYQ3ltUzNWWXNjZGpfVll5b3JyU29CMnNKUFFudEhjNWxzaUZnSHhtb0h1NWhIQUNCSmNQNkJ5eUdfbmdqS1QxUWphaGJwQmZhc1FmSW4xdFpaak8zLVZQVUlqTU91b2M4eDJoTlBXNHBnV1dVWVBKZjhvX3VWYWRqQTRHV0ZQNFNYN0dzcmw5NmQ0UmFNNVlYQmVkSmZGS080VXcwUGFfUno0OTU3bUZfTDB3QjRUNlNxdDhHaTlscnlxUzNMTlFud9IB-gFBVV95cUxNZ2JNcThtMHNiQlpzMHVVbEUwNlliVzIyUXViTk9hWVpMalRxVFp1b2FvNDd0YVAzUUlTQWltSzFILXBERjNCUmxSNHBBZzBjNDVaTU4tSnpEMVFGdTgxck9GMUxJMW81MDdfOG1tWkk1OTg3M1BSNzNTdGdNOWZGbWZzRlk0WUNiYVFuYk9zOVgzQXVIeXh3bU1tZFZjeHhqRXkyeW5rMXkzZTlQMWtCdTdURkNzWFhQaFJmN1QwU3NyamtZQkppaUJhQ3VhVzJVU1ozUWdudGY3WGh5OHRiMXdwdGduRUJILWIxbnJMR3ZjZTBIVnI3Q1hB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Rhode Island",
      "district": null,
      "headline": "Bill Spotlight: Rhode Island Ban on Smartphones",
      "date": "Wed, 04 Mar 2026 08:00:00 GMT",
      "source": "Paragon Health Institute",
      "url": "https://news.google.com/rss/articles/CBMiggFBVV95cUxQMUlUamlTczREdEZ1ZVlpaHg2SW52WF81RURaRFYzRTI3LWU3Y0RtUXVzRFhRa2g0ZjczYTVUMHVpVXdKYU9ldmNnbWx2cnBQQTkydUtUbEdDNEVsRnpLcFJXS2VGc3hBeVRxTWpZcWlIWE9IY2RGN1ZYSUdTTEg3UXZR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Rhode Island",
      "district": null,
      "headline": "School sports anti-hazing bill sees no opposition during RI House panel hearing",
      "date": "Wed, 04 Mar 2026 08:00:00 GMT",
      "source": "Rhode Island Current",
      "url": "https://news.google.com/rss/articles/CBMivwFBVV95cUxPVnZmQlhyNzZjbk8td0REMEsxSUNkcVdzaU10Tm5TMkw5Qy1UOHh4TXZyUFk0bk9CbE0wSXZzdFRHUTlyUkpUZlRaempvblBwVXdHeEJEbEhnY2tfUXNZYXg4SlVEcjJ0bVRBaWMybnZITEIzc2ROTzBxclhXb3c4RTRMbWM0SlFiUHdjMHEtQ0laNU9GazMzU3IzYWVVc1lHUEJtTmdTTi1ZQUhYa1l3a08yaFB5Z290SXhJTU9HQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wisconsin",
      "district": null,
      "headline": "Evers says he has to think about the ‘bell-to-bell’ cell phone ban lawmakers are pushing",
      "date": "Wed, 04 Mar 2026 08:00:00 GMT",
      "source": "Wisconsin Examiner",
      "url": "https://news.google.com/rss/articles/CBMixwFBVV95cUxQeGt3UFpWNnBERVlGbUUwcFBsTmVYSk9vSFhXb3N4MkdQQWs4Mm9ISnZCWFJUQ0JEaC1OUFZhZjJhT3czb2h0Wi1UdG9mdGdjRVU1QUExekZnYTBIZWpIUVVva3I3VlYwM1ZRZTBhQ1Vvb3FwZlc0Ui1zWTZLaGlPZWdhQkFYNll1dm9udHdlRXJqZXoxeGRvb01HTGlzZmNrMVdCeVI3LXN3azFOajBIQVB1UUJHV3JsLXQ3cDBXQmItQUxLUXA4?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wisconsin",
      "district": null,
      "headline": "New Wisconsin bill aims to ban phones for entire school day, not just during learning time",
      "date": "Wed, 04 Mar 2026 08:00:00 GMT",
      "source": "WLUK",
      "url": "https://news.google.com/rss/articles/CBMi2gFBVV95cUxPVHhEbGp3RWpfSTg2SXpQSkNRU1NJbnYzNDJWNTRlZk5tWXdvMHZxRkxLWlhFYzBXSi1mRUlnQ0RIdzI0TVVtZGJxcXV6MEMtSjdVSnc2NmRzS3o3SUpxZjl3Z25DdC03OG1YMVpCVWFwVV9pSVhDdjBFRlJfNnlEYXRUUUtWNERhTXZmbF9XMW1ZSlNRY3Q5dGExa054LVliYzRkczVXbElyLTVtRHVvVk5XcjlmUDNJRWdTb0JTOUZxVGJYVUI5QlNSTkJuMFFFUmtuckRDSnkyUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Florida",
      "district": null,
      "headline": "Some parents say adjustment — not chaos — defines Florida’s school phone restrictions",
      "date": "Tue, 03 Mar 2026 08:00:00 GMT",
      "source": "WGCU",
      "url": "https://news.google.com/rss/articles/CBMivwFBVV95cUxNNy1PdFdFWTlUMUhFRDJsci1nOVdjTlUtRmtWS2FqVkdBbk9pempNZzNxN2o1eHVmX1RPZU5rWE4yZXhaQ2IweTIzZ0tJU2gyenN5REl2dnhiT29TZ1RUekRDU19Xb1k2eFhjUHR3dTIybWtkT1FBZkFneEJ4Zk1Ea2FEODdiRHhJNDJfckFObkdESHlvcDNvbUMwb0h0T1RpMXJ2R244YWNqVGR4bVhfa0VvcEtfUmNWUnR2U3p4RQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Carolina",
      "district": null,
      "headline": "At-Risk Students Get Second Chance at North Carolina Charter School",
      "date": "Tue, 03 Mar 2026 08:00:00 GMT",
      "source": "Education Next",
      "url": "https://news.google.com/rss/articles/CBMiwgFBVV95cUxNZFA2cVEyWDdUTTIyMzFKRGg3WlRlYmNMU1k5YVNJT0N0TUZ2U3hldFRCMnFaYmkzSFdnNTh6cE82MlcxQ21ISGZhS1hyb1JqakpfSnRBZEtsZmpSWG1xVjlQdHhtZ1h3MEJEMW9jT0lrVjlwTVJHcTFZY1h1T0ZpVXFUN1pMdXMwZVJFeGx2ZEdHZzY4U3N2QlZORkVrWkE1Y194cmR0bU9DTlJkVi1vajdSSGwwTXhfcDVBWi1xNG9UUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Dakota",
      "district": null,
      "headline": "South Dakota Legislature: School cellphone ban comes up short - Brookings Register -",
      "date": "Tue, 03 Mar 2026 08:00:00 GMT",
      "source": "Brookings Register -",
      "url": "https://news.google.com/rss/articles/CBMiqgFBVV95cUxPOFJxUV9xWUprLURvdEUtMElNcGV2aTRvUXBvZXo3eDR2Q3JnVHBKQ3dycXVBa3hhREdlRldlT3pOUS1mVnB5ZldFWFg1TGZ1MENMcjMtanNYUEJWRVY2c3FnUWI0NlRHMTcwdEZqaE10bnBTVVVhXzFtdnlwQ0tWSzFnYWxnMlBGdXlDZ2lXOVNNenZTNHNaSUpLaUJkdS1FN1hOSHV1bUt0QQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wisconsin",
      "district": null,
      "headline": "Wisconsin could expand newly-implemented school cell phone ban",
      "date": "Tue, 03 Mar 2026 08:00:00 GMT",
      "source": "WPR",
      "url": "https://news.google.com/rss/articles/CBMiZ0FVX3lxTE01cWVPN3RjZkp6U3FaLUxpUmZXVWFvM1pSNUdnZkN5NS1YME0wbGh2VFFkWlcwc1IxTUdJU01kVnozRFA3YkdLYlg0aHBMNVRYUEhjRjRPWk9hX0hkM3d1SGc3ZjNwYWs?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Wisconsin",
      "district": null,
      "headline": "Wisconsin lawmakers propose bell-to-bell cellphone ban in schools",
      "date": "Tue, 03 Mar 2026 08:00:00 GMT",
      "source": "WSAW",
      "url": "https://news.google.com/rss/articles/CBMimwFBVV95cUxONUVmYWVvdkQ4V1hfUU00RW1mWmxXQnRaa25mRUlpZUlhTkpDZzV2TkItSHFFcUZKMFNveHp6VllXOHIzeWZmOUpUaV9VY0kzR1BuWUdKS2RDclZORFpfb3gwTVJveXNaYjhmbDJFdEhQZTVvZlJDc1hqc1RzR2dSZEZZUnpOUWpSZy0zTDU4N0wySjBDRTZZVERiMNIBrwFBVV95cUxPcGhvTFN2VEp0WHg3MWpHRzd5b0xBSVdkOVl1cVJRcVJUSjJQYjlZMjltNUdRMHJuTVUwMUltMk8wdmlIVnB4NUNmM1d2dXQxT3R3b3hJSzN1ZENRQm56U3JOc0h1U2lscVloSkw4QjBoUG5PUGZ2ZTZtV0laWHlacDVocm5UcXlieUFZVHRBSDdaU0ZtUnZTUWgyYmdCLW1CV0xKVVlnZUZUWEYySGtJ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Minnesota",
      "district": null,
      "headline": "Lawmakers consider a statewide cellphone ban in Minnesota schools",
      "date": "Mon, 02 Mar 2026 08:00:00 GMT",
      "source": "KAXE",
      "url": "https://news.google.com/rss/articles/CBMilgFBVV95cUxOcENDb3BBQVVneDVoMzBzVXBfWnhoTHF4Wk51ZENzQU5tUTE5QVFLY0N5a2VjQWFNVEpySlBDTjVUejZIS1c0Q0ljd1JrRkdzeXk2bjQtazlhaWtCV05UQnBSQjVkNGtwSkoxdlhxMGJDV3pVcTMzZndReDNlb2ljQ1hlUkcwcS0yZnlRai1CRHhpZ0ZLY3c?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Dakota",
      "district": null,
      "headline": "South Dakota House committee kills statewide ban on cellphones in schools",
      "date": "Mon, 02 Mar 2026 08:00:00 GMT",
      "source": "KOTA Territory News",
      "url": "https://news.google.com/rss/articles/CBMimAFBVV95cUxOS0gxTHVDV2ZSUTZZTmQzb0hhZThqMDRidm1DSVRob3hTSTN4Q0lFOElINnl1Ym4yN0pVWlNzNjFGLTliTnNVd2g2T01fTWdSZjZyYldHaHFkdTF5dVVyaER4b2QyWmRWQUpwaWI2ZVBEYmYzWE1KbTd6RVFGNjh2Y1hqNV9IN3FQTkVNa1JUay1Xa3pZV1M3TNIBrAFBVV95cUxQNm5UYzRZUWROZU9KWGJxMkFyNGE4SDhiS0dJdzJES1BVR2VPUkUyMU13OU5oSmgzUlp3bjZtOEsyNEM2NWpjbmgzeVozZzJ0WjNhekRsZW1aeUNEWnIxeE1iYWowU0tHbVM0NWFlaWRhSHota0R0eWhxYzB3RHlIbFpyb0J4bDduUTZsZDMtWjBxWGJPLUJLTTFDck4wa3BzXzh4Si1Fb1dhaHpF?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Dakota",
      "district": null,
      "headline": "SD House kills statewide ban of cellphones in schools",
      "date": "Mon, 02 Mar 2026 08:00:00 GMT",
      "source": "Dakota News Now",
      "url": "https://news.google.com/rss/articles/CBMimAFBVV95cUxQRmJ6TUtNTW1jYkFEY3pXYUtackZjQzIwT21aRkZjcFV3UkJCNWJraFFZOGlXemdaLWNobDJibXBXUGxIU0dQTktZclVFZUMxUnFNbUpZMW9VVllXNlpiT0ZVNUFBNElwZ095MFRSZklrai1YUTdyTmdYeGs1YldCc2NkTldKcDBmc2w1ZFR3VWM2VlFIbF9JMtIBrAFBVV95cUxOdHBrSlNEMWFoemNmRHplOXJQeGliM2pJSUpGRG4telF5LUtaWXJiZ0Z0ZGxGSFNIRG1pbEdCTkRwc21ON2ZtblhOVlgtbUJoeFdVdHBidHBhVXVXTE80bmd4X1pDbXpiaWFVejhDUjFGemgxSFVad3FGdEU4dnFCUHVlcGZoN3dNcUJvRVY4MXFta0tSS3FpdG9vem1QOXY5VEtubVk4Z2J6X05S?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Minnesota",
      "district": null,
      "headline": "Minnesota Considers School Cell Phone Ban",
      "date": "Thu, 26 Feb 2026 08:00:00 GMT",
      "source": "KVRR",
      "url": "https://news.google.com/rss/articles/CBMif0FVX3lxTE5yMHBnVkNzN0tfY0FYYTVuWlRDZkNCN3plZWI2a1JMLWlBdjFRNnN5b2ZyWjlYcm1xNlU5TXo4bHhETzlBTW9jOWtrUDgyN2dtYjZ1ZnRBVkhic3QwaVBTWEJ2aGZHX3d4bFlTUEFsYmpYdUJ6WTFrMEY2dGFHR0U?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Minnesota",
      "district": null,
      "headline": "POLL RESULTS -- Phone Restrictions In Schools Across Minnesota",
      "date": "Thu, 26 Feb 2026 08:00:00 GMT",
      "source": "WJON",
      "url": "https://news.google.com/rss/articles/CBMiZEFVX3lxTE9YMFFjc21ERFpTbmxwQjRZS2dwS2haWGF4NXBYeGFRejQzOVlRckU5dzVxMldVZVV1dzI1ZWd1OXRXVzZLV2VxWkswRFZoYW5QN2lSSGN1bEJXLXNWa3NRdEFHUmw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Michigan",
      "district": null,
      "headline": "The scroll, the like, and the law in Michigan schools | The Metro",
      "date": "Wed, 25 Feb 2026 08:00:00 GMT",
      "source": "WDET 101.9 FM",
      "url": "https://news.google.com/rss/articles/CBMirgFBVV95cUxPVi10TjZCdGpUMzVmWHkwV0tRLWsxTzF4cWR3d2dLeWl3bms4Ul9XT01Zakp5WGUyd3hSRzlNM2NjUmxyMEVOU2JFN1B0RVFwcFFlMkNoV1Y4ZURRa0VaSVE3ZGlRSmdKZkpmTkV2WVkzMzNkZXk1OTdDQWd2TC1PS0ZaNkY3VjhEeVBlYVpVRTRjMlU4TGlLOHhVVkdqQlZndUJxeXY2Y3dhVjRkOHc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Minnesota",
      "district": null,
      "headline": "Minnesota bill proposes statewide cell phone ban in schools",
      "date": "Wed, 25 Feb 2026 08:00:00 GMT",
      "source": "Northern News Now",
      "url": "https://news.google.com/rss/articles/CBMiogFBVV95cUxQb2cyOXZyUlN4clM4YnRsMEtubGVPOHN4NmxfbmhxckxFaE9Kd0lobTAzUlJxNk5XbHFOek9faEVvM0pYenV3RFB1ai1qZXF5WHg0UkxtMTB5ZjdJT2pzTHVMVVBibl8yQmFqMFgwN2ZNVmdDazR6ZzZiUFdJNnhvTi1kS2lHVXY0MEE3VWlWOVlNMVRJUDJpUjdmZlMwdFdDYnfSAbYBQVVfeXFMUHRKQmNDMTVLZTdBdnk2cVpwY2xSUF83NlNvcHR4M2N1ZW5PVXVnRUpnVkFnX1dqVnFWZGp6Nm16UkZXOGxRVHl0UXRuSXcxQnpkZnp6UzVYMFFvbTFsUG91OFFrTUNoeXVJSG5nbmZUUTd6czY1a0NhcHkydEh2OFZ5LW05Q0wxNjlobDBUM2FfYzhMc1lra1hIaVVBR2NpX2pVN1IwMjQ5UUIwZ1BXVDJhYk4ySnc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Rhode Island",
      "district": null,
      "headline": "Rhode Island college student dies of carbon monoxide poisoning after charging phone in car during blizzard",
      "date": "Tue, 24 Feb 2026 08:00:00 GMT",
      "source": "CBS News",
      "url": "https://news.google.com/rss/articles/CBMilAFBVV95cUxOejZicUdwektTenpJVUhmZlczVEJ0eGprbW9XMnRRZGtKcS05S3FoaFZkTk44aVBkWDZ0ZWhjQldUUzFTUWZRakVmZTNTbndKVHk3UkhxRlpKcTVjY2l2MXJTNElrc2VadEVOR0NlSWFmcGNkamRWY21FWF9uNUhBMWh0YktVbkhSLW5xTFk4Ymo0UVot?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Mexico",
      "district": null,
      "headline": "Data shows water systems with high PFAS count as NM writes new rules for ‘forever chemicals’",
      "date": "Mon, 23 Feb 2026 08:00:00 GMT",
      "source": "Source New Mexico",
      "url": "https://news.google.com/rss/articles/CBMiwAFBVV95cUxQS1BvR3B0Y3UxOU41RXg1THhiZ3BNRXRtNklBTkJDOWdIenRTR09RMDk3aHBsZjNwcG1kb0NrNWtXXzQ3S090NEh3MlN1a0dRcEZMSUJPMjZVWDZtVE15dmNmMGw5ZUNZN0tGZWlhSjJDYnN1M2R3RlAwc1FYYUVCanVtTWJ0V2Q4M2NHLUpaOUFrejB3NDVRTk1hZEdVcEo1YU5VMEE3VXlFeEZQR2ROTGpJY0haVG9PTXp2Snk1YUU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Iowa",
      "district": null,
      "headline": "What worked and what didn't with a cellphone ban at a Kentucky school",
      "date": "Fri, 20 Feb 2026 08:00:00 GMT",
      "source": "Iowa Public Radio",
      "url": "https://news.google.com/rss/articles/CBMiwwFBVV95cUxObkNnOFl2ODMySlEyYVJhY003aElCS0pvWDBCRHBzbnJ5X2ZUNzJqaEdQNW42eTJVbDdFbnlzb29CWXBnYXR5SEVnWTlMaE1NMTRPb0daRUFVLUpkSmt4eTl4d3BxaFdGUkZLNEFCVlY5TFltVUZEN25USlV0MWl6XzlXT1VOMGVMNFhQTnFsT2QwcTNuY2NJbU44UksxclBGLW15RC0yU0w0c25IMmpaejUyTmF5T2ZOa291TE4zNEJOaUU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kentucky",
      "district": null,
      "headline": "What worked and what didn't with a cellphone ban at a Kentucky school",
      "date": "Fri, 20 Feb 2026 08:00:00 GMT",
      "source": "NPR",
      "url": "https://news.google.com/rss/articles/CBMinwFBVV95cUxNU0RYblplcEpwSWw4SUxjV1F6WGdZSGhPd1Fuelc3SlpLcUdFNi1nRXZXdDAwUkdkZGVKVFZDaHZFNG9Rd1pDZUo3b1Q3SGVUZ0c0VTVOTC16QVQtVU95VksydjF1dEI3bnVZaWxPQkFmMVhiN3R5dXFGNm54Ulh0M1BJQ0FxLUh4dDVYNmE3bHJYZ21wVFZ0VHY3Z0loZUE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kentucky",
      "district": null,
      "headline": "What worked and what didn't with a cellphone ban at a Kentucky school",
      "date": "Fri, 20 Feb 2026 08:00:00 GMT",
      "source": "NPR",
      "url": "https://news.google.com/rss/articles/CBMiWEFVX3lxTE5JYjRkaWlVaUM4N1hkUlVrQmRxUlJzYVVqTlZFbVhoVmNqdEYwQU9KdG8zSDAyZ3BVejFYMzdXejlzb1J2UXRKVFVuVkFkNEY1ZVY3dmNPLTE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kentucky",
      "district": null,
      "headline": "What worked and what didn't with a cellphone ban at a Kentucky school",
      "date": "Fri, 20 Feb 2026 08:00:00 GMT",
      "source": "Louisville Public Media",
      "url": "https://news.google.com/rss/articles/CBMipwFBVV95cUxNV3d1OGlQUHdQTFhIYzJqRlJLZ0xDd2Njc29Kbk5aRzBQdnROQndUTFRWTFRxUmJ2SmxtSlo2TkVXTlRUaGZ0eS1WdWs2V3dnVnpWY3ZGTTUtQ0FadnVabFRYS0x2WnVQT25hN2I0T0VUN0VsUEZtMkZVOFQxSHc2cGJKMjh2Q1lpeUx6Ull0YmtmNVA5ZHo5M0x5VVAyVEhkbXN1VlBhQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Mississippi",
      "district": null,
      "headline": "Classroom Cellphone Ban, Other Mississippi Senate Education Bills Appear Dead in House",
      "date": "Fri, 20 Feb 2026 08:00:00 GMT",
      "source": "Mississippi Free Press",
      "url": "https://news.google.com/rss/articles/CBMiwAFBVV95cUxObjBTcFh2NWpTTHBqSUNDUzlVaWNnSmxlVkctc3lRN0RjaGtubllyb2VLZ2pKdXpMU1dEbGpHNEpMbFlMbGZMeWlCNkpsbTRsUFB2TnZiTENUeXdEN0ZpVjd1UkZULWhaa3drRlJ6OFE0VnZKVC1QMVd2YndMX0pNRjltSnJzWElNMFlhQkpfeGt2ZXhkUmhMNXNhZkJMTkNrQ0UxS0laQjBXTl9jT3g4eGRmQm0wdzQ1TjNERUEwZjY?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Delaware",
      "district": null,
      "headline": "Schools consider new phone bans as bill aims to set statewide guidelines",
      "date": "Thu, 19 Feb 2026 08:00:00 GMT",
      "source": "Spotlight Delaware",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxNZFpQdVdiYnZCYU1nNlFmOVVHcFhtTGpMc3diejRxTmV0RGxZR2QxSldoMnlDV29xbzNGbnZ6SXAtUjllQXpsYTZKQVczcXRRNER2Q0RrZDdtYlo5WFRld1JCOXFyMjdJWlJHVmpQZ2ZXZ0hTMHI5cG1FRk14QWN0bmRnTWFRS3F3Rkoyd0hEV2J4MGttaFp5N2ZtUDEtc1ZCOFItVXFzQnJBN1E?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nevada",
      "district": null,
      "headline": "Nevada school districts tell lawmakers low birth rates, funding leading to budget deficits",
      "date": "Thu, 19 Feb 2026 08:00:00 GMT",
      "source": "KLAS 8 News Now",
      "url": "https://news.google.com/rss/articles/CBMiywFBVV95cUxNLUtFQWRZN0d0QVVHdTg5UHhtWlNPV0pRNDJMLUJGMHRPRWhQM291b2x1MFlnU3g4cXRBSDVlVHo2Q2NobnRRZkIyRm1HaEphWWIxZk51SUFjVVpLQjByVkdTSzNBTFJkNzVvaTJVcTBzLTNCSGk2dDRYVU1LeWtfWXlQdUtoZWcxazFldEJYZmdRdFNoVEtHZ0ZMREd1ajFiSDZ1ZGdNcXJzX2k0bnloMWJ3cUNnbV92YjRvWXVWUE1vdEEtT1RSVmNsRdIB0AFBVV95cUxNYXhJeXlvNk5uNk55RmE0cmxkWjVtSDJKSmd3QmJWMXd4Q05pU1hMVkI4QmhHT3laWmVJMHo0bjZ4N2ltNDZTbE1LTmc4ZTRIZTBPVENwcGtOMlh0SGpic20yS29abGFqejNNczNEdTZTODF2eWFLcDhCamxjU0R3ZFRtRGo3VjdLVWtqRnhkRWVpWVJkbjZQMk1ZTFItN0poRmZZZFdDSnQwSlNic0NEQktTbDVILVFLSGhfck52TWRUU1I4cDQ5R3k2SDFZcmc4?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Hampshire",
      "district": null,
      "headline": "House passes bill banning ‘leftist indoctrination’ and LGBTQ+ teaching in public schools",
      "date": "Thu, 19 Feb 2026 08:00:00 GMT",
      "source": "New Hampshire Bulletin",
      "url": "https://news.google.com/rss/articles/CBMiygFBVV95cUxQUDRsR2kyRHpjNHJfY2QxTkhrUDdfV1dhOFNZNUlBR0dlUUdHZWxnb2dhaExrQWZadERVNFdTVFFNejB5RFVrM0hzVEdvRTg3cEtzZG9oM2t3a1ZrX0Jja0N6MUZ5VUU1NGV1MDhJS1BsdkdhWmRzX2NxSGViSUdQek80bHFKLWFQRzM2Y2N5MUt6YXpnOHAxS0hLdlNRcHBqM3FIcjA1d2ZyVlk2NjZDQjliT3Q1VlM5MU85eWktblBqY09yVGhHUl93?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Mexico",
      "district": null,
      "headline": "Cellphone ban in NM schools dies as literacy, teacher health bills advance",
      "date": "Thu, 19 Feb 2026 08:00:00 GMT",
      "source": "Albuquerque Journal",
      "url": "https://news.google.com/rss/articles/CBMiwwFBVV95cUxOQVEwZ3ZUV3ZILUFMUTdRLUVrVkZnUU5CYk54dGQ2STRKMmMweGEzLTdvY0ZaUGhWSDJoczlrTF9ycVZPdjdrSk5IN0lBTUJCOVZIZGM5aVRfcTNTRnVieHdqRjRrWF9qLThyQUhJRzBjaDRQN1JVeWpsNmVnTVZlZEI0aHA5aGc5eHp0UzlkaDJwMEFoSXNOQy1VZno0SVFPT2RrUjFVRC1WVGlRN2J6WDJHaVdQOGtsSGlvTzdGZUltb1U?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nebraska",
      "district": null,
      "headline": "Eastern Nebraska student accused of recording classmates showering",
      "date": "Wed, 18 Feb 2026 08:00:00 GMT",
      "source": "KOLN | Nebraska Local News, Weather, Sports | Lincoln, NE",
      "url": "https://news.google.com/rss/articles/CBMioAFBVV95cUxQS1NLa2dYRDFqR2p5aE84MHEyTzVsdmhVWmktSmhYNC0wTENvZ1g4RmZEclpuTVUxaFY2a01BNUNvZTNkZ2lXTlliQTlUVnh6V1pLRjE0VjlyTFBGZlR3Sk9UV0NjX3RqREV5am9YaUtUd0tlRmtTOGZ4Tm14ZW8wZGJVSDhEV2FNWmJLZlFXNlBLdE82c3BWR2xsNHlja2w00gG0AUFVX3lxTE9XX0R6a1N2Yk5naGtQVGc3TGhOYThHM3l6UVFCc1lLMHRzMVRON1RtVUVqWDZjaS1fTU5LWVkxSmJhbHFVc0NCZUtSVEpHLW00TXBSOGlQS01waE9PTHQ3dnN4ODdVOWRpSXhEaThBMUltRFVUeU56YmtzMTJ6QmsxYjBEem9MUzUyLUtvTDd1amZ5V2pRUjluNnNnaTUzOV9LNDRnNnFvMnM4OUZOdnRFd1NHcg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Rhode Island",
      "district": null,
      "headline": "Rhode Island shooting: transgender father kills son and ex-wife at school ice hockey game",
      "date": "Tue, 17 Feb 2026 08:00:00 GMT",
      "source": "The Times",
      "url": "https://news.google.com/rss/articles/CBMitwFBVV95cUxPMzRIbEtaZFZYVHZqbHVLckVPZUk1enRmYkhYaEZoSHVRdWo5V2lLMnJjTHVqYkZqN21NTThhVUl6c0Q3TDZKRHhZQlBPSGtWaGdKQm5oWFhEMV9tZThVaXNwb0FlSjZVVFFoWF9HMm13TkpZYkt6dHFZZ1M2aDlDMGpTeVN6WU1fVnd0dkJ6T2hmZENLVXg2MFozcDd0N2szUnBlM1RTZE9yNER3SGJZMzduWFJzYWs?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Dakota",
      "district": null,
      "headline": "State Senate backs school cellphone ban",
      "date": "Tue, 17 Feb 2026 08:00:00 GMT",
      "source": "South Dakota Searchlight",
      "url": "https://news.google.com/rss/articles/CBMiigFBVV95cUxNZ0Vod212QjdIU3htVmpkTEF4aUZpYTRYMXpBdVBXYm9fY3Zya2FhUm5wc0RUSGYzTzFXU3JoNWRPRXdwUllQc0RHenRrbTVud1VMdFItWDBJa2N1S2ZnT1M2QUYybU9TeWx0QU95Q1JRSFhtaUtIYjg3N2c4N1k2c0ZYbHZZYl8xM3c?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Mexico",
      "district": null,
      "headline": "New Mexico school cellphone ban clears Senate in 32-6 vote, heads to House",
      "date": "Mon, 16 Feb 2026 08:00:00 GMT",
      "source": "Albuquerque Journal",
      "url": "https://news.google.com/rss/articles/CBMijgFBVV95cUxObDh2dC1IWFNuOEFVX3Uwamx2cWVlZDZUVEdCN3FoV2ctc2ZDWVhrOXZFaVR1cUFGNkp2RnpxRnRvcTQ3OEJ2aXNnaUktdzdvcjhCM1doTTlOSnU1aG9sMWtwSDh6WTN6WkwyU24xR1BBbkQ3dHFIbjdhT2hCUm5EbXpJVUtudFpXbWpLZXV3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Mexico",
      "district": null,
      "headline": "Bill completely banning cell phones at public and charter schools in New Mexico moves forward",
      "date": "Mon, 16 Feb 2026 08:00:00 GMT",
      "source": "KRQE",
      "url": "https://news.google.com/rss/articles/CBMi5wFBVV95cUxPUWFJVW9fbXRNbWhGWjRLUXBMcVBmNTZ1YmNzYXh3d2VSbko3bmFjeC1lWW5FaDZCZFNHaHhrcmVUaEdpMFZzal9BcDktNGVCRmlBSmlKTDRzZG5aQS1GNmgyRzZKQ3VsRlktNVV5aGtvb3ZtdzFoX0lqajgwdlU4Y2JUWUtWMU1LYkItdE9VTUtXZGFPeUJGOFZIcVJhbHl6OVJrX0ZnUnh3QjQ2SXZUWGJ5WnR0c3pWdF9kMlJWY18wemlRZTRna2lUMjFhaWZYNHc2cWpBNUlUR3Y2SHh6cm16ZDF1cGPSAewBQVVfeXFMUFNmZW9oMUUxTENqblQ1ODNKQ0ZfNEhHTlhWazZJMzEtejhIa3g1Q2VzLUxmMmxsU3Y0akdyMVBtakY3d3dPSHV3cUx5dTN1R1ZqUjdDUXFNZHdhUXFCZkFFbE5pNktEUnVSTlA3QzZjcnZaNEZ4STdybGdvdHA0TEFGckZWUER4ampHQmwzU204aHpPanRhRWlDemRLWjNFSkNyb2U3bXNwQVpPU0NUM19WYWhnYmhORmppOWlKZ1BQVHVkb3FMaEE0SWNlWTk3QUF6SHY5aWp2ZU1zdlpZd085Z2FRM055Y0FsTTM?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Mexico",
      "district": null,
      "headline": "Bill to ban cellphones in New Mexico schools nears finish line | Legislature | New Mexico Legislative Session",
      "date": "Mon, 16 Feb 2026 08:00:00 GMT",
      "source": "Santa Fe New Mexican",
      "url": "https://news.google.com/rss/articles/CBMi9gFBVV95cUxOY0NSa2otelcyQ01PcE9KSVFUUXJKQXV0dm1HT05tZmNOVHFCYWZZdnhmQXJ6RXZSX2d5R3k2ZGJBN1RfclRGby1rWFRoaXh1ZFdNelMtVnVaSVZJRmg5eHZJMF9yTGhMUjBXSm1LeUJCRlZlZUxXdHJtd3M4VTY3ZF92Q2ltNk1IVFg3djVhSFRSYjk4VzF4UFpXbFBxcWJ0Z2w1S3BtOGZRVmZOMHlQRS1XZXBHSHNtR1dWczU5ZWZqcUU3WGpZanFmdzF2NzRQYVNnQnhmQ2t2ZF8xckdpTUw2UE80enluTXVyeEQ3YnJlb1JqOUE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Montana",
      "district": null,
      "headline": "How Michigan’s classroom cellphone law affects Mt. Pleasant, Clare schools",
      "date": "Sun, 15 Feb 2026 08:00:00 GMT",
      "source": "The Morning Sun",
      "url": "https://news.google.com/rss/articles/CBMiswFBVV95cUxQc09rU0VweE1qWU5NVGNyNGlNd1d6bmhfSU5fU190OWhMU1BzeXlOcjlxZjNBZU95VmRHTElja0VDTWF1X3Y2NC1RU3B1bk9udjZ3VnozTU9wRm5VNXNUSVB5Tmh4dTRYRVd4S2I2SVNrWGRsVmRFdk1oNkdHQWppUlotRWxaSkU1UXRnNU11OVRlNVNLMmdEVG55SldhbmRlbUlFZjdlWFQxVFI2aHBVanEzTQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Hawaii",
      "district": null,
      "headline": "New rules limit cellphone use in Hawaii public schools - Honolulu Star-Advertiser",
      "date": "Sat, 14 Feb 2026 08:00:00 GMT",
      "source": "Honolulu Star-Advertiser",
      "url": "https://news.google.com/rss/articles/CBMipAFBVV95cUxNV04tcXNoaUUtTVdQc2N1M2pIa1NaVWtINHF3ZTVRUGd3bkF2eG5iVjFQcDJ2TW14UTAteFpldmcyeV8xVzhnSXVwSU51ZW9zVTU5SzQ3RGUzNFhwN1NfYk9ORElkQXdMM1haT3lHb25SRzNfWWw1N2g1d0hTMVh1ZjN4ZEFoREZmTUhwMkE0NTBXZlhpeU5WaDZfSmkzUEhpSEtjUA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "California",
      "district": null,
      "headline": "Opinion | California schools that ban cell phones make students want them more",
      "date": "Fri, 13 Feb 2026 08:00:00 GMT",
      "source": "CalMatters",
      "url": "https://news.google.com/rss/articles/CBMiowFBVV95cUxOU0ZBeW9GeU5JQldOd0lKanB2YTNSc1JEUVVUQnk2TnZGejBRM25YSUxHY0tMTHdacmFvSW9zelNtbGtqNnY1NHBibEE2NWFseGd5ZGZGVklJVE5qZ0FZM0w3OVdNN09TdzRrUHRCajJ2WVN0a21XNVRGYk43U1dNWndFa2J1eEhnY2dBYkdkY0RrT1dhQlU1Y0FxVTJ4VElFdVJz?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Hawaii",
      "district": null,
      "headline": "Phones could be banned during most class time next school year",
      "date": "Fri, 13 Feb 2026 08:00:00 GMT",
      "source": "Hawaii Public Radio",
      "url": "https://news.google.com/rss/articles/CBMiugFBVV95cUxPX0dSQVBEMDBCODUyUkNqeVJZNnVDekxON1hrSXFfekpxVzZuOWtwR1dtQXBwY003cUN0WGhISWdFZWFULWVxOXBsOEhkNGYtMHJsbVA3YzBOeFNkRDR0SXU2aWg1aHU0dnluWGd0dmg4aE5yV1hOTzVCWmhOd21PV3NYZWFCWEFSS2laTEo5UFhsWjZFa3JUZ2pVQnk1am1VSGNRbHU3cWtMRHVfR0wxcGhpSlJlbGdLTWc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Mississippi",
      "district": null,
      "headline": "Mississippi bill could challenge Supreme Court’s ban on school prayer - Charleston Sun-Sentinel",
      "date": "Fri, 13 Feb 2026 08:00:00 GMT",
      "source": "Charleston Sun-Sentinel",
      "url": "https://news.google.com/rss/articles/CBMisAFBVV95cUxQZjV0aGJkUGZfekV2bmc2NFhmQkFDTWN4SUQ2UmhxQW0wUlRoTlh6d05zdV9na29SenM1WHZzZlNQdTJMOGUyRGdNNVRJdlFSdkJDNm00WHVubHZVbEF5NmhDSVEyQ3BaWE5wUE5sRzFPenFHeW1lWGhfeGJReGdCc0h3STM1bkxsQkhfeU45TUVsaVI2eG5QSjdkWGFfM1ZzYmlUajlMcW9BOXluQmoxMQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Mexico",
      "district": null,
      "headline": "Lawmakers race to finish big changes for New Mexico schools this session",
      "date": "Fri, 13 Feb 2026 08:00:00 GMT",
      "source": "KOB.com",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxNZ3l2bkZoSGR2bnBpbG5iaG1nQ0VfVGRfWF9sSUhobWo0X1JCVGJNRU5vOEQxZTNhQTVtSWxOaDloWjRGVDFfX2U5YjN4Z3ZEN296QkZ5OTZGM3BZT1ZEVXRFMkpVT0lvUjlQbWpwb2ZfazJMTjl2eHF1ZkdKbTdFVHR2UGNLbUkxMFh6T2l2aHcyZnpvSFphMC1wOGpCbmRfaUNrczQtUGpyT2M?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Hawaii",
      "district": null,
      "headline": "New rules on cellphone use in Hawaii public schools begins next school year",
      "date": "Fri, 13 Feb 2026 03:32:50 GMT",
      "source": "KITV",
      "url": "https://news.google.com/rss/articles/CBMi5gFBVV95cUxQczZNRjdnS2lDajVBWDVfZlZac3U3TkFCRG9EUGYzb0FIMUZJMlpSUkx6WkVuZDY2R2Jvc0JNMk4tbkx3ZG5MNUsxeG41RXRSSjNmWkNHbUo5RmpMWWZDczFqV2pGSlNySXBqZFBqNU9vSVFYQXdwTmlzcURwQjIwOXNIU0VlSXlwMFhEaTgyb3lVc2oxZnZxa2drc2kybHFpcnRudUhfRzh2Rl9sM3pjMlFwQ0Z6TThuVWRZMXpuUTV1SXFldFI0VGstbS1LNjA5a2h3TWktNlhGbG1FeUgtejVBYWRJdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Iowa",
      "district": null,
      "headline": "Iowa receives ‘C’ for school phone policy as districts weigh full bans",
      "date": "Thu, 12 Feb 2026 08:00:00 GMT",
      "source": "KCRG",
      "url": "https://news.google.com/rss/articles/CBMimgFBVV95cUxPQlZEMlFOandaclVQa3lyNHBUOHVLekY3bGwzbUZzR0FQV0EwdWFndWt2ZTNkT24zWGFXbnBNLXR2WldocUlVNmZlaVM5SzAtU2F3cnRNbnBuRFA0emZLdjdrcXFhZVVOd2loSXFjLV8zLTl2NGtJcDRCcDdPWDN3c3ZSODZ5NkE3bkVpdHgxb0NCdEtPd0NqX0tn0gGuAUFVX3lxTE1oMW9DTHJfWjY2cWlsOEZpWlp5ZkNMb1VNaUl6MllVQkRtdTBjQWhxc0pjVDM4SjBBUF85cWhycjhCSmpXQmZYcGV1VWhpaThJSlhzOUo4a05iMjRjSGxtZ2h3LS1vai0tdTB6ajAtWDJ4ZTAxeEhyVTNVdUV4dGdkS1pBemhMWmp0cXJBa1hVNXYwSFhoZVV5bDF3Nk03V3Y1ckFNUTBvWjZNWTBsZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Mexico",
      "district": null,
      "headline": "Lawmakers consider a statewide policy to prohibit students from using cell phones during school",
      "date": "Wed, 11 Feb 2026 08:00:00 GMT",
      "source": "Source New Mexico",
      "url": "https://news.google.com/rss/articles/CBMiwgFBVV95cUxNZ2swUUhzazNORXNLYVAxMl96SXJvWGhybUFDQkpCZ3JDSW1xZEo1VkFyUjc5MzRkVDBYS0xnRUhoQ0g2RmxHYjBRUU54VW5zbVRyWHc3c2xiSEx6ZmhMZnRISW1hUzNDZWFKd3dFTFZtUFk3TzViREpqWENvS0JFSFZHVEFFRjVJN2w0SU9TR3haWExTYk96ekhGTWo3Si1MbVNONDR3STNySHNlMHE2Q01ZUkNrSWI2eWdZM2lBWXJ0QQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Iowa",
      "district": null,
      "headline": "Legislators in Iowa, South Dakota look at mandating school rules on dress codes & mobile device use",
      "date": "Tue, 10 Feb 2026 08:00:00 GMT",
      "source": "Siouxland Public Media",
      "url": "https://news.google.com/rss/articles/CBMi3gFBVV95cUxNNkt5a3Z0SXpsaDNhallxb1JDbGo4amkwNFlfSlBZLXptTWp0bHRPa05yTnVORFdnREdON2tNLU5CUjV4WmVMVW5KWld2Ym9vWDVZcDJQV3UzSkk0anFNTG4zbVp2Mjk2UGR6X0t2R0VHS2VWMWtlUFg3Z2VNNWp6eHB3M2d1dU1HWEluTERoQS1ick15cHRXYjFFLUJFOHU2OWZtOGl4Q0ZqbzZMa01STjRpV0hNNGNaMUdYSG5xaHlSRU1zRjhZVVFvTWZOT1U4NFU3MXBiWnNkVlFBQnc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Dakota",
      "district": null,
      "headline": "School cellphone ban stays alive in South Dakota Legislature",
      "date": "Tue, 10 Feb 2026 08:00:00 GMT",
      "source": "South Dakota Searchlight",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxOSlVfN0lfQTVIYlJiWlpLV2NBVjZNT2NScDJ1dG1XeWZzcHY0X1FyMGlvSExEa19vOGRnWFBhUGNVSFVaTlgyWWE2dUtmQ29jZ3RfM0V0b1NhVXhiN1g0dktfcjQ5TmhFVV80d1pjUkViOG9veEx0QVNNOVVjR3BDRDE4Y1FFMjdHMWh1Y2VvLXlNSTB4VWkxZXBhWU5xbUJwNWc2dENHV0twSm8?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Dakota",
      "district": null,
      "headline": "Bill that would prohibit cell phone usage during school in South Dakota makes it to Senate floor",
      "date": "Tue, 10 Feb 2026 08:00:00 GMT",
      "source": "KOTA Territory News",
      "url": "https://news.google.com/rss/articles/CBMiwwFBVV95cUxPZU02dXVJdDJpemJoQk1nWEVDek9IVHBKNEtGd2tnTmY5c3RqZzdSYzI3NFJtemZReTJWbzBjTWxTT2tVSGs2V3dfTDhsMVQtdmRkVmRxZlU0VGl2d3p3MVc3MHZCbjE3MWpNSXJJbndZTVFKcnl3TW9EUnB5U3g5SUFDckg2ZGxOczVpUUxTeUZJYTNZX3VZdnQ3Z0FMYjlpUHJMZTQxSUZGVzU5MS1rOGpBY2RqYlJEZm1oeHNRb0Y5X2fSAdcBQVVfeXFMUGQ2YzkycS1uVnJWY2ZOU2RDTTNMaVMxd3BkQ19fRmozeG5aM0FhNGxINWRQYzRsWlRxbDNvYUl0QUpMYmc3LTBFTjMxcUJRVGhWeVdLcEh6ZDZSQ1dOZEoyV1FVZmN4UVF2TjBLSEZOVnNmVl9OZ0VBTGUyZ21tQlVNRzlKcEc0ekhOV1Bsb0trWFhnOVhpVHBoYks1dTZrWmpnYTlLQ0FBTUR2dFRPZGtGN0dvcndGMXZiZGFnMUp3VEhwM3pVVkVuNVBPX3RoM3lwb29Ka0k?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Mexico",
      "district": null,
      "headline": "Bill could completely ban cell phones in public and charter schools in New Mexico",
      "date": "Mon, 09 Feb 2026 08:00:00 GMT",
      "source": "KRQE",
      "url": "https://news.google.com/rss/articles/CBMi1wFBVV95cUxPZ1JfMFhldjE5QVNNMTR4Y0plUlMzQnloclVKOWU1WkE1MHk3ckc2VzdLaGRPLXItQ3NrczRHb2VxZTNSb1EzTy10czlUYnM0aGlTS0NCTTNzVXcybGNnVDlsVGhYNXZ5MkhrZS1qUlR0VC1wNW84a0ZGckFXSmV2WURiNklsaEVmdkcyenhyYmRYS1RpMzBHV0xoS3JTT3FFSXBiQ1o5SC1xUVBna3B5NjdGclJENEtvZEZaazRYQ1FTdzlIM240ZWhmMEVzNU11VEhpRTNEd9IB3AFBVV95cUxNUm5FcDZ5ZjJQSHNJQVcxMTN5ZC13SzQ2MHNhNU5vZHRaOXVWcW5aWlBhbnQzWjVWSVFCRlRHdTlSaHB3UTlzYUZJSktyc2pFNGZRMDdMRnBJblJ3MGY4QkYwZzgwWmFGWEFYbFVreHRTMGVmazg4MXdtdnoycFAtMmxINGlrbjRhSFFodXBLM1B6LXNTOF9MMVE3eU9nT1hjYU9ZSUxxeXB0RE5sbVJlTkF5TWVOSVlHSzZhSF9Eem00Q0dZaGtKbFdHZGJmX2RUeFJoMFc5bVNWeWMx?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alaska",
      "district": null,
      "headline": "Alaska schools projected to lose 1,500 students, state says",
      "date": "Thu, 05 Feb 2026 08:00:00 GMT",
      "source": "Alaska's News Source",
      "url": "https://news.google.com/rss/articles/CBMiogFBVV95cUxNQndaM2ZrUWFjLXJYRDJYRERmQU5mQ2ZoZmZ5R0NqV1pPUGEydXVvWm9qRnBVeXVGeldlWnRDVHFKVU9wekM0SWNGY2hDclhCeEd3bjNNV0ZtXzk3NmdXUHVySGh6MzdpVXNGWmdMZlBIaUlEUnRrQlpnZVVpaWJjN2g4MUVvanoyb25VZHY3aU5YMjJqa2VobW9NZmR4OEM0T0HSAbYBQVVfeXFMTXlpcnFEV3VIWWFRNWhCTTd6Yl9yZ0NwNjRCMkRhM3ZQaXFZU1JadGRPRFVPY1NEWkJqc1dwZDdVcVlDUXl1dGdfVmJTWmg0bkVfY0JHS2x4anJwQkNncllwUld0YXFXZ1FVUHJzTmM3YWIzajhsRm5DZVktZHRuRVVPcS15WHl2TTJtYVZHcEVLU0MwZjJGbmZLd0tKVy1MWkZ5amdfMmlkYTNwMWx2OEtFaGVNUkE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Idaho",
      "district": null,
      "headline": "Idaho teacher sues state, school district over ban on “Everyone Is Welcome Here” posters",
      "date": "Wed, 04 Feb 2026 08:00:00 GMT",
      "source": "KTVB",
      "url": "https://news.google.com/rss/articles/CBMi9AFBVV95cUxOc0NLZVVRMkFxbGsxZ2N0QjRzbGFhY2d5S3JlOTdCZ0N4Zl9fYWZ5Q21PVUxaODBzS25xazZCZjJZZWZseVhJYXhWOG83SDVXZkVySDdCMVVuQ3pDYUxvV2dZLWUyaUFCa0Z1SUpyN0oyS0lDdy1NUFJjRjBnUjRIRjY4WUxZSTQ3MkM1NUpIN1MteFVmWVRzMFBOZGRPUE1tSWQ4cUxlV2lLcUVzbTVHZk02M0VtSTVXUGMzdFJrWGxrYUxxOFhuU2hvbDFINGR2X00tSjh2anBKTDVia1c0N05sa3VWWmxySHlEaUJrN292SHFk?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Delaware",
      "district": null,
      "headline": "Marijuana fines, school phone rules advance in Delaware: Press Room",
      "date": "Mon, 02 Feb 2026 08:00:00 GMT",
      "source": "Delawareonline.com",
      "url": "https://news.google.com/rss/articles/CBMi1gFBVV95cUxNLUVaM0lHX0NfakRpSS1Pd0x4TXFZd3R6d2lRbU4wSXYxT05YYVBVWFljbTFkeEdZc2JiTmN3OXRKV0RzcnJzRlVqLVhPcVcxZ0QzZmxkMmZndlp3UEkwTTR0NkJUYU1CT18xb00yOGxmNEtnU0owNlRZQTdwV2VveVIzZUh1MVBYNnJxZllUbW1jcU5KczFpR3dyc2RoMEpELThWaTQzTDQwbHVlb1hnS19kV1RHMTNYZEVHS19CNG9KdUh0dVpHMm1vbzZEVks4Zk05U1Zn?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Rhode Island",
      "district": null,
      "headline": "Hundreds of Rhode Island students walk out of K-12 schools in protest of ICE",
      "date": "Sun, 01 Feb 2026 08:00:00 GMT",
      "source": "The Brown Daily Herald",
      "url": "https://news.google.com/rss/articles/CBMiwwFBVV95cUxPMFpTYkhpaWZRWkFWeFVsdndFV2lGU3d0b2dURVktQnhrTG5KcGh6bHNid19PZXRjU2pJSWczV1dGWEJOME5ZeE5kbG5TNy1MRGRLcmpOc2wwaWwxUXhBNXJDVjN4TkIxTFBTWExreW9xYjVvVFk0VXRzZnBPQ3RkOVpJemRNck5YY0xjZ21sV1c2eEl6U1RzVnlyTUw0NndPRU10ZHZGVmI3bkZQMF9uYklSUzZDdTR6dEo5SDZhZThZemM?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nebraska",
      "district": null,
      "headline": "Car Hits High School Student in Nebraska During an Anti-ICE Protest",
      "date": "Fri, 30 Jan 2026 08:00:00 GMT",
      "source": "The New York Times",
      "url": "https://news.google.com/rss/articles/CBMiigFBVV95cUxPUWhCN20tZ2NGeFVaT2NxYXNaUkJheUxBVmxCbHJJa014Q1QyRkI4THhtZHo4TGZfQ0Y0QTc2N2hyNTN2UWFraVF1UHQ2ZGE1MTh1dEowQlM3NWxoZnlXa2Y0RVBobHBmdGtlZXFHRkVSSTlrbG4xZjJ6amt2Vi00S2pOY2hQVDRDMWc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Rhode Island",
      "district": null,
      "headline": "Thousands of Rhode Island students walk out as part of a nationwide shutdown and general strike",
      "date": "Fri, 30 Jan 2026 08:00:00 GMT",
      "source": "Substack",
      "url": "https://news.google.com/rss/articles/CBMie0FVX3lxTE9DOFVncnlzRERoQjQ1THExZU1zekVtZVJpSmJwVnRLX3ZDaHB6MkZSSGhaT3lNNjNHMTUweFJ3QVd0RzF3LUJkdF8ybFdOV0NFZmFqRW1BQWY5QWxwUVRkRFh3WFlZUE1XMlBwUk9WUEgzQnVHOUdvT2pFaw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Florida",
      "district": null,
      "headline": "DeSantis seeks to supplement Florida school vouchers with federal tax plan",
      "date": "Thu, 29 Jan 2026 08:00:00 GMT",
      "source": "Tampa Bay Times",
      "url": "https://news.google.com/rss/articles/CBMiwAFBVV95cUxNbHc3enhjSXJ0eWJCbEdlT3Y4dHNlY083Y1R4c2JoRVJZYnhKLVI3a2didWtGVFc1RWJIMk00V1ZqeGNWTm1IZXZONXB3cmVUd1FvNm9TQ0VreV9rdU1qNGp2R211YnRkNVVMSE5TZ3E0Q3UyZjhkNEJYejNhMWdKcnpCU2RVTW5KRmhidE9QRlNyTDd3a3ltSUh3VnRMQXpPZ3kyaDdYMjZnaVdOS3hpdWNDYTU4TkdOenpwX2ZMdDY?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Montana",
      "district": null,
      "headline": "Briefs: Unlicensed teachers; Summer meal program; Phones in schools",
      "date": "Wed, 28 Jan 2026 08:00:00 GMT",
      "source": "Montana Public Radio",
      "url": "https://news.google.com/rss/articles/CBMirgFBVV95cUxQUGU3NG5lUEdrbzQ5c1NDYkJSMktsazdPZGpucGRON3FEVktucjhMS0hoX2R4VE5FYTduUzBKNlBsalhNR3VUbU1leExkb0Y2OE9iUHc2TUhBUzNyeUFhanNVT05aMWxUMGVVNDdUUU44NmNOWlAzSl8zUDFYcW5kV3RrQU9rQVFFUkxOZ1lZUWdmMXNoOHRGMmlZRVAwZnIwQkVyZ2tPY1NzUi1qMWc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arkansas",
      "district": null,
      "headline": "Arkansas earns ‘B’ on national phone-free schools report",
      "date": "Tue, 27 Jan 2026 08:00:00 GMT",
      "source": "KNWA FOX24",
      "url": "https://news.google.com/rss/articles/CBMioAFBVV95cUxQMlZPRkd3Z0N4VWpHRlVsX01hU3hsWFBGZXBzd01vdXJWUmpOaWkyVjBUYmNfZ2xFazljc0lwSzFldzlIcGRJSGRLSVZNa1IwbERnLVFxM19BbzNnV0RFR3NmaHFOT3FPYkkxWG9YZEw0TERJX1VOUGpqYlFobHlfVDE4bWN0WklPRXg3Tmd6cDlYOHVoUnBCVXFKRlRHX01D0gGmAUFVX3lxTE9SQXJVcGd5a0dyaURfSVRkSTZYYlVVTnl5MzJVd0NQeWJBWHdocGRaRmpTek1ydjhEczVQWUFHMlg3dGdvRENNeDU0M3BETkJfZEd5aU10Yk5RaENVZUN4WmNib2NscEpvcEZhd1dhbFdGelhPTVd3X0NjNnV2b0VwQzRaWXh2aTUzZUxybkx4QV9wNk1RRGpQSTRLcWpKRnRrSkY3enc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Idaho",
      "district": null,
      "headline": "Measles on the rise in Idaho after school vaccine mandate ban. What to know",
      "date": "Thu, 22 Jan 2026 08:00:00 GMT",
      "source": "Idaho Statesman",
      "url": "https://news.google.com/rss/articles/CBMicEFVX3lxTE5KVVVSTVN3bkF5bWdlbkwwRjZCR3lXOXRydVNHdWRYUTRfalZISTZ6bEF6Q25FNmJvNFJoYlU2VkM5alVSTmFrRjZITjBFZXBUYjlNcWlDejk4Vl9lbXRLcU1MZDhhN1pUVm56Z1lhcETSAXBBVV95cUxQZ3lUVDFzVzB0ZXJ1NnkwSXVoMjV1SWMtdE0tZW1aZEZrVGY3N1N6Ym1NckptX0pkWDh6RWlLX1E0SlVYdTBhVk53UXJ1c3haRWFmWHJ5a245RDlpYzVYeFBtTm5ubXpWemFuU1NoS0FH?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Tennessee",
      "district": null,
      "headline": "Tennessee's school phone law gets C grade in national report",
      "date": "Tue, 20 Jan 2026 08:00:00 GMT",
      "source": "State Affairs",
      "url": "https://news.google.com/rss/articles/CBMifkFVX3lxTE41UlFiMDFfUE1oRzJCaUdNbGJPUVhUQ2dVYkNnTG8tZW55OWxfcTB1OW9GS2djVm5reDRZZjM1WmVvMWZpTGhoVlBxNU01dFh6Sm9IYzBUZTh0a3VNTjh3YzBKRURINFE2Rm04MGhKU19vSWpkWFdCQl9jWlN1Zw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "West Virginia",
      "district": null,
      "headline": "West Virginia gets C in national Phone-Free Schools Report",
      "date": "Tue, 20 Jan 2026 08:00:00 GMT",
      "source": "WTRF",
      "url": "https://news.google.com/rss/articles/CBMilwFBVV95cUxOVERlU1JjeWp1aWp4bmxwazZha3lOTVl3MDg1eDd5dGctb3lCVEMzbmpISWE5Y3JFeHU1RHBPWlRJM29fUkdQUjhYX3ZFMWlHaldLX0picG9rZHdGclhTNkQzbVFNWVdibG9Pcjg0ZWV1RUlfSnM3el9ZTVFlRmc5dVdSLWltdms4NDJDcUdOcHFHTWt3anNz0gGcAUFVX3lxTE9raHAzQXJDeTlJaHR0SFlhRnRWM3dCSTdvb2RfREFpd1FMNGJSeHI5RzE3V2llbk9sWU1fR3VvNmlFaVQ4LWNZX3BuRjYtamcwU0xqd21BSDU5NS1zNHlMU2hfcUxDS0hvNHlJNFB4cWZlbzBnUmV6YjVVbm8xYWpnbnNWTWxOWmxjYmtFUDFJc0UxT3p6SmtOclhFdQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Delaware",
      "district": null,
      "headline": "Delaware talks guardrails on AI companies and public education: Roundup",
      "date": "Mon, 19 Jan 2026 08:00:00 GMT",
      "source": "Delawareonline.com",
      "url": "https://news.google.com/rss/articles/CBMi-wFBVV95cUxQdnpSbEl5anB5RWFHWnBrOHNBQXo4MUhNaFZlTnBpeEhpay0tLURfTlBMNS02dlZtUE5vUUszSkU4VWpITHphLS1XLTdJd2NjbDRNdmtMd0xRU0hMSi1fMTlxU2p4Wko5UFVNNFhyQ0pNUkEwZ1pHeXBidXdaTm1rdTQwOExnVC1nVTRBenh1OXlYSm9FSDg2MDVrcVZWWUxjX3ZLU3VsNFROYzlsSW82OVpsc3haQjJHbWFVVC1XWVEyRDFPX3ZJWXlxaHRndE9mdHhIQ3I3dDhVVms3cTEzbGtYTHFMMlFfbmFEZEVKWUNsN25JUUV1Rkxsbw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Missouri",
      "district": null,
      "headline": "Kansas eyes phone ban like Missouri, but kids are split",
      "date": "Fri, 16 Jan 2026 08:00:00 GMT",
      "source": "Axios",
      "url": "https://news.google.com/rss/articles/CBMiqAFBVV95cUxQaVZQRGdkbGo4WXN0NmVCbVFuZzVBdWtta0EwOW9DRFNKOGJLUUJnb2FqeDlMYmNIX1VqblVyWXpVWUVuNjhScVpoTkhOWDZ2RkpMbkR0UlhUVFUtM2I4SlpvVU90NGR0VXVPb21JTlRHcXFlVm83czB5SkNwNkFZWHZxTnQ0dVYwTnc0dXhBQ3RNMDNBX0d3aFVjem1jZjBsV0o1TUhuXzQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Montana",
      "district": null,
      "headline": "Montana school wrestling team denied service at McDonald's restaurant",
      "date": "Fri, 16 Jan 2026 08:00:00 GMT",
      "source": "KTVQ",
      "url": "https://news.google.com/rss/articles/CBMipAFBVV95cUxONkJjaUstM1lxdTRYaGxTXzUweXIwQ0VjczdiaFBMMkZLdzN5VFJuRkhhS2RKTEtTWVhWSU1fWUxDcnRTQXB3bVNFaW5LOEktc3BvZEFoSThyVU9VSE1PU3NqSmoydDdpMDEyNVRicV9aLWdEb3d0UFdFYnNZWWZTSGw4SEVrWmNCMHFrX2NvSndVaHNObV9WTDVuek1ZMkNtOF96cg?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arkansas",
      "district": null,
      "headline": "Arkansas schools see positive changes after smartphone ban",
      "date": "Tue, 13 Jan 2026 08:00:00 GMT",
      "source": "K8 News | Jonesboro, Arkansas",
      "url": "https://news.google.com/rss/articles/CBMilwFBVV95cUxPdEJxUk9QZVNPZ3ZTdDkwaHZKdkhRY2JoM05tR0NoWE1ueTcwc0djend6RFM3dXFaalpuWVdLYzNiME0taW10eXBYUG1ncURUeDREM2Judl9QazN1cnJTVkpqRkVtUXBIVnpaYVNIdVlTSnFGa0dsVldaUFhKT3lzVjJ2bWlYQ0hoN0lJX2h3Q21xTm9aM0d30gGrAUFVX3lxTE9SeHhObWhPLUdTQlRxZFdGYUFRamtQVV9TSmN3aW92T3B2cGVVMk1FTTVQamV6b3BuNXQzemRWQkdfaDFhTGVkU2hPTldGaUVVYk1NTGdaVzF3TUprRmd3X2xiWk1ycEhvUjZHRGROZ09pdVVpZkNPNDZndWQzRWV1V1FpdlQ0SWNWdG13b0hqLWo0RkN0Uk1qOHRMNGVFbTFqYmROcVFpbEtxNA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nevada",
      "district": null,
      "headline": "Nurse: Carson schools will hold to state vaccination laws | Carson City’s Trusted News Source Since 1865",
      "date": "Tue, 13 Jan 2026 08:00:00 GMT",
      "source": "Nevada Appeal",
      "url": "https://news.google.com/rss/articles/CBMirAFBVV95cUxNeWhFU2Q5Q2RTV0F2S1lTb1RKb3hkQWZCdUlfZUJvTXgwZDQydlAyQTVncVlUVUtvWkdsNW96OXVyODNLelZoempRaHlyVW1UcDJjMXpUeDQtdU9ZUU15azNkR3FHOVlxMVJBTnpidlVteFRZZm82ZnhkaG5NUmdveDBCNjdtczE0RVBkQUNOX2Y1WUlsZUthN0hRWHRGT0xqY19jMEZKZWt6VXJ0?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Carolina",
      "district": null,
      "headline": "Governor Stein Holds Teacher Roundtable Highlighting Impact of Cell Phone-Free Classrooms",
      "date": "Tue, 13 Jan 2026 08:00:00 GMT",
      "source": "NC Governor (.gov)",
      "url": "https://news.google.com/rss/articles/CBMi2AFBVV95cUxPYUNKWFJYbWRaeXJISGhfNngtc0lsUHdvN1FXWDRfcDBUM2tyeHh5T3RmaXA2T2hHQ3RpLWpRaXNlREdtekN2TzlON0dleFA2LXJTNm5nLUU3Sm9rMHB3Qk5STWF6MjZwZFVzZVpuNml4eFV1bTE0MXc1amwxN3VMbW9HX1R6d0JuRjBPRUZCTVpiTEdXemFhLXRWR3JGRnRORktQQVh4dlNKYy1XUHhNSl9FVWZyczNtMVZPbjRqNGlWSTVzNTRKLS1SbFY4WmdhRHVPRWlLOGw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Carolina",
      "district": null,
      "headline": "Charlotte educators laud North Carolina's cell phone ban",
      "date": "Tue, 13 Jan 2026 08:00:00 GMT",
      "source": "Axios",
      "url": "https://news.google.com/rss/articles/CBMisgFBVV95cUxQSkw3NmZsUmJOUEpvdzZHWUt3aFNiNGNVdVVrczIwb21jV1F3Uy1kZHdYOUVRZFNhSXBMdEJQeVl5RVNVbnRPU3V4TXdwRktTYUpkcVczSDhxVDlVZ0I3eUFKa3VwbnZFV3MxNzd4Wk1tbkYxV1Z6cmt4eUI2NzFQWFRsRmdqWEVRNjQ0Z2FyY2FCZkMycWFkbkF2RGdLY0dreUlyOXhDXzFuWjJoWlBEV2FR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Carolina",
      "district": null,
      "headline": "Charlotte-Mecklenburg teachers tout phone-free future as new North Carolina law takes shape",
      "date": "Tue, 13 Jan 2026 08:00:00 GMT",
      "source": "WBTV",
      "url": "https://news.google.com/rss/articles/CBMivgFBVV95cUxQb1c1VUpMOFlvcUl4cTZkR3Y3d2xvMzRldS00dVh0dFFfT1RwcjR4djIwV2IwX2prQW1WZjN4azF5dWJybGhVUFZ0andDYzZSMC1yeE1NMnRxcVNHQXNZa1ZlWGM0eDBBU2dyeGF1STJvWjd3ZXlHTFJMcnlfUWhNSjNhdUtqekZSZlRiWnB0Q3h6cmlaaVB2Mk44UzZEUFFEd3BSZEZ3WHpUMWxWcHc0RGk3dmdLSjVRb0VfSlJ30gHSAUFVX3lxTE94cExJaEcxZGZwSnN5WnA2TFItWjc2NUhZWHc5c2d5d0lfZGliTEF2YU9xWHFWSkoxZGZoSGFfeEN0WkdtTmNYNkpuUkNUZ1hITHIwbjFKNml2dHpyRFppcms0cmFlWEVHaXo5UjdXblB5OXgtRnhlS0RINnNOdFpLTVpjWmkxclAyQXlJajdMeHFra1dzWjQzdjJGMm94cWREak5MbmdWWU9IZGhWNDlEVkN2SXluUUtlRWp0RkJkdTlzY3VZMUh0cDdhZnhKam5DZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Hampshire",
      "district": null,
      "headline": "Some NH schools stop streaming sports, concerts because of parental rights law",
      "date": "Mon, 12 Jan 2026 08:00:00 GMT",
      "source": "New Hampshire Public Radio",
      "url": "https://news.google.com/rss/articles/CBMiywFBVV95cUxNNVp5UGJLcHNyTXZPV2NNcVhwTzhqYjBkRTlkWVdqZHU4dGwzLV9jQWc1b2RpcF9XRldTWDQxdW1iTXNKOHFyV2ktNk9XLVpDUFJSa3hrcE84V3MycnFoM0s4NVJEWUtBblFCZDBuM1o2UldBS3liZmpYYWxTVW1BbXZlMkh2MXZHUVV6LXk4RF96bThicmx2NE8tcGdEWHo4N1ZnNmhLVDVOZVd6T3diYjB5aUhlSV9kQV80SDB1ZzM1a3R0Y2xpZUlYWQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Louisiana",
      "district": null,
      "headline": "Louisiana police are ticketing drivers for cell phone violations",
      "date": "Mon, 05 Jan 2026 08:00:00 GMT",
      "source": "Shreveport Times",
      "url": "https://news.google.com/rss/articles/CBMi3gFBVV95cUxOeEQxZ0JFT1JNbVl0WXJUMWZFcGpSc2VnQi16ZjFWOHg3M29BQWZUSmxIaHdidExidVBsVVVrZ2cyOUlhNmJGcExBaTlBVm9mc2dnMkw4VDkyOXhTdlpxZTBsUFFLd1pEZnM0eTlGeEZhRlpGVC1KUWNMYjZiclBUaWNfcnNSOC12OXR4VUhWNi1BWVNHdHVWVHRwX3pNMjUzYzV2Y2UyRU9tLWdqTlpCQ29NeWNNd1ZlbUpzWFhoVW9QcFFMWWg5QllHNnd2a1FGTkJmdU44NG1kMHgzUHc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Hampshire",
      "district": null,
      "headline": "Republicans will try again to set limits on discussions, materials and bathrooms in NH schools",
      "date": "Mon, 05 Jan 2026 08:00:00 GMT",
      "source": "New Hampshire Public Radio",
      "url": "https://news.google.com/rss/articles/CBMirAFBVV95cUxNdDR6TmR3SEZqNk5Wa1FQZmZqQXhzS3N3Nk9lYUNHb21LYVVUTExQRkFDbW9NaGp3R2NnQ0FQMkJTMTQzS1YyLVhoR094eHphTGNpMzcyOFJOdEc4akI1NWhPZktwS1NNMUVBbHpIMks4NDBlOTgwbEpSX01mWDlsY2ZTSHlMTEdaMzVnRWp5a3JpWGlhT3BYQlNUZzFrYzlIVXhZaTI2QkQ0dVBX?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Carolina",
      "district": null,
      "headline": "School cell phone NC | Durham Public Schools rolls out new cell phone policy as students return from holiday break",
      "date": "Mon, 05 Jan 2026 08:00:00 GMT",
      "source": "ABC11 News",
      "url": "https://news.google.com/rss/articles/CBMivwFBVV95cUxPYVlmT3NYcEU2aktTZS1TVm9vd0lnR2hXM3hGaVJEc0h2U3lhSENOeXdNNzJPY1FaWEhxRm1jek1tZmVfenJiRllxekFLZkI5NFYtb2ltRUlIUmNXdk5VVklPeE13OFRRVDdSWmIycHhjRTcyZGlyX2puNkdLUDE4NWwyTEJBWXA2Z3g2REdLbW5rT043MXhDaW5ISlhicHprc1p0WEpBcDdOckhmTnVjV2dsSkFrRG52emZqMTZGc9IBxAFBVV95cUxPdUFjcTRkUkZnTXBJbmlERmNoaDRxSkJZVDlrSzExUzZyd3pkbWI0WlNLS3RfRzZoY3dPR3YyQWt2a3p0dk1ZX3BwVVdnWFgyUzV1TXN6clN6ZDFyNS1JTGp3d3I4bThZbUkyYS1HZW9rRXBFcWR2N2pRU3pOTVotLXRKbDRNYUEtNXpIaUk0cUQ4d2pMaEFHVThNWk0yU2JFU2Jnd05kcFpVa1h0RUo1NzR0S0dTT2wzYlZVeEdITXJrNG9y?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Idaho",
      "district": null,
      "headline": "Idaho killer Bryan Kohberger was a fat, loser heroin addict in high school – briefly turned corner before slayin...",
      "date": "Sun, 04 Jan 2026 08:00:00 GMT",
      "source": "New York Post",
      "url": "https://news.google.com/rss/articles/CBMixwFBVV95cUxNaWh1SFo2NmZKNzJ5QWNLRTVaVW1UcURjN1hSS29pYXc1ZmtRQ1dPVGMwR0RqN2xxTzY4WElHVFdYSDlyOTI4VWZqQ1EwWXg0Tzh3REZpZmtuVnd4UWFCektzRVBHZU01N3NQdkVkTDNlcWNMM0tHV1BXTVE5d2lRR3h5QkZYVFNGTndnaVNSZmRCOWxWT1l4VHlSSkRwdnhOaUVtNzlWemZHTDR1S0tnRmIyWnRCVEFlT2RzT3dualF0OElBaGNz?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Carolina",
      "district": null,
      "headline": "North Carolina laws regarding gender, cell phones in schools go into effect in 2026",
      "date": "Fri, 02 Jan 2026 08:00:00 GMT",
      "source": "The Asheville Citizen Times",
      "url": "https://news.google.com/rss/articles/CBMiugFBVV95cUxPd3dxYXZIRHk0a2FxNmhna0l2NUgzdWdDZzBtcFN3YzB0WlVjSFVIYXB1RjctbTFaTU9hdjAyN0pLX3JOQmdDMHkzNzJqbUFDaExuM0FfT1Z3Nlh2NDhpemtERV9mcnZYc1lORjVWZzRORnRqV0pWMlk4Z09td21oTnNsYmp0LTV2clFHRHhkV0lFOGh0WjFhSVNoX29TRXJIcnBFSWpWYloxUHlwcGVOQjk1aU52R2M2cEE?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Hampshire",
      "district": null,
      "headline": "Phone ban, funding and school choice top NH education stories of 2025",
      "date": "Wed, 31 Dec 2025 08:00:00 GMT",
      "source": "Seacoastonline.com",
      "url": "https://news.google.com/rss/articles/CBMi1wFBVV95cUxNREhVU1dyYXlwTWNrSHJGdzkxc1dDaVVfVVFrN1o5QURWZmVBcUo4T2Nhc0tRSm9RMGpfM3RaRjI4OGJ1ME5iTDRSX1BjMElxRXdQeE5WaVJyUXZ3eEMxd2IwWGN4TzNOaFRiVVNLQ0pYcUg4UnA5YWJ0RnQ4LUN3eks0aXo0cmJDTGtoY1BiX3FTdElXaWZwaWZQaXRaSUdIYy1EMnFhOF91c2ZJRjJZY1AxOXkyZkxrOXpManpJUGQ2Sm5IT2F0MTRsZ1JBeWdoSXRwS1oyQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Carolina",
      "district": null,
      "headline": "SC education agency wants $18M to tell students why too much screen time is bad",
      "date": "Fri, 26 Dec 2025 08:00:00 GMT",
      "source": "SC Daily Gazette",
      "url": "https://news.google.com/rss/articles/CBMiuAFBVV95cUxQY0tRc0FXcnRidnAxZGM3bU1lbVNnMjE0TzRhS256MzFtY3dqTlVFenRJQ2dZTFM1ZkNZUUtUYW13bjRvd0FldU1WOVlDODJIWi05eWFadE9TMGNfZ19LbEl5bExWNGtBZ1VyQlp2LWJmWlRkV0JITnRLS3RGWWYxcXR0WWF0alRWVVN3THc1c2FmSHBtNXdoTV9VMXYyQXZsUGxVSXN1MC1qSEYxcnRzTC1MblVMcUl0?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Montana",
      "district": null,
      "headline": "Montana law of unintended consequence: Legislature wipes out gun-free school zones",
      "date": "Tue, 23 Dec 2025 08:00:00 GMT",
      "source": "Daily Montanan",
      "url": "https://news.google.com/rss/articles/CBMiuwFBVV95cUxNR3cxZVl3M09IRlRpVnNnX1FrdjAteTZ3LWtiWm5PVlMtMGY5UWRtN1NkSEZwaDR6SDNFLW9BWTdNQXZsZWdMUnZGUHMwb0hIWG9XVjhWRDNnd1JXQkFKWk9VWFF6ZGdFOGdLb2oxVG1KLU9qZlVyMEI5ZkoxZENTWjFTTFBPQW5XT3FnQ2RMZjlzRDhTWG9mUU96UlRJVGV1b3hPR1VIWm9OenYyRC1VVTVONDhxeDNmTFRJ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "West Virginia",
      "district": null,
      "headline": "West Virginia public schools increase training for children to prevent online sextortion",
      "date": "Tue, 23 Dec 2025 08:00:00 GMT",
      "source": "West Virginia Watch",
      "url": "https://news.google.com/rss/articles/CBMiygFBVV95cUxNVGpyZ3RXN3hLcUZqSm1uUGh5dEpWbnNWQlN6SEN2cWp0SEZ6SFM5WVVWMjRiSWFhQTZwbFl4SzhzbF80YnpmOFU5cXJEWTJnbjBQcGdDeGoxWUZKWW16RXZJd2lIeU40M0ozT1p6OUZ5bWxqblN2ZDlQZE5wTUpqY1d4TFNWUnZJd1otVHczVGNhTHhUVHhtVGVXZUhwSjJkWEstMkJHcGxvbUg0bFNiSTk0SzRwM2l1d21SUEdQNTZsNUJENUZQUGx3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "West Virginia",
      "district": null,
      "headline": "West Virginia among top 10 states where kids rely on smartphone-only internet access",
      "date": "Fri, 19 Dec 2025 08:00:00 GMT",
      "source": "WVVA",
      "url": "https://news.google.com/rss/articles/CBMitAFBVV95cUxNQlZiM2JTOXFxeHhVMnRFWFpvVG9yOUgzOXM5bVJzaWFCdng4c01BT0lXbEFGQ1dodjI5MnhaUlM5YzdvclJxdXFzakpBZGNoWjZPekp0eGN1SF92WFV0WVQwTUp4S2ZXVnJnWDluQmpldVg2U29xSjMwUE1MaWkzQ2l2MnVuNFNIVE9jaU4wTmZEcTRRSFUxSkM5ZVdwTHdSZ1c4ZG51bnVkMEZQQnE4S1doOXLSAcgBQVVfeXFMTnpsOTluZkhaUDBtRFNMNVA3dmRUZ3RBbHk4MThmdTZEUjJaeTBLWEd4NkM4YmN1bGM4UTlXOC00RGw3WXV3WmNxc1IzYXVBYlRiQ1pKN2tmRUhKbzgtUUI3MjE0Rko0UHVOZXpQLXNiV1JiVktlRW91NVlVUmozRVhqYXZ1UkxFcW50MlpxdnVaZFU0a01VNExCZVV3V25IaTRvRzBFLW1TRktnUUF0RS1Rc2dobWkzVnpBV2trVXo5MkVfY1pEU1Q?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Florida",
      "district": null,
      "headline": "Florida’s cellphone ban hasn’t reversed testing score trends | Opinion",
      "date": "Wed, 17 Dec 2025 08:00:00 GMT",
      "source": "Tallahassee Democrat",
      "url": "https://news.google.com/rss/articles/CBMixwFBVV95cUxNeTdvY2Jfa2RCSXJwdk5kVHRiMXdiNldRaS1Td2VSUm8xVExld0dBejd0d1JNX0d6UTBvNy16Wm0wOE53c2taT05LY3RJenJRX21YSlZLTXJSSmtQaWkyR2JGSVFkVE5PUms4blV2cGFMNVQ2VnhwNE55VGJfcjNuaUNDbHJuc3BjMzNhRmNJRTFIQnlFUDhRV0ZUcHRoSnUtWmM1ejR1MzVWMzlwZTE3QUg0RGxnZWQyalRPcWZ2d0NHaDZ5TnZV?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Vermont",
      "district": null,
      "headline": "Vermont School District Faces Racist Backlash Over Somali Flag Display",
      "date": "Mon, 15 Dec 2025 08:00:00 GMT",
      "source": "Campus Safety Magazine",
      "url": "https://news.google.com/rss/articles/CBMivAFBVV95cUxNbDB2UVFoaXdJX1ZZWXZiM1BRZ3hYbWJubXJSUmFrdGVhNDgzaFliZGptUE1nVE1aMTllUXpNdGptWDZTdjU5T1M3bmo5UHMzRXZiZ3QxdU1IVF9VZzc4SHNsZTBReUhPUHZSUHllVFVETGs1cnhfMm5XSndnSzRiN3VDSm0tS2xaOHJ4bzRiOUNMWjM1Tk84WUtkUlBpcU1Yc1BGUE9VcGRMTGZYRU9odmR2QVEyUllsVWllXw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alabama",
      "district": null,
      "headline": "Alabama’s FOCUS Act in effect: Statewide law aims to curb classroom distractions",
      "date": "Sat, 13 Dec 2025 08:00:00 GMT",
      "source": "HooverSun.com",
      "url": "https://news.google.com/rss/articles/CBMia0FVX3lxTE1qS2NUbU9tTEI5Y1JQZWxfNHQyZ05yajl1WUFTYWVHN1FBTlZidl9DNWxCbURBcWZzWDVqVWVaazl0eXVSYWkzbTZ0QjlGZU5rN3ZfejJ6NjFoVndsUVl0SS01R2JIQWszbV800gF2QVVfeXFMTWFUN2ZieFNTNGp0MWl3dkpPbHktUmM2cG1KR2VaaHhiSmMwd1FCS3NWWlBBdko5M0RlRU4xNmx2TUNLTUlIai1qR1RiRHNPTlNINzlyV214RFJyMi1NUHVFOXJOR2RxVFRUV2ZDb1lSV0lyZXBuQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Dakota",
      "district": null,
      "headline": "North Dakota cell phone ban shows positive results in Fargo area schools",
      "date": "Fri, 12 Dec 2025 08:00:00 GMT",
      "source": "Valley News Live",
      "url": "https://news.google.com/rss/articles/CBMisgFBVV95cUxOclM0ekRRYmJoSFlIeTN3dElVbXpqZnJ2NkhJdVlZRzI5aW1jb0ZiSzYzUkNxQlVXYkdfaWVrMUJDajBSZmpYb3E3UTlZVERobkZOTWlCQlJ4WEtmT3F4U0d6ajJVMzZoZm02YWpjWVk1NFFFbHROcXk2STktenNvTGZxTUZGbVdndmYwRkluNnIyMTYwYlJSVlZBMjNUVG9hdGh2Zkg2TU82WG45WHVpdTJn0gHGAUFVX3lxTFB3U1pfcWdmaG1pRzU3bllsYmdiZmFDX1FWNUFRQkdyQVUtU1hhTWd6WGd1dWFaNlhVd3Fuc3M3TEV0aHVCZTJ2NXR3MFNMNFNiRVkzTFpyLWE2MDlURmJ5ODJQX1drLWx6V3NZMjA5VEtpQ1RSRXQwd1dzU2RFUG95amVVR3BPbDhSeXIwT2dUUEVIUjFXUHVZQlpsc1VYdmZJZ2FhOUxnSXI0N2VvaXkxX0lKQlJ3RWJWcE9ZX0hBMldza08xZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Vermont",
      "district": null,
      "headline": "Somali flag flown outside Vermont school building over Trump ‘garbage’ slur brings threats",
      "date": "Fri, 12 Dec 2025 08:00:00 GMT",
      "source": "AP News",
      "url": "https://news.google.com/rss/articles/CBMilwFBVV95cUxQcURQT2xrOW96M1gxTGlGMmwxRHVTMW5SVUxmQmxibEI1UmNpVWdJcG1waVBLeUdMMGZhYzRwaTk3RFdpaS1FVkZSaVEtbmprdHBtSS14OW5ubUM2UTJXaDFlaUZ5UnhrRmNLSDBVLXVpcGhvTktHaURnWHNJNk9MQ0pockRCNlNzTjJOMDRDaG4yOEZjQUVz?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Vermont",
      "district": null,
      "headline": "After Trump's 'garbage' slur, a Vermont school building flew a Somali flag. Then came the threats",
      "date": "Fri, 12 Dec 2025 08:00:00 GMT",
      "source": "PBS",
      "url": "https://news.google.com/rss/articles/CBMixwFBVV95cUxNZnBfNjJ0bnNpT0pJeHdVOUJIREFCNnNjdzZtZU44YUlORFdzblZMZzVzck9HektiaUxGdXd1V3FUVldfOV9zbEJsbVRuQTVlVTNzWDkxdEJwc3Nzb2V0dkZIRzRBdnNFS2FtWjlwaDF3Ti1sZ3lyZFBqUWJVYlZpSEQ2SGY3eENwc3M1ME9HNkF2a01DYVB5LUlSenVTNW1QT3VHbjJkQ2hkYVRmRUVxZGxkTmlPWWdqN05VQm55RDlfQU9IWEpr?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Vermont",
      "district": null,
      "headline": "Somali flag flown outside Vermont school building over Trump ‘garbage’ slur brings threats",
      "date": "Fri, 12 Dec 2025 08:00:00 GMT",
      "source": "Los Angeles Times",
      "url": "https://news.google.com/rss/articles/CBMi2gFBVV95cUxPdmRheV9TSDJFYUVWMFhmbWQ1VXZCU0hTT0dvX00tYThneWJrQlp4YXQxSU1tRlhwNEpjeVRpY0RjZUxSWWRURU9lQTNlbGVYSG5Zc29ucmNJb3hlRGcwUE04bk1WcHNHZGwtZXA2dl81RWF4R2N0eFhlUWtWVXMyUVRSSHhvX0c4WGY1Q3JhQ3plaXNZSm51RWtvVi1mM2Y1RDNVaHpUSWRYTERUb21sUlBNMUVCXzFid3ZKRTE4LUVNNkpWWEpRZ2dIT1RFLVM0cXhOSkw4YWRSUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Carolina",
      "district": null,
      "headline": "AI-generated hoax phone call targets high school in South Carolina",
      "date": "Wed, 10 Dec 2025 08:00:00 GMT",
      "source": "WBTV",
      "url": "https://news.google.com/rss/articles/CBMinAFBVV95cUxNV0FuYnRZSTRiZFRkYmtzblJjdmFwRGNKcFl1RmhtM3NpVl9iNUh5cE9XUE5VcW9IZXVCaGVFc3JLSlJCRlktOElMYmtfbXY0Z0lmb2xxSXNyRXlkeVBnZW53VzRsRWw4V2FfaXZIeDZqeG80d3lhVnh5elJVRmFpblg0Wmp5czFHdTNIU0p1SWxpR3pWcmVNbEhCcUM?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Vermont",
      "district": null,
      "headline": "Vermont school district sparks outrage after raising Somali flag on campus",
      "date": "Tue, 09 Dec 2025 08:00:00 GMT",
      "source": "New York Post",
      "url": "https://news.google.com/rss/articles/CBMiswFBVV95cUxOc2h5N08zUTk3a3AzT2ZuczZQQklwWHg5SFFEOTdxcElGYlhjMnJNQ3kwMTRTMm45QmpvVTFEM2lKS2REQUxCUlpBZTdFMUtFTV82Z0dCV1c2dTJBVkttVHFIVVl0NUp3dGRqZmhSc2oxSVh6anZuQ1RyOEh1S3FncF9jV2tPMFB5bmpkd29wWnZZUlRYbU9xWGhQblVJNU85anBOYWhBNjRSLWc1Ulk4SXJLZw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Massachusetts",
      "district": null,
      "headline": "Most Massachusetts Parents Favor Banning Phones at School",
      "date": "Mon, 08 Dec 2025 08:00:00 GMT",
      "source": "govtech.com",
      "url": "https://news.google.com/rss/articles/CBMinAFBVV95cUxQd2hjUHNoSTRsUmVpbmNnaEZ2eVNBV3lOV0tZR1JqVWNiZ1l0eDROZ2lYZlltZ2cwTWFveWRvTlBONmhzYXpNYUw5ZVF4MlU5ODdLLUtTOVhlSEI3OEZiYWVJUks1endsV3c2bklGdDgtZHF4WFFBSGRWOFlDaGEtbE00Q1JQTy1nMlY0SGJZRk5ZQXhhdS1McWxHWmI?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Rhode Island",
      "district": null,
      "headline": "Anti-hazing bill will be on RI legislature’s agenda in January",
      "date": "Wed, 03 Dec 2025 08:00:00 GMT",
      "source": "Rhode Island Current",
      "url": "https://news.google.com/rss/articles/CBMipwFBVV95cUxQRG9JaXZkLTlDRklvdTNqMTFGN29BbzZUcFNWVDhQZVhvVHYtM0Q0M3lLWHdqQXpjeHo4LWc5LUtBbWRoU0tsWTV3YzNCR3FTT3R4ZlY0UjFZb25FU2ZaZTd1clRIVEttQUZnVVBubE4xbWgxMjlLX0YtaWtKT3p0THlDaF92MkkwSGNlZlVpc0hNMl9jTVE0M1Bkc1VIS1JxcTFJRnFFTQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alabama",
      "district": null,
      "headline": "Alabama's FOCUS Act in effect: Statewide law aims to curb classroom distractions",
      "date": "Mon, 01 Dec 2025 08:00:00 GMT",
      "source": "VestaviaVoice.com",
      "url": "https://news.google.com/rss/articles/CBMicEFVX3lxTE1tcVpmWWc4Unp4dVI5RzVOSDZPOGMySjRnOHlIVVN1eWNIS2dXOW13Szh3clB0NlJyZXF6Q3ppOEFsSGRvN2tMRG9LM0lyamsxRlVNVExSTDZmMUJralVMMWU5MERuWng0a1cyX0U0NlrSAXtBVV95cUxPRFdtOHllbE1tM1Q5bHM4YllEQzBTMnNYVjNxVTZwNWpDNEppRmlJN05HUjJFVzJETjVfTkdFUVptUDQzSWk4SXVGa3FZTU4yWEdReUdfVEYzMGY1ckdaRUVFX0Vsd05BRVpaeHRuY0dYN0VsNWdvLXlXMEU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "New Hampshire",
      "district": null,
      "headline": "The return of email, Uno and loud lunches: Inside the first three months of New Hampshire's school phone ban",
      "date": "Mon, 24 Nov 2025 08:00:00 GMT",
      "source": "Concord Monitor",
      "url": "https://news.google.com/rss/articles/CBMihwFBVV95cUxQRXZfVEdUdlhjWnBSZ2NoMi1oNjhPazUyblZaLUp3SlRncFZmRkpyLTBJUzZsWWszNVFFSUZXUVVqNEtCeVZxQklfb210eHM1SllZaHg4eUc3NTBSTWVWVXhVRDVqMGFybkxKb2FsWWFrT1RqMUhUQW0wWS1EOUtkQVktRkpkeW8?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nevada",
      "district": null,
      "headline": "Nevada schools implement phone pouches to boost focus and reduce issues",
      "date": "Fri, 21 Nov 2025 08:00:00 GMT",
      "source": "mynews4.com",
      "url": "https://news.google.com/rss/articles/CBMipAFBVV95cUxQTzlXRGhPOVNyZXBSRjFEdG9Yb0U3TmlFd0FaSnphMllJTkZiMEZrb0VGbHFvVkxIalhvVnd3bmh6MF83MDdNZnh0dlZuc1pPcDVGMkJGM3ZtU1l5OEl6ZkE3SV9adzhfRDZXQTBHcjJfUTlvTG5hNDU4MUtnNW5PM1pDYkVYQmQ3cEpsblNPbDlUaFdUMm82TlZLT3dvd29mckM4VQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alaska",
      "district": null,
      "headline": "Alaska AG calls out Anchorage School District’s failure to endorse U.S. Constitution flyer",
      "date": "Mon, 10 Nov 2025 08:00:00 GMT",
      "source": "Alaska Watchman",
      "url": "https://news.google.com/rss/articles/CBMiywFBVV95cUxPSDdwakhEbGx3TVZqZkg4VU12UjBWQ1NEZGVGOWVRUVROaF9aYUZ2MEw3cDAyWUJrMF9RN2VqZkJIWnNWUTdyWkFma2EtNDlkcFNtSU1qN1ljTVJnLXlfVFVLazBpTnJzYmZveEtfTTVJSm01dG9hVHo1NGFvZFlPOW5hR3BiWVJzMjk4NGRGbFExX0xwNTZJVVFSZEYzUGVNUDg0N01iQjVfeFVxbFFGOFRiMjRkS0Q5NDhVbk81d3dTdXFlcGNXSEU0UQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Tennessee",
      "district": null,
      "headline": "From cell phones to principal pipelines: How TERA empowers evidence-based decision making in Tennessee schools",
      "date": "Wed, 05 Nov 2025 08:00:00 GMT",
      "source": "Vanderbilt University",
      "url": "https://news.google.com/rss/articles/CBMi4wFBVV95cUxPNjV6cmprc3pwQWFGLURpM3c5VlI2NXVpdEdUQ1lsQVdCWXV2RHh6TVJPdVZsQVRMdnZGVndfdEp4blFXWnYzb3ZWRWdEZGhueE5Sa0pGTnpQTzVyTXRhRGdUYkxlSnpXbm80UFEwQldsWnVtbDV6MmpxUnJJTXhOc3l6TnVEZHVhdk82c2pXNGhSb1huNjB3eTNvcWxKQWNJODc5LTFIRjFPdUJ6WlpvOW8ycW1ubVdMUzFDMzJXcnRTR3J1REx4bWk0NHRIaWhyempSN0szczB0eXcxYm1EOVFjUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Dakota",
      "district": null,
      "headline": "From suspensions to conversations: The uneven impact of North Dakota’s school cell phone ban - KFYR-TV",
      "date": "Fri, 31 Oct 2025 07:00:00 GMT",
      "source": "KFYR-TV",
      "url": "https://news.google.com/rss/articles/CBMirwFBVV95cUxPelZ6c1NMRV82Y0V1Q0R0V2pnYXhId1BiaTBScFNYZjBWbGQ0OFlWdGpJSldpUEFscFZmZTVQRkxHZkZ0R3NNQ1NwREhJaG5oOWtJQXQ0M3B2VDEzbERSVjhfYzlPVl80dF9MUVpnemJmc1lOU1Brd0h1T2c2SHBzM3RfbUFyN0M4Ti02UzlaZEVNbHdzeUZkTzZYY2F6ZkZpNmpkSXhSR1JnTUZFX1dv0gHDAUFVX3lxTE1oOXBRem1kVE5nbjc1NE9OTzVqVlRfcVl4S1FoeTdVUkpUYjBXMTZPZnExTTREVkE1bFg5MDRBTkxqSmpIZFRncFp0REhuRUtxS0lDQ1prTkxIaDZfUDdxLS1ndFVFaUJmWTZXRElfRHgxX2pfc252clVBeUNLdVhjY3ltWnVhOGFQVVJzR2laMHBkREI5WDVMT2IxMDA5bkRYb1pheC1KYkNjYmF1ZHA0T1NfWEN6OV9zMC1fMmpMYnMyOA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arkansas",
      "district": null,
      "headline": "Arkansas educators report more engagement, less bullying after schools go phone-free - The Arkansas Democrat-Gaz...",
      "date": "Sun, 26 Oct 2025 07:00:00 GMT",
      "source": "The Arkansas Democrat-Gazette",
      "url": "https://news.google.com/rss/articles/CBMimwFBVV95cUxOcEhzcUZXUHhHQUVKbTlmakNwNVlER2xLZmZYVTNRV1V3dmt1VHpBSUt3ZmN0QjVua3hBNVBhay1fMmhXLXd6NEVlUjlSNU14VDRSNEtvNzVNSjFyMEthQ2pUaEJYYWFfQjFUdzgwWi1EaFFsdmx1U3dzaWNtOHoxMHVrVXp1Si02RXRXbF9kQzZ6WWJwZVg2RmlGUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Nebraska",
      "district": null,
      "headline": "Teacher and Her Boyfriend Accused of Sex Trafficking a Student in Nebraska",
      "date": "Sun, 26 Oct 2025 07:00:00 GMT",
      "source": "People.com",
      "url": "https://news.google.com/rss/articles/CBMinwFBVV95cUxNNUNGeFFyNHUtMGQtbUF2eXhWZklOdW5NRkJJbGlET00zaDNtSzhzOE80VjhBZjJBeUl0ZERZb1p6WEF3Mk51VkZZN3YyYklydzhTbkVIOUFEZ1lCdlZNX0NMdkx5ekR6NWVLc0NsaEJUUDBTTUU1RXJZVWFCR3Q3TVk1OHVKRDR6ZV9KV0lORFVSR0ZDMkV3QlBrOXQyWUU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Florida",
      "district": null,
      "headline": "How a statewide cell phone ban is changing Florida classrooms | Investigations - WINK News",
      "date": "Thu, 23 Oct 2025 23:27:25 GMT",
      "source": "WINK News - Southwest Florida",
      "url": "https://news.google.com/rss/articles/CBMihAJBVV95cUxPdHM1SVhLUHkxMnM4ek9Kck0zT1puSWR2ZFFwUUpuNGhwT29JdkNHbGxiblVzMHJLQWU1c2tVTm9UZExfd2ZTTTU0V1A3SGJNcVVOVlVhVG00dTFnQlBqWno3VDBsVGMwX1NuRmtpeW90UHJDMzlFRlhhMzJORkhreHZncWNKZ3k5eUYyRVZaT1lUTFlHanQyY2ZIZ05WQVVmWFVCZGdZcnRTNUhseG95T2RLQ1BBS19fU3o4ajJUeHlyYVVwTEJuX0ZKVXFIYU5pYjc0ejBjOGI1eGdZRFRvVlktUnZQYkhTZGhGMkFoQUp3aG9jNjlPZUgxM1NKdjRHUHFWOQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Florida",
      "district": null,
      "headline": "Florida Trend Education",
      "date": "Thu, 23 Oct 2025 07:00:00 GMT",
      "source": "Florida Trend",
      "url": "https://news.google.com/rss/articles/CBMif0FVX3lxTE83YlkxTHV2cXdxaWJrSkozM19MeTJzdmgwVV9kZGdOTm9EOGd1UVBHR1BNS0d5Q3lLU1dfM0x6R1RBWGloZkNnUFpGbmJ3VGR1RHNUOE5jVE55RXBfVUlSZ255dzFRT09kZWdpc3F2ZXZrbmxtc2N5TEg0cm12emM?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Tennessee",
      "district": null,
      "headline": "Rutherford County Schools reveals Tennessee’s first fleet of Mobile Learning Labs",
      "date": "Wed, 22 Oct 2025 07:00:00 GMT",
      "source": "rcschools.net",
      "url": "https://news.google.com/rss/articles/CBMiYEFVX3lxTE80aEFfcnlmdjdxaC14Zm00amg4c1p4NGwxTGQ1LXlWX1BhUVl0dzIxZ1RhOGp4OWtPaDJNaGNCRWVqVlUwVzNlc1FhMzdPaXdmY1g4Vnpib1kzVElFUHpkUA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alabama",
      "district": null,
      "headline": "'A blessing for education': Teachers and students embrace the cellphone ban under Alabama's Focus Act",
      "date": "Fri, 17 Oct 2025 07:00:00 GMT",
      "source": "WVTM",
      "url": "https://news.google.com/rss/articles/CBMikwFBVV95cUxQQmJqSXpMbjdnRHBwSmZ3eElaQTNRVUxfa05zb3czMi1TdlhLcm02d1MxUUxvWV90bzZfV0JudWdpb2lLd3VUVkNoTGJkVWg0VmdVOEdjUl90ZC1QM3E0VjU1OEJvMGpFNjlVQk9SemV2VHJGY2NqMXViaG16WnF0cENGQlNBT2FnT09EYXdEX2ZsZlU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "West Virginia",
      "district": null,
      "headline": "West Virginia schools enforce new cell phone ban in classrooms",
      "date": "Wed, 15 Oct 2025 07:00:00 GMT",
      "source": "WV News",
      "url": "https://news.google.com/rss/articles/CBMi4AFBVV95cUxNSHg3cTFLS21uc3N6Y2M5Q2dpa1pOZ1BHX0NOOExIM3FYaXZTNV9sWkdjWGtwYl9IRVc1NjF6OF84aE96bG5yRXd0d012UnI4SGF4OC0xV0FzczRrUFpKYU5iNnFnYkhGNXA5aXROVGRzeEdMSGFhSlhnZ0RNWEpBQWhxSTJqNFB1X3BZV1FGeEthQ3FhMk93UGNTeTgwcmhGY1BVcUQ1c250b1piZmdoT0p4eWUwUEpOQXAwQmFEb1I2MnlvUWxUbkZOU0pwRmhCOVpxNDdtaUNPa0FaN0ozWA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Missouri",
      "district": null,
      "headline": "St. Louis-area students turn to notes, cards after cellphones banned in Missouri schools",
      "date": "Mon, 13 Oct 2025 07:00:00 GMT",
      "source": "STLPR",
      "url": "https://news.google.com/rss/articles/CBMiigFBVV95cUxOb05RVTZGZ25QbUpDUzBJOGdpMFhLVWN2M0FreDV5d1hNc0p2RG9PNFBoX2dLU280Y0dWNlZPQTY3MkZHZWEtX3lzem5UQnNhQXFZS3FnNW1XSVU0WF80Wkd1WDZFZktXQWd1QXA1RkJYUGNsck91VkhPOUV2Z3hhYVMxXzhYNzVDUnc?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "West Virginia",
      "district": null,
      "headline": "International group sues WV health, education officials over state’s new artificial food dye ban",
      "date": "Mon, 13 Oct 2025 07:00:00 GMT",
      "source": "West Virginia Watch",
      "url": "https://news.google.com/rss/articles/CBMi0gFBVV95cUxPc0FtSy1pZHB5QS1FVElheVo4VzJFU1JKVTVnZHQycXpPOVk1RWxMb3IwUW1vcUtIZW4wYmFVXzhfMnJ5c3ByV3MwdWo0T0VkenBOM1Q5MlpFc0ZwSEZ6ZHVyaUNTcDFMa0tPOG5KM1FQQU5ZU0tsSkRFUnY4dFd1ZUQySkdqWnN6dS1DNlFuUkNGVE5rdngwRFVtVlQzcklwdWlhLVY5MUhiMzNfYVc5aldKNWZvcTc0VHlZQVV4SWN4S2hTYTlUMmlMNnJTWF92N0E?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alabama",
      "district": null,
      "headline": "Alabama Senate passes public K-12 school cell phone ban",
      "date": "Sat, 04 Oct 2025 07:00:00 GMT",
      "source": "1819 News",
      "url": "https://news.google.com/rss/articles/CBMijwFBVV95cUxPNFNDQW5CV2dNdUgzX09wWUQ3MDczZUI0OUV5MmNudzB3U2lqMENkX09ZYjBuUFl4cmZKM1RwdW92MHprS3pjLTZRenZwSzllTFBNc1FnUFpCYy1GM241TEsyVTlzUDlwdUd2ZjItX0pBX0ZTYkpuc2FDa3N6YldFUndhRi1fRDJqWEYwTHZzRQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kentucky",
      "district": null,
      "headline": "Kentucky school district enacts 'bell-to-bell' cellphone ban",
      "date": "Wed, 01 Oct 2025 07:00:00 GMT",
      "source": "Fox News",
      "url": "https://news.google.com/rss/articles/CBMiVkFVX3lxTFBobGM2ZFFGNVhDNEJnOG9hZEJMOUFlNW1odXlUemFEYUZ3aUxCZzUxVjBPNXhzUlNKWDdYZlRydnpwV0ZTX0IxMnFzNlZYT183eHEyTVB3?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alaska",
      "district": null,
      "headline": "Mat-Su District abandons Alaska’s top charter school amid lawsuit",
      "date": "Tue, 30 Sep 2025 07:00:00 GMT",
      "source": "Alaska Watchman",
      "url": "https://news.google.com/rss/articles/CBMiiwFBVV95cUxNUHhkdElBYmJUVEhMN3k0QnRPLUFscVg1WDJvNFBSVHFhSTNVRGlqR3Nnb05ldklWUng0N2pvMGRaVkhsYVl4bVpyT1dOcld5MlhPM0pkYnVTQkpCYkpNdExIQmRtVTl1emFSRm1wZFplWFpWQkJsNkt1bnJHbThmSWlseGYxNWpENm13?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kentucky",
      "district": null,
      "headline": "A school in Kentucky banned phones. Remarkable things started happening",
      "date": "Fri, 26 Sep 2025 07:00:00 GMT",
      "source": "The Detroit News",
      "url": "https://news.google.com/rss/articles/CBMi0AFBVV95cUxPbjBhUnpOUkdCTnVNbmFDT3lQMkNka0tDdXhxb0ZDaHFWZzY1ZUdUSFNBekw5THFPdzdBYWN4MzVOTjJPNTROZU5GdmstRlZMWDJMdGc5RmwyYTdZbjhBVU5RSFR1am9JUDdTMDdaSE5XMjlEMllrREVGd2t4N1VlQ3NvSk9xRTZ1NjNZNDVZUjBHMzU1a3MwWDlDWTg4T1lSd0FxUzljTmhyRU16eWlVdnhia055VGpndS1iVHIxeTV3SXBDQUlja2dpR3VsQnRB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Kentucky",
      "district": null,
      "headline": "A school in Kentucky banned phones. Remarkable things started happening.",
      "date": "Fri, 26 Sep 2025 07:00:00 GMT",
      "source": "The Washington Post",
      "url": "https://news.google.com/rss/articles/CBMie0FVX3lxTE1RWktmQ3FpeDdhWkdDMkdtdWFXckRIQmpnWmdTYUIwZHY3MElQNk4zODN1bnpLZV9QUmw5ZFd3NHVfTmRKWmQwUmJKWXhBY2NCdkp0cm4zYXBaSzdWdGRFbjhvWXllSFRjMGxDTHZQTm1lQVd0OG1QakN4OA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Dakota",
      "district": null,
      "headline": "Cellphone ban means less drama, more focus for some North Dakota students",
      "date": "Mon, 22 Sep 2025 07:00:00 GMT",
      "source": "North Dakota Monitor",
      "url": "https://news.google.com/rss/articles/CBMitgFBVV95cUxOOHRkOFJuQ0pRb25ydVdLUVE2a2c4YzZvZGJPTFQ4azBKdk1PRnVVNXNhcnhtUGMxNzRGdDNWZFRLN25PQWloYkVOSzl2dGdCaXhseDhkSnAtTjBzanZ3b3lnRm5xbGZYT1BGdUNjRWNJNGNReHBDcVVoT3pkNkFhb3NNd2xscnVoT3EwSVl5THhuUThLQzVLZ01uUWd2WmcycHY3RmN1bHd0ckxfOHVlQVFuZGhsUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Dakota",
      "district": null,
      "headline": "Cellphone ban means less drama, more focus for some North Dakota students",
      "date": "Mon, 22 Sep 2025 07:00:00 GMT",
      "source": "Route Fifty",
      "url": "https://news.google.com/rss/articles/CBMi3wFBVV95cUxNZmtZS0FqbF9hc3ZRSnBVZGtkMmxyb0FkYWw1X24zY25uMlRDS0p3al9OQlNzNi1Xa1QxNjNTYTJNd0pZVEJsM25XdFdEVUZxR2FReXlNTUUtd3ZrQ3dHY1J1Vm1lV0RtWFN2Sko4UXBvZS10WTNzRnpwTERxZ1pkd2kyVkxsXy10cWNhTmcyVjktZmVGc0JLNHk5RzdEUzBtX01rSG1VSW9fZHdnR2FQaUNvU0V1dUFQRklzUmM3M0poMkp0T1VfcThxbmttNEFCQ0dxeEJKcTU1UWRpVWpF?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alabama",
      "district": null,
      "headline": "Hale County High students, staff adjust amid Alabama cellphone ban",
      "date": "Fri, 19 Sep 2025 07:00:00 GMT",
      "source": "WVUA 23",
      "url": "https://news.google.com/rss/articles/CBMi4wFBVV95cUxPcldoMVVaLVE0VFBodXBpSktyeHZFcmNZOTJfOFptV09aa0IyQVRXYkpMZmdWVGtiYVZmUDdxN2kyM1ZLSC1xeXg2aHFPTmoxS2J3XzFBa1ZuWUptOHdmdXVhc3ZJODVQWFlkZjVnQ29MNEx6ME1MS3FpRmt2Z0JRSTRQVUg5Z1hRRDhiVmRNY2VZQ29iRWpaS2lDZWU4NTZSNUZ0ekVFUUdVcFVNeTd5X1Yya0ZFVmx1bHpuUGFUQTlTQ3Q1OUFrXzNFWWpFTm1nSzE5NVFLZm5hdUVLNXVBQk9mUQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alabama",
      "district": null,
      "headline": "Focus Act limits phone access in Alabama schools, sparking controversy",
      "date": "Thu, 18 Sep 2025 07:00:00 GMT",
      "source": "WBMA",
      "url": "https://news.google.com/rss/articles/CBMiiwJBVV95cUxNMHB1YVV3dl9EeG93R2lEOXA2VEM5X2RIbnpTZE54Y28wZDFhQkVHRzJIbVI3ZUJiS2wtX3R6SVkxamE0TFlHb2JMTmpGV3o0dnRvT0Jyay1WSnJuRWRwUkQwNEtuazctODZDOUM5SVA4NEd6V0JhSEV4blRmQ3hNallQaEM4bHNJRnp0TFBtVFVGMDZ4WEk2MkEzb2lQU0w3bUZiZ0hyWVZidUE0T2JBaURyZVJJeS1saWozYVNLNGxzMUlqN0ltV0dsVUNyVjZETC02VHJZX2ZNTXVvcHNNcGZmU2pZLTFUZTMwNWlaLWZYbHNLcXFLdmp4X1dLUnB2dUFpRzBEWkJGSUk?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Tennessee",
      "district": null,
      "headline": "How is the Tennessee cellphone ban affecting your school? Help us learn more.",
      "date": "Wed, 10 Sep 2025 07:00:00 GMT",
      "source": "Chalkbeat",
      "url": "https://news.google.com/rss/articles/CBMiqwFBVV95cUxNc1JXd21acEFjd1I3UTROT1lJUS1vd1lkaTIxa0RsUUl4R2JJQkhiV1NhQklHXzE3MHVyRUs5d0xpN2l4b1FSWmNTamFpWTFIcWFLaWIxSkRYREtrTk5NOE1OUm5XY3FoVm5DdmNTakN3cnkwaEJjUlBUbTNlWHhucHdJWjdfcVRBd0xSQTBHRFJjdElQeGprbVZSbEtmVl9DWDJ5UW9pUVN6RkU?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arkansas",
      "district": null,
      "headline": "Schools report success with Arkansas' phone-free law",
      "date": "Tue, 02 Sep 2025 07:00:00 GMT",
      "source": "Axios",
      "url": "https://news.google.com/rss/articles/CBMimAFBVV95cUxNd3dJcXN3NnV6STdyUGticTZqc2lQRFVicFhyRTlrNkhTa3FXS2dlM0hOeVdnOUx5ZlBhRm81WFgzYjBobGxUalpwUGk3NFlPRU5QWDZJRlNxeHZ3T2p0bVFlSXFkWkx6cmZ4WEt4d0pNdTJINUpHOEN1bE43bVZZWEx5NGVqT0RwSE5iNDlBOEQydHE5S1k2Tw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alabama",
      "district": null,
      "headline": "How is Alabama’s school cellphone ban going? Teachers call it ‘wonderful’",
      "date": "Thu, 28 Aug 2025 07:00:00 GMT",
      "source": "AL.com",
      "url": "https://news.google.com/rss/articles/CBMitAFBVV95cUxQeVZPemdFZXBJV2JGU3RfRzkxUWN3ZXZSVFZpaE9aVDc3NHJrbGp1cDZKZ1pNSktOWUd3VDdFVHdDWVpvSzdxWjFFUm55OW5zbk5WM3hRaUxlazNBelNKTTI4RlZ1d1pfaDFFNTN2WHlrbzF3WUJTZzRsWXBUV1V1YklwbjZfSzRaeGNpdWwxUThEVEV3UGR4NUd0akZpUXBlRk83MUthMGNta2EtaF83dURacXY?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alabama",
      "district": null,
      "headline": "Teachers Say Alabama's Phone Ban Made Classrooms 'Drastically Better'",
      "date": "Thu, 28 Aug 2025 07:00:00 GMT",
      "source": "govtech.com",
      "url": "https://news.google.com/rss/articles/CBMiqAFBVV95cUxOVmx3MXRTXzRWNThPTkRpUGdtbExqR25iek9iX3lIc3EycFQ1TUFvZ3NMamJZcFlCckphLXpLWkI1clJ4REN6bmtaZ0JURDF3MG1PUnItd2ZyX0hHUlJ1eVlsbzUyUWVfYkVHSGs5MllRQzlKUm1jVWkzUnljWG5UTWRUNFF2WXpScm1aRGRqN2hTam5qRW5BbXBqOS1zOTNqMWFIWEhfM3E?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arkansas",
      "district": null,
      "headline": "Pulaski County districts report on schools’ first weeks banning cellphones - The Arkansas Democrat-Gazette",
      "date": "Wed, 27 Aug 2025 07:00:00 GMT",
      "source": "The Arkansas Democrat-Gazette",
      "url": "https://news.google.com/rss/articles/CBMingFBVV95cUxOV21aaGtVQVFjODRrdTZPM1EyX2ZWSDQtamcxYkhtcG9MXzhVSElPcXlzYkJsN1lBUDFIUXpfN2UwNzBBNUkxMlNTRHk3cWV6Qjc4QVhoQmh6RURGalZVZzJwQlM5Zmd3ZjBvZ2FnVHEtQ3lFRjd5ZWM2Q1gtTkNiVWxzWXpNczNTREhEYlc1dGQ4UzZUT29LTEJGM1dSdw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arkansas",
      "district": null,
      "headline": "Little Rock School Board OKs cellphone policy; students must store, lock devices starting Friday - The Arkansas ...",
      "date": "Thu, 14 Aug 2025 07:00:00 GMT",
      "source": "The Arkansas Democrat-Gazette",
      "url": "https://news.google.com/rss/articles/CBMimgFBVV95cUxNTEQ0UWlZMGNUV3k3Szh0bXo4RmlQcDZ2RDhscXBsQ3FDT3JJZFNfRDlhUG8yb0tuR3N2Rk9tZHoyX1NORUxCVS11MXllQTY3S285YURTUnl2a0hWblMwUlNYdnBiUzhsNjg4MFR3VThGWDFOSHFQTmpObVZLTER6akJXQVlvQ1VrcU1odE9qaEhuTnlvbE83cmpR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alaska",
      "district": null,
      "headline": "First day of school on Thursday for some Alaska students",
      "date": "Wed, 13 Aug 2025 07:00:00 GMT",
      "source": "Alaska's News Source",
      "url": "https://news.google.com/rss/articles/CBMilwFBVV95cUxPX0RVMXo3eUJzY2RmU2JRY3p4NVdvNlphNEhnc1dvWURYWW9xZ2R0R1kxLVl3LWNqTk9DblVjcVZvbHdyWEJRV2UzNm9RNzljTVBwNFU3b01vTFV0Ni11WlNwaFJiNU1MSWtVVjdNcEZtQkY3djd2V1JEM3l5UHlQNElYVms5M08yeEs4OGxkN0toT0ZCZnRJ0gGrAUFVX3lxTE9EODlaY3JJTjVMZk02M2JMT1pob2JsQTRsdjJBMm01NEk0dmFvbWpvWTlJN3hCXzhycU9ZellsdU1hVDZzODJqemNydWpYMW1TLWNmeEZhazE0QmlIS2JwdEM4WXU1TFdBRk5DN0hNTGs1Q3oxUmxmcUlEZkpHTWlJMnFYekFHdms2Y3o4X2ZITGF4NV9VTzB4M0VCWEFNZXpFT3N2ZDdaZHRyQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arkansas",
      "district": null,
      "headline": "How This Arkansas School District Turned a Phone Ban Into a Student Win",
      "date": "Tue, 12 Aug 2025 07:00:00 GMT",
      "source": "Arkansas Money & Politics",
      "url": "https://news.google.com/rss/articles/CBMiekFVX3lxTE5iMW1KdVc2Q0ZWdGFBVk5oRUZOb3NjSWJnMlNDSWhJdVFhMkUwZFdfNGphdGpZMXB0STZJM2U4NHg3RnFkak5TLUoteDZiVmZKUXVmeWh0NXpZNERCc2oxQkdVMEJBVUEtMDJ2WGlmeFJFRkRGRElLenJR?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Alaska",
      "district": null,
      "headline": "Back-to-School: ‘Urgent priority to hire as many teachers as we can’ ASD looking to hire more staffing for next ...",
      "date": "Fri, 08 Aug 2025 07:00:00 GMT",
      "source": "Alaska's News Source",
      "url": "https://news.google.com/rss/articles/CBMi5AFBVV95cUxQMUpKbE5vMEVFYzlOeERETktCZlpHOHc0S3RYbG02VjVOcFZUbzB0ZnlUNGpmVmNfYUI3a1o0RVNDQy1LUzdFM0JBSmFncmtVaHRiUFRHWjdaNU1VTTFTUnNsQkdMTk1yelFLNUNvVnZvTlZFWEs3ZWx1N3BkajJmanlPVG1EM3ZPQWctSW4tT0JkSkE4RTI4UWItNHJVaXhTOUo5ci1KaU1JTmtZa2FIZk5ZbGh5a2p4LWJROWgzVG5palB1c2VuMk1ZVW16enlJTHBhanpiakNKbktMaEFkSDdSTXDSAfgBQVVfeXFMTVRXT3RXVWJEaldzTUhtUzNOdkdMdkRXUkJoN0ZiS0VRUXdfQy1iclR0bWJ3YVdOQlprTFAwdnNUMDdabGp5VUdLNS03Zk5jYlZOaF8yM0lHMzh0VGVwWHFnZzh3dlk1RjhnSlNWS21IdjZab1ZPUmp0Z0VWZEFWSUlIOGRhTHYwa1BNSG1GMFpsZmcyZTY2eVhsUmZ1U1RYUFNnTkhZT2pBd19OVWZBWTBfa3V6LUtQaGFvRElkdm1TaTNnX1MxaUlGSld1TEwyN1M5ZVFaTHpZdDJSckdBZGZvbS1aSmttSmlTSm1GdmFoYUFtNTM3LWk?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Louisiana",
      "district": null,
      "headline": "Here's what you need to know about Louisiana's new cell phone law",
      "date": "Fri, 08 Aug 2025 07:00:00 GMT",
      "source": "Shreveport Times",
      "url": "https://news.google.com/rss/articles/CBMixwFBVV95cUxNc2IzUXEwRTlVdkEzM3hHQnRzamJEX3JGbzlWNHN6LUNIVTZ6Mm8yY01IQlFadEx1M21NcmhCRG1XMDVkcVdSckFnM2lYM0VpRGJyT1lzSG9GM3BZLXBPVW9rUmVwOHQzYUFkZm9tTV9ZdktUT2pyeDRMRjNtbk5LZWdvdS0zb0lodENmTFJqMUtpUzhZT1VRZzFRdDVvNHJ0Nno3N1I2c05wNkh4R0QwVVVjeWVub0lVcS0tdGk5bXpfT1VkdldF?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Louisiana",
      "district": null,
      "headline": "Motorists Urged to Drive Safely as Louisiana Students Return to School",
      "date": "Wed, 06 Aug 2025 07:00:00 GMT",
      "source": "Louisiana State Police",
      "url": "https://news.google.com/rss/articles/CBMisAFBVV95cUxNSTRTU2xWMTlFRnBNMVdLdDlWenBFU250R2o5akR4WVU5cnhHaU85Q0g4VHJmVHd2Q1B3Rl8tZjFDZy1RN1Q2eU82dmphaFBpT01IdDhjYmlueGJIUnBXOG5PMTdUQXpFN2VwRGJsTnkzMEsyLTZINm9UTGVrUTQ1VkJxa29Yc3VVeUFubjdWTnkxbjlBVHVYLWFHNVJwcGdLcFVucFpvTTRjY1pnckgzQQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "Arkansas",
      "district": null,
      "headline": "'Bell to Bell, No Cell' law sparks student interaction in Arkansas schools, officials say",
      "date": "Tue, 05 Aug 2025 07:00:00 GMT",
      "source": "5newsonline.com",
      "url": "https://news.google.com/rss/articles/CBMi1AFBVV95cUxOdWxqVXhXVlVhZTNYMzN3WXVQczk5S3pnNTZDWG5YVjA5dmhSY0I1LXhQQk9XV3R4c1lCTVpLVW5PVFhrQ2Rreks1SUViNjFSZlNmb0ZHcjd2bjQ4c1NteE16eWVlbXFxbUtnZVg1RzZsd1djeHV3LWh1b1oxZG5kNThhUDRydzVveE81NkVOOHdqU3QxN3lvdWVLNE5odTIwRlZiMjdwb05qbVRKYzBfWlFxUW1KMFlSZjZVcGxhb1l0QWRLS00zRldMbFBlemRVOGNMVA?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Dakota",
      "district": null,
      "headline": "North Dakota’s public school cell phone ban to take effect soon",
      "date": "Fri, 01 Aug 2025 07:00:00 GMT",
      "source": "KX News",
      "url": "https://news.google.com/rss/articles/CBMiowFBVV95cUxPUzllOThHYy1TMnVQMUEwcnY5dklNYkplanRROWRyQWpzNEo0Q1QwNFFibHg2V1ZCY3U1dzFRQmhQcmU5RXJxdEl4UDl0b3FQMUJyZm5JOElKTVBZc1g3eXhKOS1wX01YaVhkVXVReEZzWkRUTWFKeW9KZjZwQURabDE4MkROU1RYRkROSnQ1anQ2dzF4TFBlLWk0UGNMd2hjLXIw0gGoAUFVX3lxTE93bGtscHFFd3NLTUZfMUhYbUwtaFlDOHFQUkpmMUxnSnZ0cFo4V2F5alVnX3JoNXY4RzZnajdYVHhxaWczNXRPb0VlbkZTZTl0NlVYRFhlX0RDZUUtOFhST01GTC1ZNVFhQkFxRHQwMmZnUUd6UE0zdmdoQlBicjZDSjBmQzBqSms4ZG5FMGc4LTdqanpqTGZYS1dYWWdtZjgzbWNxMXQyMw?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Carolina",
      "district": null,
      "headline": "South Carolina teachers say students are more engaged after cell phone ban",
      "date": "Fri, 25 Jul 2025 14:04:02 GMT",
      "source": "MSN",
      "url": "https://news.google.com/rss/articles/CBMiwAFBVV95cUxNMFZyR1VCbW9pNXVoYW5YZEY4WDVjb3FTcGlibWhrMTJDcERtVno0aDR2elVuTDEwendubVd1M2JPbXdUS3RFOGZCQkNOcmx6cm9SaXJvZGY0elhCNHJQRXZrMV9Kemg0SVdwV19ObHg2Wk93enRMRGZnSzduenRxTjlLdnFtVmRURjFKUEpmV3YyZzJQblRDWmJfTUR3SEllTllPR0tSMUk4bDc0bnZtdUtYazJTeDZOM292d05UT3M?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "North Dakota",
      "district": null,
      "headline": "Students, parents respond to North Dakota school cellphone ban",
      "date": "Thu, 24 Jul 2025 07:00:00 GMT",
      "source": "InForum",
      "url": "https://news.google.com/rss/articles/CBMipgFBVV95cUxPT3R1MjhBanhtbVpVcUdpTFhQSXNIR2N2ZWNTOEFGOFppVXhqcVY2dWFnZnlkbjBPNHRRZVEyVWVidnRoaGp5NW1wazVieHdaTjlfZkxVZEVURHliQVh0U1RGb1JJNFQ1MWx0clFFb19xUTc1LUIxbURpLVFEaWNqM1Jxb1ZtOExXWXZnS200VVlrOV9Sckx2UlNSRkN1S0F3dE03NWxn?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Carolina",
      "district": null,
      "headline": "New school year starts with student cellphone ban in effect across SC",
      "date": "Tue, 22 Jul 2025 07:00:00 GMT",
      "source": "Live 5 News",
      "url": "https://news.google.com/rss/articles/CBMipwFBVV95cUxQSDc2bV9RbkYwaTNrYUV2MVpoZjM0VEVCUm1iUjRYUjNpdmYtQU0xd0g5bVRvV0hsdXk0c0JVYXVmMXczdWVqZjF2SFNMRXNqNlhFUS03N295QkFJX3pMbTRoMzlwbS1BaUM3TGEwY05DeUttWEloQm80OF91d01md1RoMml4QU0xbUoybFowdG8yQ2trc0ozUDFWako2T1RRaVlrUW9aVdIBuwFBVV95cUxQZUdadVJJZFBUUlR5bVlMd1Nib1BHbmx4QkwwM0ZNdDZuaFN3clZCbllIZlNJSS16U21iQ2ctR0ZpS1NmSnhyQzh6cHIxMUQyNjdTTHhDRTFWVUxVSFhoZ1E3WlozQmFqSnBsWTR2dU5IMVpjajM5VUszdGtqbks4MzExTmE5RnAwVk5oZm0zaFhueFNhZ3U3SXlrdU4xdWo2RWNGZnBaZ0FkMi1UTGxfQ1dTeHE0V01fTlZB?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Carolina",
      "district": null,
      "headline": "SURVEY: How did South Carolina schools do without cell phones? - WSAV-TV",
      "date": "Mon, 21 Jul 2025 07:00:00 GMT",
      "source": "WSAV-TV",
      "url": "https://news.google.com/rss/articles/CBMiugFBVV95cUxPR1E0YVFqcGZfS1kwQkR0NXcxb3RvcG9BR0VqWXdtUjI3bVlqRGVvbHV6SDN2aTVoTTlVdkJjZmszcVJLcHFBa0otYm9sRkxUeUVLZjNkZFhYME5Dem5hYUcwVjZYMGpPRkk3WjJUSGs4NTdRbUJmbHdkSDZpeEREcGhuSnI1TDhhZG5nZnA1VC1yU21la2NyN2ZCX0F2THozZko4RXQ5ZEh2SGVkQUlpei03dEswa1ptSFHSAb8BQVVfeXFMTkEzRGJONG1HNlB1bnF0MHpZUmhuUEFnUmhhUXJxYk1QVE1EdEVObDdDODcxT3Rocmc2YWJEQnhKdUtFT2JWWFBMTFIycjE4d2tXWkRwSHl0Vy1fOE12S1dhT1VVRmZrQ3cwclg4LTMxQXp4U0thNmpRazljU0Vhb0hWYV9UcVdvWkxVT0FkeXFrQ2ZKUG5hTkdvNl9WQ1dXWHVRakFqWUZ3T3Exc0d1eUM2OUpMSU5BbnJudE05aDQ?oc=5",
      "type": "scrape",
      "free": true
    },
    {
      "state": "South Carolina",
      "district": null,
      "headline": "After a semester, SC schools' cellphone ban shows promise but raises enforcement questions",
      "date": "Wed, 02 Jul 2025 07:00:00 GMT",
      "source": "Post and Courier",
      "url": "https://news.google.com/rss/articles/CBMizAFBVV95cUxNYkE0RU96RVBVMXBQa2dLZ1hfRm9DY0lKcERfWUtkT2M4UE9RMjNWZ0I4Uy1lbWpvaVpfUU8tRlJ2a1lqak9RVEdwS1lVRHk2Vy1fSmtWUmE5OC1zUml2Z0FUWVJRVGE2MjVxR3YxTGJCRk1WZXFURVVyd0lYU1A2emNjRzN3Znd6bVdTNlNUWU5BVTdFeW5HcnZVYnQ4SXdvWVl2T1doU1ZZdl9kdmdsbWs1MDF1OWJPa0N4V19NNE5mR0lQWEowX1pLa04?oc=5",
      "type": "scrape",
      "free": true
    }
  ]
};
